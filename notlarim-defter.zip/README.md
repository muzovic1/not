# Notlarım – Geometri & Not Defteri

iPad için yazılmış, PDF üstüne çözüm yapılabilen dijital defter (PWA). Veriler cihazda (IndexedDB) tutulur.

## Yayınlama (GitHub Pages)
1. Bu klasörü bir GitHub deposuna `main` dalı olarak yükle.
2. Depo → Settings → Pages → Source: **GitHub Actions**.
3. Her `main` push'unda otomatik yayınlanır: `https://KULLANICI.github.io/DEPO/`
4. iPad Safari'de aç → Paylaş → **Ana Ekrana Ekle**.

## Yerelde çalıştırma
`npm install` → `npm run dev`
