import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

// GitHub Pages'te uygulama /repo-adi/ altında yayınlanır.
// Workflow BASE_PATH değişkenini otomatik verir; yerelde '/' kullanılır.
const base = process.env.BASE_PATH || '/';

export default defineConfig({
  base,
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['apple-touch-icon.png', 'pwa-192x192.png', 'pwa-512x512.png'],
      manifest: {
        id: base,
        name: 'Notlarım - Geometri & Not Defteri',
        short_name: 'Notlarım',
        description: 'Geometri odaklı dijital not defteri: PDF üstüne çözüm, akıllı şekil, pergel ve cetvel.',
        theme_color: '#2563eb',
        background_color: '#f8fafc',
        display: 'standalone',
        orientation: 'any',
        start_url: base,
        scope: base,
        icons: [
          {src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any'},
          {src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any'},
        ],
      },
      workbox: {
        // pdf.js ve yazı tipleri CDN'den geliyor: ilk açılıştan sonra çevrimdışı da çalışsın.
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/cdnjs\.cloudflare\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'cdn-pdfjs',
              cacheableResponse: {statuses: [0, 200]},
              expiration: {maxEntries: 10, maxAgeSeconds: 60 * 60 * 24 * 365},
            },
          },
          {
            urlPattern: /^https:\/\/fonts\.(googleapis|gstatic)\.com\/.*/i,
            handler: 'StaleWhileRevalidate',
            options: {
              cacheName: 'google-fonts',
              cacheableResponse: {statuses: [0, 200]},
              expiration: {maxEntries: 20, maxAgeSeconds: 60 * 60 * 24 * 365},
            },
          },
        ],
      },
    }),
  ],
});
