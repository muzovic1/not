import { useState, useEffect, useRef, useCallback } from 'react';
import { Notebook, PageData, PageStyle } from './types.ts';
import {
  getAllNotebooks,
  saveNotebook,
  deleteNotebookCascade,
  getPagesForNotebook,
  savePage,
  deletePagesFrom,
  seedInitialSampleIfEmpty,
} from './utils/db.ts';
import { exportNotebookToPDF } from './utils/pdf.ts';
import { HomeScreen } from './components/HomeScreen.tsx';
import { EditorScreen } from './components/EditorScreen.tsx';
import { NewNotebookModal } from './components/NewNotebookModal.tsx';

export default function App() {
  const [notebooks, setNotebooks] = useState<Notebook[]>([]);
  const [activeNotebookId, setActiveNotebookId] = useState<string | null>(null);
  const [currentPages, setCurrentPages] = useState<PageData[]>([]);
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  const [isNewNotebookModalOpen, setIsNewNotebookModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const saveTimerRef = useRef<number | null>(null);
  // Son kaydedilen sayfa nesneleri: sadece değişen sayfa yazılır (PDF'li defterlerde çok önemli)
  const savedRef = useRef<Map<string, PageData>>(new Map());
  const savedCountRef = useRef<number>(0);
  const pendingRef = useRef<{ nbId: string; pages: PageData[]; idx: number } | null>(null);
  const saveChainRef = useRef<Promise<void>>(Promise.resolve());
  const notebooksRef = useRef<Notebook[]>([]);
  notebooksRef.current = notebooks;

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 2800);
  }, []);

  // Initial load
  useEffect(() => {
    const init = async () => {
      try {
        const seeded = await seedInitialSampleIfEmpty();
        setNotebooks(seeded);
      } catch (e) {
        console.error('Database initialization failed', e);
        const list = await getAllNotebooks();
        setNotebooks(list);
      }
    };
    init();
  }, []);

  // Open notebook
  const handleOpenNotebook = async (id: string) => {
    try {
      const target = notebooks.find((nb) => nb.id === id);
      if (!target) return;

      const pages = await getPagesForNotebook(id, target.pageCount || 1);
      savedRef.current = new Map(pages.map((p, i) => [`${id}#${i}`, p]));
      savedCountRef.current = pages.length;
      pendingRef.current = null;
      setCurrentPages(pages);
      setCurrentPageIndex(Math.min(target.currentIdx || 0, pages.length - 1));
      setActiveNotebookId(id);
    } catch (e: any) {
      console.error('Failed to open notebook', e);
      showToast(`Defter açılamadı: ${e?.message || e}`);
    }
  };

  // Bekleyen değişiklikleri hemen yaz (sadece değişen sayfalar)
  const flushSave = useCallback((): Promise<void> => {
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
      saveTimerRef.current = null;
    }
    const pending = pendingRef.current;
    if (!pending) return saveChainRef.current;
    pendingRef.current = null;

    saveChainRef.current = saveChainRef.current.then(async () => {
      const { nbId, pages, idx } = pending;
      try {
        const currentNb = notebooksRef.current.find((nb) => nb.id === nbId);
        if (!currentNb) return;

        // 1. Sadece değişen sayfaları yaz
        for (let i = 0; i < pages.length; i++) {
          const key = `${nbId}#${i}`;
          if (savedRef.current.get(key) !== pages[i]) {
            await savePage(nbId, i, pages[i]);
            savedRef.current.set(key, pages[i]);
          }
        }

        // 2. Silinen sayfaların artık anahtarlarını temizle
        if (pages.length < savedCountRef.current) {
          await deletePagesFrom(nbId, pages.length);
          for (const k of Array.from(savedRef.current.keys())) {
            if (parseInt(k.split('#')[1], 10) >= pages.length) savedRef.current.delete(k);
          }
        }
        savedCountRef.current = pages.length;

        // 3. Defter bilgisini güncelle
        const updatedNb: Notebook = {
          ...currentNb,
          pageCount: pages.length,
          currentIdx: idx,
          updatedAt: Date.now(),
        };
        await saveNotebook(updatedNb);
        setNotebooks((prev) => prev.map((nb) => (nb.id === nbId ? updatedNb : nb)));
      } catch (e) {
        console.error('Failed to save pages', e);
      }
    });
    return saveChainRef.current;
  }, []);

  // Debounced quiet auto-save
  const triggerAutoSave = useCallback(
    (pagesToSave: PageData[], activeIdx: number) => {
      if (!activeNotebookId) return;
      pendingRef.current = { nbId: activeNotebookId, pages: pagesToSave, idx: activeIdx };
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
      saveTimerRef.current = window.setTimeout(() => {
        flushSave();
      }, 800);
    },
    [activeNotebookId, flushSave]
  );

  // Uygulama arka plana atılırken / sayfa kapanırken bekleyen kaydı yaz (iPad için kritik)
  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === 'hidden') flushSave();
    };
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onHide as any);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onHide as any);
    };
  }, [flushSave]);

  // Pages update from editor
  const handleUpdatePages = (newPages: PageData[]) => {
    setCurrentPages(newPages);
    triggerAutoSave(newPages, currentPageIndex);
  };

  // Change page index
  const handleSelectPageIndex = (idx: number) => {
    setCurrentPageIndex(idx);
    // Henüz kaydedilmemiş en güncel sayfalar varsa onları kullan (eski state'i yazıp yeni sayfayı ezme)
    triggerAutoSave(pendingRef.current?.pages ?? currentPages, idx);
  };

  // Update notebook title
  const handleUpdateNotebookTitle = (newTitle: string) => {
    if (!activeNotebookId) return;
    const trimmed = newTitle.trim() || 'İsimsiz Defter';
    setNotebooks((prev) =>
      prev.map((nb) =>
        nb.id === activeNotebookId
          ? { ...nb, name: trimmed, updatedAt: Date.now() }
          : nb
      )
    );
    const updated = notebooks.find((nb) => nb.id === activeNotebookId);
    if (updated) {
      saveNotebook({ ...updated, name: trimmed, updatedAt: Date.now() });
    }
  };

  // Create new notebook
  const handleCreateNotebook = async (
    name: string,
    icon: string,
    cover: string,
    initialStyle: PageStyle,
    description?: string,
    pageSize?: { width: number; height: number }
  ) => {
    const newId = `nb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newNotebook: Notebook = {
      id: newId,
      name,
      icon,
      cover,
      pageCount: 1,
      currentIdx: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      description,
    };

    const initialPage: PageData = {
      id: `${newId}#0`,
      type: initialStyle,
      bg: '#ffffff',
      width: pageSize?.width ?? 1000,
      height: pageSize?.height ?? 1414,
      pdfDataUrl: null,
      strokes: [],
    };

    await saveNotebook(newNotebook);
    await savePage(newId, 0, initialPage);
    savedRef.current = new Map([[`${newId}#0`, initialPage]]);
    savedCountRef.current = 1;
    pendingRef.current = null;

    setNotebooks((prev) => [newNotebook, ...prev]);
    setIsNewNotebookModalOpen(false);

    // Open immediately
    setCurrentPages([initialPage]);
    setCurrentPageIndex(0);
    setActiveNotebookId(newId);
    showToast(`"${name}" defteri oluşturuldu!`);
  };

  // Rename notebook from home
  const handleRenameNotebook = async (id: string) => {
    const target = notebooks.find((nb) => nb.id === id);
    if (!target) return;
    const newName = prompt('Defter için yeni başlık giriniz:', target.name);
    if (!newName || !newName.trim()) return;

    const updated: Notebook = {
      ...target,
      name: newName.trim(),
      updatedAt: Date.now(),
    };
    await saveNotebook(updated);
    setNotebooks((prev) => prev.map((nb) => (nb.id === id ? updated : nb)));
    showToast('Defter yeniden adlandırıldı.');
  };

  // Duplicate notebook
  const handleDuplicateNotebook = async (id: string) => {
    const target = notebooks.find((nb) => nb.id === id);
    if (!target) return;

    try {
      const newId = `nb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const targetPages = await getPagesForNotebook(id, target.pageCount || 1);

      const duplicatedNb: Notebook = {
        ...target,
        id: newId,
        name: `${target.name} (Kopya)`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };

      await saveNotebook(duplicatedNb);
      await Promise.all(
        targetPages.map((pg, idx) =>
          savePage(newId, idx, {
            ...pg,
            id: `${newId}#${idx}`,
            strokes: pg.strokes.map((s) => ({ ...s })),
          })
        )
      );

      setNotebooks((prev) => [duplicatedNb, ...prev]);
      showToast(`"${duplicatedNb.name}" kopyası oluşturuldu.`);
    } catch (e: any) {
      showToast(`Kopyalama başarısız: ${e?.message || e}`);
    }
  };

  // Delete notebook
  const handleDeleteNotebook = async (id: string) => {
    const target = notebooks.find((nb) => nb.id === id);
    if (!target) return;
    if (!confirm(`"${target.name}" defterini ve tüm sayfalarını silmek istediğinizden emin misiniz?`)) {
      return;
    }

    try {
      await deleteNotebookCascade(id);
      setNotebooks((prev) => prev.filter((nb) => nb.id !== id));
      if (activeNotebookId === id) {
        setActiveNotebookId(null);
      }
      showToast(`"${target.name}" defteri silindi.`);
    } catch (e: any) {
      showToast(`Silme hatası: ${e?.message || e}`);
    }
  };

  // Export notebook as JSON backup
  const handleExportNotebookJSON = async (id: string) => {
    const target = notebooks.find((nb) => nb.id === id);
    if (!target) return;

    try {
      const pages = await getPagesForNotebook(id, target.pageCount || 1);
      const backupData = {
        app: 'notlarim-geometri',
        version: 2,
        notebook: target,
        pages,
        exportedAt: new Date().toISOString(),
      };

      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${target.name.replace(/[/\\?%*:|"<>]/g, '').trim() || 'defter'}_yedek.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      try {
        localStorage.setItem('lastBackupAt', String(Date.now()));
      } catch {}
      showToast('Yedek JSON dosyası indirildi.');
    } catch (e: any) {
      showToast(`Yedekleme başarısız: ${e?.message || e}`);
    }
  };

  // Export notebook as PDF directly from home screen
  const handleExportNotebookPDF = async (id: string) => {
    const target = notebooks.find((nb) => nb.id === id);
    if (!target) return;

    try {
      showToast('PDF hazırlanıyor, lütfen bekleyin...');
      const pages = await getPagesForNotebook(id, target.pageCount || 1);
      await exportNotebookToPDF(target.name, pages);
      showToast('PDF başarıyla indirildi.');
    } catch (e: any) {
      showToast(`PDF hatası: ${e?.message || e}`);
    }
  };

  // Import notebook JSON
  const handleImportNotebookJSON = async (file: File) => {
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      const nbMeta = data.notebook || {
        name: data.name || 'İçe Aktarılan Defter',
        icon: data.icon || '📓',
        cover: data.cover || 'linear-gradient(135deg,#4facfe 0%,#00f2fe 100%)',
      };

      const rawPages: PageData[] = Array.isArray(data.pages) ? data.pages : [];
      if (rawPages.length === 0) {
        throw new Error('Dosyada geçerli sayfa verisi bulunamadı.');
      }

      const newId = `nb_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const importedNb: Notebook = {
        id: newId,
        name: nbMeta.name || 'İçe Aktarılan Defter',
        icon: nbMeta.icon || '📓',
        cover: nbMeta.cover || 'linear-gradient(135deg,#4facfe 0%,#00f2fe 100%)',
        pageCount: rawPages.length,
        currentIdx: 0,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        description: nbMeta.description || 'Yedekten geri yüklenen defter',
      };

      await saveNotebook(importedNb);
      await Promise.all(
        rawPages.map((pg, idx) =>
          savePage(newId, idx, {
            ...pg,
            id: `${newId}#${idx}`,
          })
        )
      );

      const all = await getAllNotebooks();
      setNotebooks(all);

      // Open imported notebook
      savedRef.current = new Map();
      savedCountRef.current = rawPages.length;
      pendingRef.current = null;
      setCurrentPages(rawPages);
      setCurrentPageIndex(0);
      setActiveNotebookId(newId);
      showToast(`"${importedNb.name}" başarıyla içe aktarıldı!`);
    } catch (e: any) {
      console.error(e);
      showToast(`Yedek dosyası açılamadı: ${e?.message || e}`);
    }
  };

  const activeNotebook = notebooks.find((nb) => nb.id === activeNotebookId);

  return (
    <div className="w-full h-full relative font-sans">
      {activeNotebookId && activeNotebook ? (
        <EditorScreen
          notebook={activeNotebook}
          pages={currentPages}
          currentPageIndex={currentPageIndex}
          onUpdateNotebookTitle={handleUpdateNotebookTitle}
          onUpdatePages={handleUpdatePages}
          onSelectPageIndex={handleSelectPageIndex}
          onBackToHome={async () => {
            // Bekleyen son çizimleri kaybetmeden kaydet, sonra ana ekrana dön
            await flushSave();
            setActiveNotebookId(null);
          }}
        />
      ) : (
        <HomeScreen
          notebooks={notebooks}
          onOpenNotebook={handleOpenNotebook}
          onNewNotebook={() => setIsNewNotebookModalOpen(true)}
          onRenameNotebook={handleRenameNotebook}
          onDuplicateNotebook={handleDuplicateNotebook}
          onExportNotebookJSON={handleExportNotebookJSON}
          onExportNotebookPDF={handleExportNotebookPDF}
          onDeleteNotebook={handleDeleteNotebook}
          onImportNotebookJSON={handleImportNotebookJSON}
        />
      )}

      {/* New Notebook Modal */}
      <NewNotebookModal
        isOpen={isNewNotebookModalOpen}
        onClose={() => setIsNewNotebookModalOpen(false)}
        onCreate={handleCreateNotebook}
      />

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900/95 text-white px-4 py-2.5 rounded-2xl shadow-xl text-xs font-semibold flex items-center gap-2 border border-white/10 animate-in fade-in slide-in-from-bottom-2 duration-150 pointer-events-none">
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
}
