import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// iPad Safari: uygulama gibi davransın (sayfa yakınlaşması, seçim balonu, sağ tık menüsü kapalı)
const isTextField = (t: EventTarget | null) =>
  t instanceof HTMLElement && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
['gesturestart', 'gesturechange', 'gestureend'].forEach((name) =>
  document.addEventListener(name, (e) => e.preventDefault())
);
document.addEventListener('contextmenu', (e) => {
  if (!isTextField(e.target)) e.preventDefault();
});
document.addEventListener('selectstart', (e) => {
  if (!isTextField(e.target)) e.preventDefault();
});

// Tarayıcıdan "bu verileri kalıcı sakla, yer daralınca silme" iste (iPad'de verinin silinmesine karşı)
try {
  navigator.storage?.persist?.().catch(() => {});
} catch {}

createRoot(document.getElementById('root')!).render(<App />);
