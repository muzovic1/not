import { PageData } from '../types.ts';
import { drawItem, drawBackgroundCanvas } from './canvasRenderer.ts';
import { savePdfDoc, releasePdfRefs } from './db.ts';
import { getPdfDocument, drawPdfPageToContext } from './pdfStore.ts';
import { jsPDF } from 'jspdf';

declare global {
  interface Window {
    pdfjsLib?: any;
  }
}

/**
 * PDF'i olduğu gibi veritabanına kaydeder; sayfa resmi ÜRETMEZ. Sayfalar ekrana geldiğinde çizilir.
 * Bu yüzden yüzlerce sayfalık kitaplar anında ve bellek yemeden içe aktarılır.
 */
export async function importPDFFile(
  file: File,
  notebookId: string,
  onProgress?: (current: number, total: number) => void
): Promise<PageData[]> {
  if (!window.pdfjsLib) {
    throw new Error('PDF kütüphanesi henüz yüklenmedi, lütfen internete bağlanıp sayfayı yenileyiniz.');
  }

  const buffer = await file.arrayBuffer();
  const docId = `pdf_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  await savePdfDoc(docId, buffer, file.name, notebookId);

  try {
    // Veritabanından tekrar okunur (pdf.js ham veriyi kendi işçisine devrettiği için)
    const pdf = await getPdfDocument(docId);
    const total: number = pdf.numPages;
    const pages: PageData[] = [];
    const LOGICAL_WIDTH = 1000;

    for (let i = 1; i <= total; i++) {
      if (onProgress) onProgress(i, total);
      const pdfPage = await pdf.getPage(i);
      const vp = pdfPage.getViewport({ scale: 1 });
      pdfPage.cleanup();
      const height = Math.max(1, Math.round((LOGICAL_WIDTH * vp.height) / vp.width));

      pages.push({
        id: `p_import_${Date.now()}_${i}`,
        type: 'blank',
        bg: '#ffffff',
        width: LOGICAL_WIDTH,
        height,
        pdfDataUrl: null,
        pdfRef: { docId, pageNo: i },
        strokes: [],
      });

      if (i % 25 === 0) await new Promise((r) => setTimeout(r, 0));
    }
    return pages;
  } catch (e) {
    await releasePdfRefs(notebookId, [docId]);
    throw e;
  }
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Resim yüklenemedi'));
    img.src = url;
  });
}

export function renderPageToCanvas(page: PageData, scale: number = 2): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = Math.floor(page.width * scale);
  canvas.height = Math.floor(page.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // Use the universal drawBackgroundCanvas
  drawBackgroundCanvas(ctx, page, { scale: 1, offsetX: 0, offsetY: 0 }, scale);

  // Draw strokes
  ctx.save();
  ctx.scale(scale, scale);
  for (const item of page.strokes) {
    drawItem(ctx, item);
  }
  ctx.restore();

  return canvas;
}

/**
 * Dışa aktarma için sayfayı tam kalitede çizer. PDF sayfalarını ve eski tip PDF resimlerini
 * (yüklenmesini bekleyerek) doğru şekilde arka plana koyar.
 */
export async function renderPageToCanvasAsync(page: PageData, scale: number = 2): Promise<HTMLCanvasElement> {
  if (!page.pdfRef && !page.pdfDataUrl) return renderPageToCanvas(page, scale);

  const canvas = document.createElement('canvas');
  canvas.width = Math.floor(page.width * scale);
  canvas.height = Math.floor(page.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.fillStyle = page.bg || '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  try {
    if (page.pdfRef) {
      await drawPdfPageToContext(page, ctx, canvas.width);
    } else if (page.pdfDataUrl) {
      const img = await loadImage(page.pdfDataUrl);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    }
  } catch (e) {
    console.warn('PDF arka planı çizilemedi', e);
  }

  ctx.save();
  ctx.scale(scale, scale);
  for (const item of page.strokes) {
    drawItem(ctx, item);
  }
  ctx.restore();
  return canvas;
}

function releaseCanvas(canvas: HTMLCanvasElement): void {
  canvas.width = 0;
  canvas.height = 0;
}

export async function exportNotebookToPDF(
  notebookName: string,
  pages: PageData[],
  onProgress?: (current: number, total: number) => void
): Promise<void> {
  if (pages.length === 0) return;

  // Çok sayfalı dosyalarda bellek için çözünürlük düşer
  const exportScale = pages.length > 150 ? 1.2 : pages.length > 60 ? 1.5 : 1.8;
  let doc: jsPDF | null = null;
  const safeName = notebookName.replace(/[/\\?%*:|"<>]/g, '').trim() || 'Defterim';

  for (let i = 0; i < pages.length; i++) {
    if (onProgress) onProgress(i + 1, pages.length);
    const page = pages[i];
    const orientation = page.height >= page.width ? 'portrait' : 'landscape';

    const canvas = await renderPageToCanvasAsync(page, exportScale);
    const imgData = canvas.toDataURL('image/jpeg', 0.88);
    releaseCanvas(canvas);

    if (!doc) {
      doc = new jsPDF({
        orientation,
        unit: 'px',
        format: [page.width, page.height],
        hotfixes: ['px_scaling'],
      });
    } else {
      doc.addPage([page.width, page.height], orientation);
    }

    doc.addImage(imgData, 'JPEG', 0, 0, page.width, page.height);
    if (i % 5 === 4) await new Promise((r) => setTimeout(r, 0));
  }

  if (doc) {
    doc.save(`${safeName}.pdf`);
  }
}

/**
 * Export a single active page as high-res PNG or JPEG image
 */
export async function exportSinglePageImage(
  page: PageData,
  filename: string,
  format: 'png' | 'jpeg' = 'png'
): Promise<void> {
  const canvas = await renderPageToCanvasAsync(page, 2);
  const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
  const dataUrl = canvas.toDataURL(mimeType, 0.95);

  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = `${filename}.${format}`;
  a.click();
}

/**
 * Copy active page image to clipboard for instant pasting (e.g. into WhatsApp, Docs, etc.)
 */
export async function copyPageImageToClipboard(page: PageData): Promise<boolean> {
  try {
    const canvas = await renderPageToCanvasAsync(page, 1.6);
    return new Promise((resolve) => {
      canvas.toBlob(async (blob) => {
        if (!blob) {
          resolve(false);
          return;
        }
        try {
          const item = new ClipboardItem({ 'image/png': blob });
          await navigator.clipboard.write([item]);
          resolve(true);
        } catch (err) {
          console.warn('Clipboard write failed', err);
          resolve(false);
        }
      }, 'image/png');
    });
  } catch (e) {
    return false;
  }
}
