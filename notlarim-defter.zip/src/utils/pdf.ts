import { PageData } from '../types.ts';
import { drawItem, getCachedImage, drawBackgroundCanvas } from './canvasRenderer.ts';
import { jsPDF } from 'jspdf';

declare global {
  interface Window {
    pdfjsLib?: any;
  }
}

export async function importPDFFile(
  file: File,
  onProgress?: (current: number, total: number) => void
): Promise<PageData[]> {
  if (!window.pdfjsLib) {
    throw new Error('PDF kütüphanesi henüz yüklenmedi, lütfen sayfayı yenileyiniz.');
  }

  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = window.pdfjsLib.getDocument({ data: arrayBuffer });
  const pdf = await loadingTask.promise;
  const pages: PageData[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    if (onProgress) onProgress(i, pdf.numPages);
    const pdfPage = await pdf.getPage(i);
    const viewportOriginal = pdfPage.getViewport({ scale: 1 });
    const targetWidth = 1800;
    const scale = targetWidth / viewportOriginal.width;
    const viewport = pdfPage.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    await pdfPage.render({
      canvasContext: ctx,
      viewport: viewport,
    }).promise;

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

    // İlk birkaç sayfa hemen hazır olsun; geri kalanlar ihtiyaç olunca yüklenir (bellek koruması)
    if (i <= 3) getCachedImage(dataUrl);

    pages.push({
      id: `p_import_${Date.now()}_${i}`,
      type: 'blank',
      bg: '#ffffff',
      width: canvas.width,
      height: canvas.height,
      pdfDataUrl: dataUrl,
      strokes: [],
    });
  }

  return pages;
}

export function renderPageToCanvas(page: PageData, scale: number = 2): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = Math.floor(page.width * scale);
  canvas.height = Math.floor(page.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // Use the universal drawBackgroundCanvas
  drawBackgroundCanvas(ctx, page, { scale: 1, offsetX: 0, offsetY: 0 }, scale);

  // Draw strokes
  ctx.save();
  ctx.scale(scale, scale);
  for (const item of page.strokes) {
    drawItem(ctx, item);
  }
  ctx.restore();

  return canvas;
}

export async function exportNotebookToPDF(
  notebookName: string,
  pages: PageData[],
  onProgress?: (current: number, total: number) => void
): Promise<void> {
  if (pages.length === 0) return;

  let doc: jsPDF | null = null;
  const safeName = notebookName.replace(/[/\\?%*:|"<>]/g, '').trim() || 'Defterim';

  for (let i = 0; i < pages.length; i++) {
    if (onProgress) onProgress(i + 1, pages.length);
    const page = pages[i];
    const orientation = page.height >= page.width ? 'portrait' : 'landscape';

    const canvas = renderPageToCanvas(page, 1.8);
    const imgData = canvas.toDataURL('image/jpeg', 0.92);

    if (!doc) {
      doc = new jsPDF({
        orientation,
        unit: 'px',
        format: [page.width, page.height],
        hotfixes: ['px_scaling'],
      });
    } else {
      doc.addPage([page.width, page.height], orientation);
    }

    doc.addImage(imgData, 'JPEG', 0, 0, page.width, page.height);
  }

  if (doc) {
    doc.save(`${safeName}.pdf`);
  }
}

/**
 * Export a single active page as high-res PNG or JPEG image
 */
export async function exportSinglePageImage(
  page: PageData,
  filename: string,
  format: 'png' | 'jpeg' = 'png'
): Promise<void> {
  const canvas = renderPageToCanvas(page, 2);
  const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
  const dataUrl = canvas.toDataURL(mimeType, 0.95);

  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = `${filename}.${format}`;
  a.click();
}

/**
 * Copy active page image to clipboard for instant pasting (e.g. into WhatsApp, Docs, etc.)
 */
export async function copyPageImageToClipboard(page: PageData): Promise<boolean> {
  try {
    const canvas = renderPageToCanvas(page, 1.6);
    return new Promise((resolve) => {
      canvas.toBlob(async (blob) => {
        if (!blob) {
          resolve(false);
          return;
        }
        try {
          const item = new ClipboardItem({ 'image/png': blob });
          await navigator.clipboard.write([item]);
          resolve(true);
        } catch (err) {
          console.warn('Clipboard write failed', err);
          resolve(false);
        }
      }, 'image/png');
    });
  } catch (e) {
    return false;
  }
}
