import { CanvasItem, BoundingBox, Point, FreehandStroke, ShapeStroke } from '../types.ts';

export function distance(p1: Point, p2: Point): number {
  return Math.hypot(p2.x - p1.x, p2.y - p1.y);
}

export function distanceToSegment(p: Point, v: Point, w: Point): number {
  const l2 = (w.x - v.x) ** 2 + (w.y - v.y) ** 2;
  if (l2 === 0) return distance(p, v);
  let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
  t = Math.max(0, Math.min(1, t));
  return distance(p, { x: v.x + t * (w.x - v.x), y: v.y + t * (w.y - v.y) });
}

export function ramerDouglasPeucker(points: Point[], epsilon: number): Point[] {
  if (points.length < 3) return points;
  let dmax = 0;
  let index = 0;
  const end = points.length - 1;

  for (let i = 1; i < end; i++) {
    const d = distanceToSegment(points[i], points[0], points[end]);
    if (d > dmax) {
      index = i;
      dmax = d;
    }
  }

  if (dmax > epsilon) {
    const rec1 = ramerDouglasPeucker(points.slice(0, index + 1), epsilon);
    const rec2 = ramerDouglasPeucker(points.slice(index), epsilon);
    return rec1.slice(0, -1).concat(rec2);
  }
  return [points[0], points[end]];
}

export function getItemBoundingBox(item: CanvasItem): BoundingBox | null {
  if (item.type === 'stroke') {
    if (!item.points || item.points.length === 0) return null;
    let x1 = Infinity;
    let y1 = Infinity;
    let x2 = -Infinity;
    let y2 = -Infinity;
    for (const p of item.points) {
      if (p.x < x1) x1 = p.x;
      if (p.y < y1) y1 = p.y;
      if (p.x > x2) x2 = p.x;
      if (p.y > y2) y2 = p.y;
    }
    const pad = Math.max(4, item.size / 2);
    return { x1: x1 - pad, y1: y1 - pad, x2: x2 + pad, y2: y2 + pad };
  }

  if (item.type === 'shape') {
    const x1 = Math.min(item.x1, item.x2);
    const y1 = Math.min(item.y1, item.y2);
    const x2 = Math.max(item.x1, item.x2);
    const y2 = Math.max(item.y1, item.y2);
    const pad = Math.max(4, item.size / 2);
    return { x1: x1 - pad, y1: y1 - pad, x2: x2 + pad, y2: y2 + pad };
  }

  if (item.type === 'text') {
    const lines = (item.text || '').split('\n');
    let maxLen = 0;
    for (const l of lines) {
      if (l.length > maxLen) maxLen = l.length;
    }
    const w = Math.max(maxLen * item.fontSize * 0.58, item.fontSize * 0.8);
    const h = lines.length * item.fontSize * 1.35;
    return { x1: item.x, y1: item.y, x2: item.x + w, y2: item.y + h };
  }

  if (item.type === 'image') {
    return { x1: item.x, y1: item.y, x2: item.x + item.width, y2: item.y + item.height };
  }

  if (item.type === 'sticker') {
    return { x1: item.x, y1: item.y, x2: item.x + item.fontSize, y2: item.y + item.fontSize };
  }

  return null;
}

export function pointInPolygon(point: Point, polygon: Point[]): boolean {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;
    const intersect = yi > point.y !== yj > point.y && point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/**
 * Intelligent Geometry Shape Recognition
 * Strict mathematical recognition for:
 * - Straight line (open stroke with low deviation)
 * - Circle / Ellipse (closed curve with radial uniformity)
 * - Triangle (closed 3-corner polygon)
 * - Rectangle / Square (closed 4-corner polygon with ~90 deg angles)
 *
 * CRITICAL: Handwriting (letters 'C', 'a', 'b', numbers, etc.) MUST RETURN NULL
 * so user handwriting remains 100% untouched and never gets mutated into boxes!
 */
export function recognizeGeometricShape(stroke: FreehandStroke): ShapeStroke[] | null {
  const pts = stroke.points;
  if (!pts || pts.length < 12) return null;

  const rawBBox = getItemBoundingBox(stroke);
  if (!rawBBox) return null;

  const width = rawBBox.x2 - rawBBox.x1;
  const height = rawBBox.y2 - rawBBox.y1;
  const diag = Math.hypot(width, height);
  // Protect small handwriting letters (a, c, e, numbers, symbols)
  if (diag < 45 || width < 20 || height < 20) return null;

  const start = pts[0];
  const end = pts[pts.length - 1];
  const distStartEnd = distance(start, end);

  // Compute total stroke path length
  let pathLength = 0;
  for (let i = 1; i < pts.length; i++) {
    pathLength += distance(pts[i - 1], pts[i]);
  }
  if (pathLength < 60) return null;

  // 1. OPEN STROKE: Straight Line Recognition
  // If the stroke is open and does not loop back
  if (distStartEnd > diag * 0.55 && distStartEnd / pathLength > 0.88) {
    let maxDistFromLine = 0;
    for (const p of pts) {
      maxDistFromLine = Math.max(maxDistFromLine, distanceToSegment(p, start, end));
    }
    // High strictness for straight lines: max deviation < 5% of diagonal or 6px
    if (maxDistFromLine < Math.max(6, diag * 0.055)) {
      return [
        {
          id: 'sh_' + Date.now() + '_line',
          type: 'shape',
          shape: 'line',
          x1: start.x,
          y1: start.y,
          x2: end.x,
          y2: end.y,
          color: stroke.color,
          size: stroke.size,
          opacity: stroke.opacity,
          lineCap: stroke.lineCap,
        },
      ];
    }
    // Open stroke that is not a straight line (e.g. 'C', 'S', handwriting) -> Keep untouched!
    return null;
  }

  // 2. CLOSED STROKE: Must be genuinely closed!
  // In letters 'C', 'a', etc., start and end don't meet as a closed geometric shape.
  const isClosed = distStartEnd < Math.max(22, diag * 0.16) && distStartEnd / pathLength < 0.13;
  if (!isClosed) {
    return null;
  }

  // 3. Test for Circle / Ellipse
  const cx = (rawBBox.x1 + rawBBox.x2) / 2;
  const cy = (rawBBox.y1 + rawBBox.y2) / 2;
  const rx = width / 2;
  const ry = height / 2;
  let isEllipse = true;
  let maxEllipseDev = 0;

  for (const p of pts) {
    const norm = Math.hypot((p.x - cx) / (rx || 1), (p.y - cy) / (ry || 1));
    const dev = Math.abs(norm - 1);
    if (dev > maxEllipseDev) maxEllipseDev = dev;
    if (dev > 0.22) {
      isEllipse = false;
      break;
    }
  }

  if (isEllipse && maxEllipseDev < 0.20) {
    return [
      {
        id: 'sh_' + Date.now() + '_ellipse',
        type: 'shape',
        shape: 'ellipse',
        x1: rawBBox.x1,
        y1: rawBBox.y1,
        x2: rawBBox.x2,
        y2: rawBBox.y2,
        color: stroke.color,
        size: stroke.size,
        opacity: stroke.opacity,
        lineCap: stroke.lineCap,
      },
    ];
  }

  // 4. Test for Polygons (Triangle or Rectangle)
  const simplified = ramerDouglasPeucker(pts, diag * 0.08);
  const uniqueCorners: Point[] = [];
  for (let i = 0; i < simplified.length; i++) {
    const pt = simplified[i];
    const prev = uniqueCorners[uniqueCorners.length - 1];
    if (!prev || distance(pt, prev) > diag * 0.14) {
      uniqueCorners.push(pt);
    }
  }

  // Drop duplicate closure corner if within threshold of first corner
  if (uniqueCorners.length > 2 && distance(uniqueCorners[uniqueCorners.length - 1], uniqueCorners[0]) < diag * 0.18) {
    uniqueCorners.pop();
  }

  // A. TRIANGLE: Exactly 3 unique corners
  if (uniqueCorners.length === 3) {
    const [p0, p1, p2] = uniqueCorners;
    const triArea = 0.5 * Math.abs(p0.x * (p1.y - p2.y) + p1.x * (p2.y - p0.y) + p2.x * (p0.y - p1.y));
    const bboxArea = width * height;
    if (triArea > bboxArea * 0.22) {
      return [
        {
          id: 'sh_' + Date.now() + '_1',
          type: 'shape',
          shape: 'line',
          x1: p0.x,
          y1: p0.y,
          x2: p1.x,
          y2: p1.y,
          color: stroke.color,
          size: stroke.size,
          opacity: stroke.opacity,
          lineCap: stroke.lineCap,
        },
        {
          id: 'sh_' + Date.now() + '_2',
          type: 'shape',
          shape: 'line',
          x1: p1.x,
          y1: p1.y,
          x2: p2.x,
          y2: p2.y,
          color: stroke.color,
          size: stroke.size,
          opacity: stroke.opacity,
          lineCap: stroke.lineCap,
        },
        {
          id: 'sh_' + Date.now() + '_3',
          type: 'shape',
          shape: 'line',
          x1: p2.x,
          y1: p2.y,
          x2: p0.x,
          y2: p0.y,
          color: stroke.color,
          size: stroke.size,
          opacity: stroke.opacity,
          lineCap: stroke.lineCap,
        },
      ];
    }
  }

  // B. RECTANGLE: Exactly 4 corners with ~90 degree angles
  if (uniqueCorners.length === 4) {
    let isRect = true;
    for (let i = 0; i < 4; i++) {
      const prev = uniqueCorners[(i + 3) % 4];
      const cur = uniqueCorners[i];
      const next = uniqueCorners[(i + 1) % 4];
      const v1 = { x: prev.x - cur.x, y: prev.y - cur.y };
      const v2 = { x: next.x - cur.x, y: next.y - cur.y };
      const len1 = Math.hypot(v1.x, v1.y);
      const len2 = Math.hypot(v2.x, v2.y);
      if (len1 < 1 || len2 < 1) {
        isRect = false;
        break;
      }
      const dot = (v1.x * v2.x + v1.y * v2.y) / (len1 * len2);
      // For orthogonal angles, |dot| is near 0. Max allowable tolerance: 0.35 (70-110 deg)
      if (Math.abs(dot) > 0.35) {
        isRect = false;
        break;
      }
    }

    if (isRect) {
      return [
        {
          id: 'sh_' + Date.now() + '_rect',
          type: 'shape',
          shape: 'rect',
          x1: rawBBox.x1,
          y1: rawBBox.y1,
          x2: rawBBox.x2,
          y2: rawBBox.y2,
          color: stroke.color,
          size: stroke.size,
          opacity: stroke.opacity,
          lineCap: stroke.lineCap,
        },
      ];
    }
  }

  // Fallback: Never alter ambiguous or handwritten strokes
  return null;
}

/**
 * REAL VECTOR ERASING (TRUE ERASER ENGINE)
 * Physically splits, trims, and removes strokes and shapes beneath the eraser!
 * Does NOT paint on top. Physically cuts the vector geometry.
 */
export function eraseAtPoint(
  items: CanvasItem[],
  point: Point,
  radius: number,
  eraseHighlighterOnly: boolean = false
): { updatedItems: CanvasItem[]; hasChanged: boolean } {
  let hasChanged = false;
  const result: CanvasItem[] = [];

  for (const item of items) {
    if (item.type === 'stroke') {
      if (eraseHighlighterOnly && item.tool !== 'highlighter') {
        result.push(item);
        continue;
      }

      const pts = item.points;
      if (!pts || pts.length === 0) {
        hasChanged = true;
        continue;
      }

      // Check if eraser is anywhere near the stroke bounding box
      const bb = getItemBoundingBox(item);
      if (bb) {
        if (
          point.x < bb.x1 - radius ||
          point.x > bb.x2 + radius ||
          point.y < bb.y1 - radius ||
          point.y > bb.y2 + radius
        ) {
          result.push(item);
          continue;
        }
      }

      // Segment the stroke by removing points within radius
      const subSegments: Point[][] = [];
      let currentSub: Point[] = [];

      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const isPointErased = distance(p, point) <= radius;

        // Also check if line segment between consecutive points crosses eraser circle
        let isSegmentErased = false;
        if (i > 0) {
          const dSeg = distanceToSegment(point, pts[i - 1], p);
          if (dSeg <= radius) {
            isSegmentErased = true;
          }
        }

        if (!isPointErased && !isSegmentErased) {
          currentSub.push(p);
        } else {
          if (currentSub.length > 0) {
            subSegments.push(currentSub);
            currentSub = [];
          }
          hasChanged = true;
        }
      }

      if (currentSub.length > 0) {
        subSegments.push(currentSub);
      }

      // Filter valid remaining parts
      const validSub = subSegments.filter(
        (seg) => seg.length >= 2 || (pts.length === 1 && seg.length === 1)
      );

      if (validSub.length < subSegments.length || subSegments.length > 1 || validSub.length === 0) {
        hasChanged = true;
      }

      for (let sIdx = 0; sIdx < validSub.length; sIdx++) {
        result.push({
          ...item,
          id: sIdx === 0 ? item.id : `${item.id}_cut_${sIdx}_${Date.now()}`,
          points: validSub[sIdx],
        });
      }
    } else if (item.type === 'shape') {
      if (eraseHighlighterOnly) {
        result.push(item);
        continue;
      }

      // Check if eraser touches shape boundaries
      let touched = false;
      if (item.shape === 'line' || item.shape === 'arrow') {
        const d = distanceToSegment(point, { x: item.x1, y: item.y1 }, { x: item.x2, y: item.y2 });
        if (d <= radius + (item.size || 4) / 2) {
          touched = true;
        }
      } else {
        const bb = getItemBoundingBox(item);
        if (bb) {
          const cx = Math.max(bb.x1, Math.min(point.x, bb.x2));
          const cy = Math.max(bb.y1, Math.min(point.y, bb.y2));
          if (Math.hypot(cx - point.x, cy - point.y) <= radius) {
            touched = true;
          }
        }
      }

      if (touched) {
        hasChanged = true;
        // Shape is deleted cleanly
      } else {
        result.push(item);
      }
    } else if (item.type === 'text' || item.type === 'image' || item.type === 'sticker') {
      if (eraseHighlighterOnly) {
        result.push(item);
        continue;
      }

      const bb = getItemBoundingBox(item);
      if (bb) {
        const cx = Math.max(bb.x1, Math.min(point.x, bb.x2));
        const cy = Math.max(bb.y1, Math.min(point.y, bb.y2));
        if (Math.hypot(cx - point.x, cy - point.y) <= radius) {
          hasChanged = true;
          // Item is deleted cleanly
          continue;
        }
      }
      result.push(item);
    } else {
      result.push(item);
    }
  }

  return { updatedItems: result, hasChanged };
}
