import { Notebook, PageData } from '../types.ts';

const DB_NAME = 'notesApp';
const DB_VERSION = 7;

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('notebooks')) {
        db.createObjectStore('notebooks');
      }
      if (!db.objectStoreNames.contains('pages')) {
        db.createObjectStore('pages');
      }
      // PDF dosyalarının kendisi (ikili veri) ve hangi defterlerin kullandığı
      if (!db.objectStoreNames.contains('pdfs')) {
        db.createObjectStore('pdfs');
      }
      if (!db.objectStoreNames.contains('pdfmeta')) {
        db.createObjectStore('pdfmeta');
      }
    };

    req.onsuccess = () => {
      resolve(req.result);
    };

    req.onerror = () => {
      reject(req.error);
    };
  });

  return dbPromise;
}

export async function dbGetAll<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function dbGetAllKeys(storeName: string): Promise<string[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAllKeys();
    req.onsuccess = () => resolve((req.result as string[]) || []);
    req.onerror = () => reject(req.error);
  });
}

export async function dbGet<T>(storeName: string, key: string): Promise<T | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

export async function dbPut<T>(storeName: string, key: string, value: T): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function dbDelete(storeName: string, key: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.delete(key);
    tx.oncomplete = () => resolve();
  });
}

export async function getAllNotebooks(): Promise<Notebook[]> {
  const list = await dbGetAll<Notebook>('notebooks');
  return list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
}

export async function saveNotebook(nb: Notebook): Promise<void> {
  await dbPut('notebooks', nb.id, nb);
}

// ---- PDF dosyaları ----
export interface PdfMeta {
  id: string;
  name?: string;
  size: number;
  refs: string[]; // bu PDF'i kullanan defter kimlikleri
}

export function collectPdfDocIds(pages: PageData[]): string[] {
  const ids = new Set<string>();
  for (const p of pages) {
    if (p && p.pdfRef && p.pdfRef.docId) ids.add(p.pdfRef.docId);
  }
  return Array.from(ids);
}

export async function savePdfDoc(
  docId: string,
  buffer: ArrayBuffer,
  name: string | undefined,
  nbId: string
): Promise<void> {
  await dbPut('pdfs', docId, buffer);
  const meta: PdfMeta = { id: docId, name, size: buffer.byteLength, refs: [nbId] };
  await dbPut('pdfmeta', docId, meta);
}

export async function getPdfBuffer(docId: string): Promise<ArrayBuffer | null> {
  return dbGet<ArrayBuffer>('pdfs', docId);
}

export async function hasPdfDoc(docId: string): Promise<boolean> {
  return !!(await dbGet<PdfMeta>('pdfmeta', docId));
}

export async function addPdfRef(docId: string, nbId: string): Promise<void> {
  const meta = await dbGet<PdfMeta>('pdfmeta', docId);
  if (!meta) return;
  if (!meta.refs.includes(nbId)) {
    meta.refs = [...meta.refs, nbId];
    await dbPut('pdfmeta', docId, meta);
  }
}

// Defter silinince PDF'i başka kullanan yoksa dosyayı da sil
export async function releasePdfRefs(nbId: string, docIds: string[]): Promise<void> {
  for (const docId of docIds) {
    const meta = await dbGet<PdfMeta>('pdfmeta', docId);
    if (!meta) continue;
    meta.refs = meta.refs.filter((r) => r !== nbId);
    if (meta.refs.length === 0) {
      await dbDelete('pdfs', docId);
      await dbDelete('pdfmeta', docId);
    } else {
      await dbPut('pdfmeta', docId, meta);
    }
  }
}

export async function deleteNotebookCascade(nbId: string): Promise<void> {
  const allKeys = await dbGetAllKeys('pages');
  const prefix = `${nbId}#`;
  const pageKeys = allKeys.filter((k) => typeof k === 'string' && k.startsWith(prefix));

  // Hangi PDF'leri kullandığını silmeden önce öğren
  const existing = await Promise.all(pageKeys.map((k) => dbGet<PageData>('pages', k)));
  const docIds = collectPdfDocIds(existing.filter((p): p is PageData => !!p));

  const deletePromises = pageKeys.map((k) => dbDelete('pages', k));
  deletePromises.push(dbDelete('notebooks', nbId));
  await Promise.all(deletePromises);
  await releasePdfRefs(nbId, docIds);
}

export async function getPagesForNotebook(nbId: string, pageCount: number): Promise<PageData[]> {
  const allKeys = await dbGetAllKeys('pages');
  const prefix = `${nbId}#`;
  const pageKeys = allKeys
    .filter((k) => typeof k === 'string' && k.startsWith(prefix))
    .sort((a, b) => {
      const idxA = parseInt(a.split('#')[1], 10);
      const idxB = parseInt(b.split('#')[1], 10);
      return idxA - idxB;
    });

  if (pageKeys.length === 0) {
    // Return at least 1 default page
    return [
      {
        id: `${nbId}#0`,
        type: 'squared',
        bg: '#ffffff',
        width: 1000,
        height: 1414,
        pdfDataUrl: null,
        strokes: [],
      },
    ];
  }

  const pages = await Promise.all(pageKeys.map((k) => dbGet<PageData>('pages', k)));
  const validPages = pages.filter((p): p is PageData => !!p);

  return validPages.length > 0
    ? validPages
    : [
        {
          id: `${nbId}#0`,
          type: 'squared',
          bg: '#ffffff',
          width: 1000,
          height: 1414,
          pdfDataUrl: null,
          strokes: [],
        },
      ];
}

export async function deletePagesFrom(nbId: string, fromIndex: number): Promise<void> {
  const allKeys = await dbGetAllKeys('pages');
  const prefix = `${nbId}#`;
  const stale = allKeys.filter(
    (k) => typeof k === 'string' && k.startsWith(prefix) && parseInt(k.split('#')[1], 10) >= fromIndex
  );
  await Promise.all(stale.map((k) => dbDelete('pages', k)));
}

export async function savePage(nbId: string, pageIndex: number, page: PageData): Promise<void> {
  await dbPut('pages', `${nbId}#${pageIndex}`, page);
}

export async function seedInitialSampleIfEmpty(): Promise<Notebook[]> {
  const existing = await getAllNotebooks();
  if (existing.length > 0) return existing;

  const sampleId = 'nb_sample_geo';
  const sampleNotebook: Notebook = {
    id: sampleId,
    name: 'Geometri & Matematik Notları',
    icon: '📐',
    cover: 'linear-gradient(135deg,#4facfe 0%,#00f2fe 100%)',
    pageCount: 2,
    currentIdx: 0,
    createdAt: Date.now() - 3600000,
    updatedAt: Date.now(),
    description: 'Akıllı şekil ve geometri çizimleri için hazır şablon defter.',
  };

  const page1: PageData = {
    id: `${sampleId}#0`,
    type: 'squared',
    bg: '#ffffff',
    width: 1000,
    height: 1414,
    pdfDataUrl: null,
    strokes: [
      {
        id: 's_title',
        type: 'text',
        x: 80,
        y: 80,
        text: '📐 Pisagor Teoremi & Üçgen Analizi',
        fontSize: 32,
        color: '#1c1c1e',
      },
      {
        id: 'sh_tri_1',
        type: 'shape',
        shape: 'line',
        x1: 150,
        y1: 450,
        x2: 450,
        y2: 450,
        color: '#007aff',
        size: 4,
        lineCap: 'round',
      },
      {
        id: 'sh_tri_2',
        type: 'shape',
        shape: 'line',
        x1: 150,
        y1: 450,
        x2: 150,
        y2: 200,
        color: '#007aff',
        size: 4,
        lineCap: 'round',
      },
      {
        id: 'sh_tri_3',
        type: 'shape',
        shape: 'line',
        x1: 150,
        y1: 200,
        x2: 450,
        y2: 450,
        color: '#ff9500',
        size: 5,
        lineCap: 'round',
      },
      {
        id: 's_lbl_a',
        type: 'text',
        x: 100,
        y: 310,
        text: 'a = 3',
        fontSize: 22,
        color: '#007aff',
      },
      {
        id: 's_lbl_b',
        type: 'text',
        x: 280,
        y: 470,
        text: 'b = 4',
        fontSize: 22,
        color: '#007aff',
      },
      {
        id: 's_lbl_c',
        type: 'text',
        x: 320,
        y: 300,
        text: 'c = 5 (Hipotenüs)',
        fontSize: 22,
        color: '#ff9500',
      },
      {
        id: 's_formula',
        type: 'text',
        x: 550,
        y: 240,
        text: 'a² + b² = c²\n3² + 4² = 9 + 16 = 25\n√25 = 5 ✓',
        fontSize: 24,
        color: '#34c759',
      },
      {
        id: 'sh_circle',
        type: 'shape',
        shape: 'ellipse',
        x1: 150,
        y1: 600,
        x2: 450,
        y2: 900,
        color: '#af52de',
        size: 4,
        lineCap: 'round',
      },
      {
        id: 's_circle_lbl',
        type: 'text',
        x: 520,
        y: 720,
        text: 'Daire Alanı = π · r²\nÇevre = 2 · π · r\nr = Yarıçap',
        fontSize: 22,
        color: '#af52de',
      },
      {
        id: 's_hint',
        type: 'text',
        x: 80,
        y: 1020,
        text: '💡 İpucu: Kalem seçiliyken elinizle üçgen veya çember çizdiğinizde\nAkıllı Şekil modu otomatik olarak kusursuz geometriye dönüştürür!',
        fontSize: 20,
        color: '#8e8e93',
      },
      {
        id: 'stk_star',
        type: 'sticker',
        emoji: '⭐',
        x: 880,
        y: 70,
        fontSize: 50,
      },
    ],
  };

  const page2: PageData = {
    id: `${sampleId}#1`,
    type: 'ruled',
    bg: '#ffffff',
    width: 1000,
    height: 1414,
    pdfDataUrl: null,
    strokes: [
      {
        id: 's_p2_title',
        type: 'text',
        x: 80,
        y: 80,
        text: '📝 Geometri Çalışma Kuralları',
        fontSize: 30,
        color: '#1c1c1e',
      },
      {
        id: 's_p2_txt',
        type: 'text',
        x: 80,
        y: 180,
        text: '1. Açıortay ve Kenarortay bağıntılarını tekrar et.\n2. Benzerlik oranlarının kareleri alan oranına eşittir.\n3. Çemberde teğet-kiriş açı teğetin değme noktasında oluşur.\n4. Kement (Lasso) aracıyla çizimleri seçip döndürebilir ve taşıyabilirsiniz.',
        fontSize: 22,
        color: '#1c1c1e',
      },
    ],
  };

  await saveNotebook(sampleNotebook);
  await savePage(sampleId, 0, page1);
  await savePage(sampleId, 1, page2);

  return [sampleNotebook];
}
