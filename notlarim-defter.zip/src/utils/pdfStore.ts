import { getPdfBuffer } from './db.ts';
import type { PageData } from '../types.ts';

// PDF dosyası veritabanında tek parça saklanır; sayfalar sadece ekrana geldiklerinde,
// ekranın ihtiyacı kadar çözünürlükte çizilir. Böylece 400 sayfalık kitap bile bellekte yer tutmaz.

// ---------------------------------------------------------------- belge önbelleği
const docCache = new Map<string, Promise<any>>();

export function getPdfDocument(docId: string): Promise<any> {
  let p = docCache.get(docId);
  if (!p) {
    p = (async () => {
      if (!window.pdfjsLib) throw new Error('PDF kütüphanesi yüklenmedi (ilk açılışta internet gerekir).');
      const buf = await getPdfBuffer(docId);
      if (!buf) throw new Error('PDF dosyası bulunamadı.');
      return await window.pdfjsLib.getDocument({ data: new Uint8Array(buf) }).promise;
    })();
    p.catch(() => docCache.delete(docId));
    docCache.set(docId, p);
  }
  return p;
}

// ---------------------------------------------------------------- çizilmiş sayfa önbelleği
interface CacheEntry {
  pageKey: string;
  width: number;
  canvas: HTMLCanvasElement;
  bytes: number;
  used: number;
}

const pageEntries = new Map<string, Map<number, CacheEntry>>(); // pageKey -> (genişlik -> kayıt)
let cacheBytes = 0;
let useCounter = 0;

const MAX_CACHE_BYTES = 220 * 1024 * 1024; // iPad için güvenli bellek bütçesi
const MIN_KEEP = 3;
const WIDTH_BUCKETS = [200, 420, 700, 1000, 1400, 2000, 2800];
const MAX_AREA = 12_000_000; // tek bir tuvalin piksel sınırı (iOS)

function bucketWidth(needed: number, aspect: number): number {
  const maxW = Math.max(200, Math.floor(Math.sqrt(MAX_AREA / aspect)));
  let target = WIDTH_BUCKETS[WIDTH_BUCKETS.length - 1];
  for (const b of WIDTH_BUCKETS) {
    if (b >= needed) {
      target = b;
      break;
    }
  }
  return Math.min(target, maxW);
}

function evictIfNeeded(keep: CacheEntry): void {
  while (cacheBytes > MAX_CACHE_BYTES) {
    let oldest: CacheEntry | null = null;
    let count = 0;
    for (const m of pageEntries.values()) {
      for (const e of m.values()) {
        count++;
        if (e === keep) continue;
        if (!oldest || e.used < oldest.used) oldest = e;
      }
    }
    if (!oldest || count <= MIN_KEEP) return;
    const m = pageEntries.get(oldest.pageKey);
    if (m) {
      m.delete(oldest.width);
      if (m.size === 0) pageEntries.delete(oldest.pageKey);
    }
    cacheBytes -= oldest.bytes;
    // iOS tuval belleğini ancak boyut sıfırlanınca bırakır
    oldest.canvas.width = 0;
    oldest.canvas.height = 0;
  }
}

// ---------------------------------------------------------------- çizim kuyruğu
interface Job {
  key: string;
  docId: string;
  pageNo: number;
  width: number;
  callbacks: Set<() => void>;
}

const queue: Job[] = [];
const jobsByKey = new Map<string, Job>();
const failedKeys = new Set<string>();
let running = false;
const MAX_QUEUE = 24;

async function pump(): Promise<void> {
  if (running) return;
  const job = queue.pop(); // en son istenen önce (kullanıcının şu an baktığı sayfa)
  if (!job) return;
  running = true;
  try {
    const doc = await getPdfDocument(job.docId);
    const pdfPage = await doc.getPage(job.pageNo);
    const base = pdfPage.getViewport({ scale: 1 });
    const viewport = pdfPage.getViewport({ scale: job.width / base.width });
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Tuval oluşturulamadı');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await pdfPage.render({ canvasContext: ctx, viewport }).promise;
    pdfPage.cleanup();

    const pageKey = `${job.docId}:${job.pageNo}`;
    let m = pageEntries.get(pageKey);
    if (!m) {
      m = new Map();
      pageEntries.set(pageKey, m);
    }
    const old = m.get(job.width);
    if (old) {
      cacheBytes -= old.bytes;
      old.canvas.width = 0;
      old.canvas.height = 0;
    }
    const entry: CacheEntry = {
      pageKey,
      width: job.width,
      canvas,
      bytes: canvas.width * canvas.height * 4,
      used: ++useCounter,
    };
    m.set(job.width, entry);
    cacheBytes += entry.bytes;
    evictIfNeeded(entry);

    jobsByKey.delete(job.key);
    job.callbacks.forEach((cb) => {
      try {
        cb();
      } catch {
        // yok say
      }
    });
  } catch (e) {
    console.warn('PDF sayfası çizilemedi', job.key, e);
    failedKeys.add(job.key);
    jobsByKey.delete(job.key);
    job.callbacks.forEach((cb) => {
      try {
        cb();
      } catch {
        // yok say
      }
    });
  } finally {
    running = false;
    // Tarayıcıya nefes aldır, sonra sıradakine geç
    setTimeout(pump, 0);
  }
}

function requestRender(docId: string, pageNo: number, width: number, onReady?: () => void): void {
  const key = `${docId}:${pageNo}:${width}`;
  if (failedKeys.has(key)) return;
  let job = jobsByKey.get(key);
  if (!job) {
    job = { key, docId, pageNo, width, callbacks: new Set() };
    jobsByKey.set(key, job);
    queue.push(job);
    while (queue.length > MAX_QUEUE) {
      const dropped = queue.shift();
      if (dropped) jobsByKey.delete(dropped.key);
    }
  } else {
    // yeniden istendi: kuyruğun sonuna (en önceliğe) taşı
    const idx = queue.indexOf(job);
    if (idx >= 0 && idx !== queue.length - 1) {
      queue.splice(idx, 1);
      queue.push(job);
    }
  }
  if (onReady) job.callbacks.add(onReady);
  pump();
}

// ---------------------------------------------------------------- dışarıya açılan işlevler

/** Sayfanın ekranda kapladığı piksel genişliğine uygun görüntüyü verir. Hazır değilse null (ya da
 * düşük çözünürlüklü geçici görüntü) döner ve hazır olunca onReady çağrılır. */
export function getPdfPageImage(
  page: PageData,
  neededPx: number,
  onReady?: () => void
): HTMLCanvasElement | null {
  const ref = page.pdfRef;
  if (!ref) return null;
  const aspect = page.height / page.width || 1.414;
  const want = bucketWidth(Math.max(1, neededPx), aspect);
  const pageKey = `${ref.docId}:${ref.pageNo}`;
  const m = pageEntries.get(pageKey);

  let exact: CacheEntry | undefined;
  let bigger: CacheEntry | undefined;
  let smaller: CacheEntry | undefined;
  if (m) {
    exact = m.get(want);
    if (!exact) {
      for (const e of m.values()) {
        if (e.width > want) {
          if (!bigger || e.width < bigger.width) bigger = e;
        } else if (!smaller || e.width > smaller.width) {
          smaller = e;
        }
      }
    }
  }

  const hit = exact || bigger;
  if (hit) {
    hit.used = ++useCounter;
    return hit.canvas;
  }

  requestRender(ref.docId, ref.pageNo, want, onReady);
  if (smaller) {
    smaller.used = ++useCounter;
    return smaller.canvas; // bulanık geçici görüntü
  }
  return null;
}

/** Sayfa şu an çizilemiyorsa (dosya yok vb.) true */
export function isPdfPageFailed(page: PageData, neededPx: number): boolean {
  const ref = page.pdfRef;
  if (!ref) return false;
  const aspect = page.height / page.width || 1.414;
  return failedKeys.has(`${ref.docId}:${ref.pageNo}:${bucketWidth(Math.max(1, neededPx), aspect)}`);
}

/** Dışa aktarma için: sayfayı doğrudan verilen (dönüşümsüz) tuvale, istenen genişlikte çizer. */
export async function drawPdfPageToContext(
  page: PageData,
  ctx: CanvasRenderingContext2D,
  outWidthPx: number
): Promise<void> {
  const ref = page.pdfRef;
  if (!ref) return;
  const doc = await getPdfDocument(ref.docId);
  const pdfPage = await doc.getPage(ref.pageNo);
  const base = pdfPage.getViewport({ scale: 1 });
  const viewport = pdfPage.getViewport({ scale: outWidthPx / base.width });
  await pdfPage.render({ canvasContext: ctx, viewport }).promise;
  pdfPage.cleanup();
}
