import { PageData, CanvasItem, FreehandStroke, ViewTransform, InteractiveRuler, InteractiveCompass } from '../types.ts';

const imageCache = new Map<string, HTMLImageElement>();

export function getCachedImage(url: string, onLoaded?: () => void): HTMLImageElement | null {
  if (imageCache.has(url)) {
    const img = imageCache.get(url)!;
    if (img.complete && img.naturalWidth > 0) return img;
    return null;
  }

  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    imageCache.set(url, img);
    if (onLoaded) onLoaded();
  };
  img.src = url;
  imageCache.set(url, img);
  return null;
}

export function drawSinglePageBackgroundContent(
  ctx: CanvasRenderingContext2D,
  page: PageData,
  onImageLoad?: () => void
): void {
  const isDark =
    page.type === 'dark-squared' ||
    page.type === 'dark-ruled' ||
    page.type === 'dark-blank' ||
    (page.bg && page.bg !== '#ffffff' && (page.bg === '#1c1c1e' || page.bg === '#121214'));

  // Background color
  const bgColor = page.type === 'dark-squared' || page.type === 'dark-ruled' || page.type === 'dark-blank'
    ? (page.bg && page.bg !== '#ffffff' ? page.bg : '#1c1c1e')
    : (page.bg || '#ffffff');

  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, page.width, page.height);

  // If page has PDF image
  if (page.pdfDataUrl) {
    const img = getCachedImage(page.pdfDataUrl, onImageLoad);
    if (img) {
      try {
        ctx.drawImage(img, 0, 0, page.width, page.height);
      } catch (e) {
        console.warn('PDF image draw error', e);
      }
      return;
    }
  }

  // Draw paper template pattern
  if (page.type === 'ruled' || page.type === 'dark-ruled') {
    ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 122, 255, 0.16)';
    ctx.lineWidth = 1;
    for (let y = 48; y < page.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(page.width, y);
      ctx.stroke();
    }
    // Margin line
    ctx.strokeStyle = isDark ? 'rgba(255, 69, 58, 0.28)' : 'rgba(255, 59, 48, 0.18)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(80, 0);
    ctx.lineTo(80, page.height);
    ctx.stroke();
  } else if (page.type === 'squared' || page.type === 'dark-squared') {
    ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.10)' : 'rgba(0, 122, 255, 0.11)';
    ctx.lineWidth = 1;
    // Vertical grid
    for (let x = 40; x < page.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, page.height);
      ctx.stroke();
    }
    // Horizontal grid
    for (let y = 40; y < page.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(page.width, y);
      ctx.stroke();
    }
  } else if (page.type === 'dotted') {
    ctx.fillStyle = isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(0, 0, 0, 0.22)';
    for (let x = 30; x < page.width; x += 36) {
      for (let y = 30; y < page.height; y += 36) {
        ctx.beginPath();
        ctx.arc(x, y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  } else if (page.type === 'coord-system') {
    // Full Cartesian Coordinate Grid
    const cx = Math.floor(page.width / 2);
    const cy = Math.floor(page.height / 2);
    const step = 40;

    // Subgrid
    ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 122, 255, 0.10)';
    ctx.lineWidth = 1;
    for (let x = 0; x <= page.width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, page.height);
      ctx.stroke();
    }
    for (let y = 0; y <= page.height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(page.width, y);
      ctx.stroke();
    }

    // Main Axes
    ctx.strokeStyle = isDark ? '#64d2ff' : '#007aff';
    ctx.lineWidth = 2.5;

    // X Axis
    ctx.beginPath();
    ctx.moveTo(20, cy);
    ctx.lineTo(page.width - 20, cy);
    ctx.stroke();

    // Arrow X
    ctx.beginPath();
    ctx.moveTo(page.width - 20, cy);
    ctx.lineTo(page.width - 32, cy - 6);
    ctx.lineTo(page.width - 32, cy + 6);
    ctx.closePath();
    ctx.fillStyle = isDark ? '#64d2ff' : '#007aff';
    ctx.fill();

    // Y Axis
    ctx.beginPath();
    ctx.moveTo(cx, page.height - 20);
    ctx.lineTo(cx, 20);
    ctx.stroke();

    // Arrow Y
    ctx.beginPath();
    ctx.moveTo(cx, 20);
    ctx.lineTo(cx - 6, 32);
    ctx.lineTo(cx + 6, 32);
    ctx.closePath();
    ctx.fill();

    // Axis Labels & Numbers
    ctx.font = '600 13px -apple-system, sans-serif';
    ctx.fillStyle = isDark ? '#98989d' : '#48484a';
    ctx.fillText('x', page.width - 15, cy - 10);
    ctx.fillText('y', cx + 10, 25);
    ctx.fillText('0', cx - 14, cy + 14);

    // Coordinate Numbers along axes
    ctx.font = '500 11px -apple-system, sans-serif';
    let count = 1;
    for (let x = cx + step; x < page.width - 40; x += step) {
      if (count % 2 === 0) {
        ctx.beginPath();
        ctx.moveTo(x, cy - 4);
        ctx.lineTo(x, cy + 4);
        ctx.stroke();
        ctx.fillText(String(count), x - 4, cy + 16);
      }
      count++;
    }
    count = 1;
    for (let x = cx - step; x > 40; x -= step) {
      if (count % 2 === 0) {
        ctx.beginPath();
        ctx.moveTo(x, cy - 4);
        ctx.lineTo(x, cy + 4);
        ctx.stroke();
        ctx.fillText(String(-count), x - 8, cy + 16);
      }
      count++;
    }
    count = 1;
    for (let y = cy - step; y > 40; y -= step) {
      if (count % 2 === 0) {
        ctx.beginPath();
        ctx.moveTo(cx - 4, y);
        ctx.lineTo(cx + 4, y);
        ctx.stroke();
        ctx.fillText(String(count), cx + 8, y + 4);
      }
      count++;
    }
    count = 1;
    for (let y = cy + step; y < page.height - 40; y += step) {
      if (count % 2 === 0) {
        ctx.beginPath();
        ctx.moveTo(cx - 4, y);
        ctx.lineTo(cx + 4, y);
        ctx.stroke();
        ctx.fillText(String(-count), cx + 8, y + 4);
      }
      count++;
    }
  } else if (page.type === 'custom' && page.customPaper) {
    const cp = page.customPaper;
    const spacing = Math.max(14, cp.spacing || 32);
    ctx.strokeStyle = cp.lineColor || (isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 122, 255, 0.15)');
    ctx.lineWidth = 1;

    if (cp.pattern === 'ruled') {
      for (let y = spacing; y < page.height; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(page.width, y);
        ctx.stroke();
      }
      // Margin line
      ctx.strokeStyle = isDark ? 'rgba(255, 69, 58, 0.35)' : 'rgba(255, 59, 48, 0.22)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(80, 0);
      ctx.lineTo(80, page.height);
      ctx.stroke();
    } else if (cp.pattern === 'squared') {
      for (let x = spacing; x < page.width; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, page.height);
        ctx.stroke();
      }
      for (let y = spacing; y < page.height; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(page.width, y);
        ctx.stroke();
      }
    } else if (cp.pattern === 'dotted') {
      ctx.fillStyle = cp.lineColor || (isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(0, 0, 0, 0.22)');
      for (let x = spacing; x < page.width; x += spacing) {
        for (let y = spacing; y < page.height; y += spacing) {
          ctx.beginPath();
          ctx.arc(x, y, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (cp.pattern === 'isometric') {
      // 30 degree isometric grid
      const isoStep = spacing;
      ctx.lineWidth = 0.8;
      for (let x = 0; x < page.width; x += isoStep) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, page.height);
        ctx.stroke();
      }
      const slope = Math.tan((30 * Math.PI) / 180);
      const yStep = isoStep * slope * 2;
      for (let startY = -page.width * slope; startY < page.height; startY += yStep) {
        ctx.beginPath();
        ctx.moveTo(0, startY);
        ctx.lineTo(page.width, startY + page.width * slope);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, startY + page.width * slope);
        ctx.lineTo(page.width, startY);
        ctx.stroke();
      }
    } else if (cp.pattern === 'music') {
      // Musical staves
      const staffLineGap = 9;
      const staveSpacing = 85;
      for (let staveTop = 70; staveTop < page.height - 60; staveTop += staveSpacing) {
        for (let line = 0; line < 5; line++) {
          const y = staveTop + line * staffLineGap;
          ctx.beginPath();
          ctx.moveTo(40, y);
          ctx.lineTo(page.width - 40, y);
          ctx.stroke();
        }
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(40, staveTop);
        ctx.lineTo(40, staveTop + 4 * staffLineGap);
        ctx.moveTo(page.width - 40, staveTop);
        ctx.lineTo(page.width - 40, staveTop + 4 * staffLineGap);
        ctx.stroke();
        ctx.lineWidth = 1;
      }
    } else if (cp.pattern === 'cornell') {
      // Cornell note template
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 70);
      ctx.lineTo(page.width, 70);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(220, 70);
      ctx.lineTo(220, page.height - 140);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, page.height - 140);
      ctx.lineTo(page.width, page.height - 140);
      ctx.stroke();

      ctx.font = 'bold 12px sans-serif';
      ctx.fillStyle = cp.lineColor || (isDark ? 'rgba(255, 255, 255, 0.4)' : 'rgba(0, 0, 0, 0.4)');
      ctx.fillText('BAŞLIK / KONU & TARİH', 40, 42);
      ctx.fillText('İPUÇLARI & SORULAR', 25, 95);
      ctx.fillText('DERS NOTLARI', 240, 95);
      ctx.fillText('ÖZET', 30, page.height - 110);

      ctx.lineWidth = 0.8;
      for (let y = 110; y < page.height - 150; y += 32) {
        ctx.beginPath();
        ctx.moveTo(220, y);
        ctx.lineTo(page.width, y);
        ctx.stroke();
      }
    }
  }
}

export function drawBackgroundCanvas(
  ctx: CanvasRenderingContext2D,
  page: PageData,
  view: ViewTransform,
  dpr: number,
  onImageLoad?: () => void
): void {
  const { width, height } = ctx.canvas;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const scale = view.scale * dpr;
  ctx.setTransform(scale, 0, 0, scale, view.offsetX * dpr, view.offsetY * dpr);

  drawSinglePageBackgroundContent(ctx, page, onImageLoad);
}

export function drawMultiplePagesBackground(
  ctx: CanvasRenderingContext2D,
  pages: PageData[],
  pageOffsets: number[],
  view: ViewTransform,
  dpr: number,
  onImageLoad?: () => void
): void {
  const { width, height } = ctx.canvas;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const scale = view.scale * dpr;
  const viewportTop = -view.offsetY / view.scale;
  const viewportBottom = (-view.offsetY + height / dpr) / view.scale;

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const topY = pageOffsets[i];

    // Viewport culling with safety margin
    if (topY + page.height < viewportTop - 120 || topY > viewportBottom + 120) {
      continue;
    }

    ctx.save();
    ctx.setTransform(scale, 0, 0, scale, view.offsetX * dpr, (view.offsetY + topY * view.scale) * dpr);

    // Subtle drop shadow and paper border
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
    ctx.shadowBlur = 14 * dpr;
    ctx.shadowOffsetY = 4 * dpr;
    ctx.fillStyle = page.bg || '#ffffff';
    ctx.fillRect(0, 0, page.width, page.height);
    ctx.restore();

    drawSinglePageBackgroundContent(ctx, page, onImageLoad);

    // Page number badge on bottom right corner
    ctx.font = '600 12px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    ctx.fillStyle = 'rgba(120, 120, 130, 0.55)';
    ctx.fillText(`${i + 1} / ${pages.length}`, page.width - 55, page.height - 18);

    ctx.restore();
  }
}

export function drawItem(
  ctx: CanvasRenderingContext2D,
  item: CanvasItem,
  onImageLoad?: () => void
): void {
  const opacity = item.opacity !== undefined ? item.opacity : 1;
  ctx.save();
  ctx.globalAlpha = opacity;

  if (item.type === 'stroke') {
    // True vector erasing is used; skip any legacy eraser stroke objects
    if ((item.tool as string) === 'eraser') {
      ctx.restore();
      return;
    }

    ctx.globalCompositeOperation = 'source-over';

    if (item.tool === 'highlighter') {
      ctx.globalAlpha = item.opacity !== undefined ? Math.min(0.65, item.opacity) : 0.42;
    }

    if (item.tool === 'laser') {
      ctx.shadowBlur = item.size * 3.5;
      ctx.shadowColor = item.color;
    }

    ctx.lineCap = item.lineCap || 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(0.5, item.size);
    ctx.strokeStyle = item.color;
    ctx.fillStyle = item.color;

    if (!item.points || item.points.length === 0) {
      ctx.restore();
      return;
    }

    const penType = item.penType || 'standard';
    const hasPressure = item.points.some((p) => p.pressure !== undefined && p.pressure > 0);

    if (item.points.length === 1) {
      const p = item.points[0];
      const pr = p.pressure ?? 0.5;
      const r = Math.max(0.8, item.size * 0.5 * (hasPressure ? (0.4 + 0.8 * pr) : 1));
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
    } else if (penType === 'fountain') {
      // Dolmakalem / Calligraphy: 45 degree chisel tip with angular stroke modulation
      for (let i = 1; i < item.points.length; i++) {
        const p1 = item.points[i - 1];
        const p2 = item.points[i];
        const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
        const angleDiff = Math.abs(Math.sin(angle - Math.PI / 4));
        const pr = p2.pressure ?? 0.5;
        const w = Math.max(0.8, item.size * (0.28 + 0.88 * angleDiff) * (hasPressure ? (0.5 + 0.65 * pr) : 1));

        ctx.beginPath();
        ctx.lineWidth = w;
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    } else if (penType === 'brush' || hasPressure) {
      // Dynamic brush or pressure-sensitive pen
      for (let i = 1; i < item.points.length; i++) {
        const p1 = item.points[i - 1];
        const p2 = item.points[i];
        const pr = p2.pressure ?? 0.5;
        const w = Math.max(0.7, item.size * (penType === 'brush' ? (0.25 + 1.15 * pr) : (0.45 + 0.75 * pr)));

        ctx.beginPath();
        ctx.lineWidth = w;
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(item.points[0].x, item.points[0].y);
      for (let i = 1; i < item.points.length; i++) {
        const p = item.points[i];
        const prev = item.points[i - 1];
        ctx.quadraticCurveTo(prev.x, prev.y, (prev.x + p.x) / 2, (prev.y + p.y) / 2);
      }
      ctx.stroke();
    }
  } else if (item.type === 'shape') {
    ctx.strokeStyle = item.color;
    ctx.fillStyle = item.fill ? item.color : 'transparent';
    ctx.lineWidth = item.size || 4;
    ctx.lineCap = item.lineCap || 'round';
    ctx.lineJoin = 'round';

    const { x1, y1, x2, y2 } = item;

    if (item.shape === 'rect') {
      const rx = Math.min(x1, x2);
      const ry = Math.min(y1, y2);
      const w = Math.abs(x2 - x1);
      const h = Math.abs(y2 - y1);
      ctx.beginPath();
      ctx.rect(rx, ry, w, h);
      if (item.fill) ctx.fill();
      ctx.stroke();
    } else if (item.shape === 'ellipse') {
      const cx = (x1 + x2) / 2;
      const cy = (y1 + y2) / 2;
      const rx = Math.abs(x2 - x1) / 2;
      const ry = Math.abs(y2 - y1) / 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, Math.max(1, rx), Math.max(1, ry), 0, 0, Math.PI * 2);
      if (item.fill) ctx.fill();
      ctx.stroke();
    } else if (item.shape === 'triangle') {
      const minX = Math.min(x1, x2);
      const maxX = Math.max(x1, x2);
      const minY = Math.min(y1, y2);
      const maxY = Math.max(y1, y2);
      ctx.beginPath();
      ctx.moveTo((minX + maxX) / 2, minY);
      ctx.lineTo(maxX, maxY);
      ctx.lineTo(minX, maxY);
      ctx.closePath();
      if (item.fill) ctx.fill();
      ctx.stroke();
    } else if (item.shape === 'line') {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    } else if (item.shape === 'arrow') {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();

      const angle = Math.atan2(y2 - y1, x2 - x1);
      const headLen = Math.max(14, (item.size || 4) * 4);
      const headAngle = Math.PI / 6.5;

      ctx.beginPath();
      ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - headLen * Math.cos(angle - headAngle), y2 - headLen * Math.sin(angle - headAngle));
      ctx.moveTo(x2, y2);
      ctx.lineTo(x2 - headLen * Math.cos(angle + headAngle), y2 - headLen * Math.sin(angle + headAngle));
      ctx.stroke();
    } else if (item.shape === 'right-angle') {
      // Right Angle Indicator (Dik Açı Sembolü)
      const w = x2 - x1;
      const h = y2 - y1;
      const cornerX = x1;
      const cornerY = y2;
      const size = Math.min(Math.abs(w), Math.abs(h), 32);
      const signX = Math.sign(w) || 1;
      const signY = -Math.sign(h) || 1;

      // Draw two arms
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(cornerX, cornerY);
      ctx.lineTo(x2, cornerY);
      ctx.stroke();

      // Draw Right Angle Box
      ctx.beginPath();
      ctx.moveTo(cornerX, cornerY + signY * size);
      ctx.lineTo(cornerX + signX * size, cornerY + signY * size);
      ctx.lineTo(cornerX + signX * size, cornerY);
      ctx.stroke();

      // Right angle dot in center
      ctx.beginPath();
      ctx.arc(cornerX + (signX * size) / 2, cornerY + (signY * size) / 2, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = item.color;
      ctx.fill();
    } else if (item.shape === 'angle-arc') {
      // Angle Arc with Degree (Açı Yayı ve Derece)
      const cx = x1;
      const cy = y1;
      const radius = Math.max(25, Math.hypot(x2 - x1, y2 - y1) * 0.45);
      const startAngle = 0;
      const endAngle = Math.atan2(y2 - y1, x2 - x1);

      // Arc
      ctx.beginPath();
      ctx.arc(cx, cy, radius, startAngle, endAngle, endAngle < 0);
      ctx.stroke();

      // Degree Text
      let deg = Math.round(Math.abs((endAngle * 180) / Math.PI));
      if (deg === 0) deg = 45;
      const midAngle = endAngle / 2;
      const textX = cx + (radius + 16) * Math.cos(midAngle);
      const textY = cy + (radius + 16) * Math.sin(midAngle);

      ctx.font = 'bold 15px -apple-system, sans-serif';
      ctx.fillStyle = item.color;
      ctx.fillText(`${deg}°`, textX, textY);
    } else if (item.shape === 'coord-axes') {
      // Standalone Coordinate System Box
      const minX = Math.min(x1, x2);
      const maxX = Math.max(x1, x2);
      const minY = Math.min(y1, y2);
      const maxY = Math.max(y1, y2);
      const cx = (minX + maxX) / 2;
      const cy = (minY + maxY) / 2;

      // Outer box
      ctx.strokeStyle = item.color;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(minX, minY, maxX - minX, maxY - minY);

      // Axes
      ctx.lineWidth = item.size || 3;
      ctx.beginPath();
      ctx.moveTo(minX + 10, cy);
      ctx.lineTo(maxX - 10, cy);
      ctx.moveTo(cx, maxY - 10);
      ctx.lineTo(cx, minY + 10);
      ctx.stroke();

      // Labels
      ctx.font = 'bold 14px -apple-system, sans-serif';
      ctx.fillStyle = item.color;
      ctx.fillText('x', maxX - 20, cy - 8);
      ctx.fillText('y', cx + 8, minY + 22);
      ctx.fillText('O', cx - 14, cy + 14);
    }
  } else if (item.type === 'text') {
    ctx.fillStyle = item.color;
    ctx.font = `600 ${item.fontSize}px 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif`;
    ctx.textBaseline = 'top';
    const lines = (item.text || '').split('\n');
    for (let k = 0; k < lines.length; k++) {
      ctx.fillText(lines[k], item.x, item.y + k * item.fontSize * 1.35);
    }
  } else if (item.type === 'image') {
    const img = getCachedImage(item.dataUrl, onImageLoad);
    if (img) {
      ctx.drawImage(img, item.x, item.y, item.width, item.height);
    }
  } else if (item.type === 'sticker') {
    ctx.font = `${item.fontSize}px 'Apple Color Emoji', 'Segoe UI Emoji', sans-serif`;
    ctx.textBaseline = 'top';
    ctx.fillText(item.emoji, item.x, item.y);
  }

  ctx.restore();
}

export function drawLaserTrail(
  ctx: CanvasRenderingContext2D,
  stroke: FreehandStroke,
  alpha: number
): void {
  if (alpha <= 0.02 || !stroke.points || stroke.points.length === 0) return;
  ctx.save();
  ctx.globalAlpha = alpha * (stroke.opacity !== undefined ? stroke.opacity : 1);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = stroke.color;
  ctx.fillStyle = stroke.color;
  ctx.lineWidth = stroke.size;
  ctx.shadowBlur = stroke.size * 3.5;
  ctx.shadowColor = stroke.color;

  if (stroke.points.length === 1) {
    ctx.beginPath();
    ctx.arc(stroke.points[0].x, stroke.points[0].y, stroke.size * 0.5, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
    for (let i = 1; i < stroke.points.length; i++) {
      const p = stroke.points[i];
      const prev = stroke.points[i - 1];
      ctx.quadraticCurveTo(prev.x, prev.y, (prev.x + p.x) / 2, (prev.y + p.y) / 2);
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function renderThumbnail(page: PageData, thumbCanvas: HTMLCanvasElement): void {
  const ctx = thumbCanvas.getContext('2d');
  if (!ctx) return;

  const w = thumbCanvas.width;
  const h = thumbCanvas.height;

  const isDark =
    page.type === 'dark-squared' ||
    page.type === 'dark-ruled' ||
    page.type === 'dark-blank' ||
    (page.bg && page.bg !== '#ffffff' && (page.bg === '#1c1c1e' || page.bg === '#121214'));

  ctx.fillStyle = isDark ? '#1c1c1e' : (page.bg || '#ffffff');
  ctx.fillRect(0, 0, w, h);

  if (page.pdfDataUrl) {
    const img = getCachedImage(page.pdfDataUrl);
    if (img) {
      try {
        ctx.drawImage(img, 0, 0, w, h);
      } catch (e) {
        console.warn(e);
      }
    }
  }

  const scale = w / page.width;
  ctx.save();
  ctx.scale(scale, scale);
  for (const item of page.strokes) {
    try {
      drawItem(ctx, item);
    } catch (e) {
      // ignore
    }
  }
  ctx.restore();
}

/**
 * Draw Interactive Acrylic Ruler / Protractor on Screen
 */
export function drawRulerOverlay(
  ctx: CanvasRenderingContext2D,
  ruler: InteractiveRuler,
  view: ViewTransform,
  dpr: number
): void {
  if (!ruler.visible) return;

  ctx.save();
  const rad = (ruler.angle * Math.PI) / 180;
  const s = view.scale * dpr;

  // Screen coordinates
  const sx = ruler.x * s + view.offsetX * dpr;
  const sy = ruler.y * s + view.offsetY * dpr;
  const screenLen = ruler.length * s;
  const height = (ruler.mode === 'protractor' ? 140 : 64) * s;

  ctx.translate(sx, sy);
  ctx.rotate(rad);

  if (ruler.mode === 'ruler') {
    // Acrylic Ruler Body
    ctx.fillStyle = 'rgba(255, 255, 255, 0.78)';
    ctx.strokeStyle = 'rgba(0, 122, 255, 0.4)';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.roundRect(-screenLen / 2, -height / 2, screenLen, height, 12 * s);
    ctx.fill();
    ctx.stroke();

    // Metric Centimeter Ticks
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#1c1c1e';
    ctx.strokeStyle = '#1c1c1e';
    const cmStep = 40 * s; // 40px in world space = 1 cm
    const totalTicks = Math.floor(screenLen / cmStep);

    ctx.font = `600 ${Math.max(10, 11 * s)}px -apple-system, sans-serif`;
    ctx.textAlign = 'center';

    for (let i = -totalTicks / 2; i <= totalTicks / 2; i++) {
      const tx = i * cmStep;
      const cmNumber = Math.abs(i);

      // Top Edge Ticks
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(tx, -height / 2);
      ctx.lineTo(tx, -height / 2 + 14 * s);
      ctx.stroke();

      if (i > -totalTicks / 2 && i < totalTicks / 2) {
        ctx.fillText(String(cmNumber), tx, -height / 2 + 26 * s);
      }

      // Millimeter sub-ticks
      ctx.lineWidth = 1;
      for (let m = 1; m < 5; m++) {
        const mx = tx + (m * cmStep) / 5;
        if (mx < screenLen / 2 && mx > -screenLen / 2) {
          ctx.beginPath();
          ctx.moveTo(mx, -height / 2);
          ctx.lineTo(mx, -height / 2 + (m === 2.5 ? 9 : 6) * s);
          ctx.stroke();
        }
      }
    }

    // Angle Badge in center
    ctx.fillStyle = '#007aff';
    ctx.beginPath();
    ctx.arc(0, 0, 20 * s, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.max(10, 12 * s)}px sans-serif`;
    ctx.fillText(`${Math.round(ruler.angle)}°`, 0, 4 * s);
  } else {
    // Protractor (Açıölçer / Yarım Daire)
    const radius = screenLen * 0.45;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.82)';
    ctx.strokeStyle = 'rgba(0, 122, 255, 0.45)';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
    ctx.shadowBlur = 18;

    ctx.beginPath();
    ctx.arc(0, 0, radius, Math.PI, 0, false);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Degree Ticks around semicircle
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#1c1c1e';
    ctx.fillStyle = '#1c1c1e';
    ctx.font = `600 ${Math.max(9, 10 * s)}px -apple-system, sans-serif`;
    ctx.textAlign = 'center';

    for (let deg = 0; deg <= 180; deg += 5) {
      const a = Math.PI - (deg * Math.PI) / 180;
      const isMajor = deg % 30 === 0;
      const isTen = deg % 10 === 0;
      const tickLen = (isMajor ? 16 : isTen ? 10 : 5) * s;

      const xOuter = radius * Math.cos(a);
      const yOuter = -radius * Math.sin(a);
      const xInner = (radius - tickLen) * Math.cos(a);
      const yInner = -(radius - tickLen) * Math.sin(a);

      ctx.lineWidth = isMajor ? 1.5 : 1;
      ctx.beginPath();
      ctx.moveTo(xOuter, yOuter);
      ctx.lineTo(xInner, yInner);
      ctx.stroke();

      if (isMajor && deg > 0 && deg < 180) {
        const textR = radius - 26 * s;
        ctx.fillText(String(deg), textR * Math.cos(a), -textR * Math.sin(a) + 3);
      }
    }

    // Center pivot point
    ctx.beginPath();
    ctx.arc(0, 0, 5 * s, 0, Math.PI * 2);
    ctx.fillStyle = '#007aff';
    ctx.fill();

    ctx.fillStyle = '#007aff';
    ctx.font = `bold ${Math.max(11, 13 * s)}px sans-serif`;
    ctx.fillText(`${Math.round(ruler.angle)}°`, 0, -28 * s);
  }

  ctx.restore();
}

/**
 * Draw Interactive Virtual Compass (İnteraktif Pergel)
 */
export function drawCompassOverlay(
  ctx: CanvasRenderingContext2D,
  compass: InteractiveCompass,
  view: ViewTransform,
  dpr: number
): void {
  if (!compass.visible) return;

  ctx.save();
  const s = view.scale * dpr;
  const cx = compass.x * s + view.offsetX * dpr;
  const cy = compass.y * s + view.offsetY * dpr;
  const r = compass.radius * s;
  const rad = (compass.angle * Math.PI) / 180;

  // Pencil tip position
  const px = cx + r * Math.cos(rad);
  const py = cy + r * Math.sin(rad);

  // 1. Center needle anchor
  ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
  ctx.shadowBlur = 8;
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(cx, cy, 6 * s, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(cx, cy, 2.5 * s, 0, Math.PI * 2);
  ctx.fill();

  // 2. Center needle crosshair
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 14 * s, 0, Math.PI * 2);
  ctx.stroke();

  // 3. Radius guide line and circle arc guide
  ctx.shadowBlur = 0;
  ctx.strokeStyle = 'rgba(59, 130, 246, 0.35)';
  ctx.setLineDash([4 * s, 4 * s]);
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);

  // 4. Compass dual articulated arms
  // Main needle arm
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 4 * s;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  const midArmX = (cx + px) / 2 + 10 * Math.sin(rad) * s;
  const midArmY = (cy + py) / 2 - 10 * Math.cos(rad) * s;
  ctx.lineTo(midArmX, midArmY);
  ctx.lineTo(px, py);
  ctx.stroke();

  // Direct connecting radius indicator line
  ctx.strokeStyle = 'rgba(37, 99, 235, 0.7)';
  ctx.lineWidth = 2 * s;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(px, py);
  ctx.stroke();

  // 5. Metal joint hinge at midpoint
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.arc(midArmX, midArmY, 6 * s, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.arc(midArmX, midArmY, 2.5 * s, 0, Math.PI * 2);
  ctx.fill();

  // 6. Pencil Tip
  ctx.fillStyle = '#2563eb';
  ctx.beginPath();
  ctx.arc(px, py, 7 * s, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(px, py, 3 * s, 0, Math.PI * 2);
  ctx.fill();

  // 7. Radius Measurement Badge in center
  const cm = (compass.radius / 40).toFixed(1);
  const badgeText = `r = ${cm} cm (${Math.round(compass.radius)} px) · ${Math.round(compass.angle)}°`;
  ctx.font = `600 ${Math.max(10, 11 * s)}px 'JetBrains Mono', monospace`;
  const textWidth = ctx.measureText(badgeText).width;

  const badgeX = (cx + px) / 2;
  const badgeY = (cy + py) / 2;

  ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
  ctx.beginPath();
  ctx.roundRect(badgeX - textWidth / 2 - 8 * s, badgeY - 26 * s, textWidth + 16 * s, 20 * s, 6 * s);
  ctx.fill();

  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(badgeText, badgeX, badgeY - 16 * s);

  ctx.restore();
}

