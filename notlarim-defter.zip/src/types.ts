export type PageStyle =
  | 'blank'
  | 'ruled'
  | 'squared'
  | 'dotted'
  | 'dark-squared'
  | 'dark-ruled'
  | 'dark-blank'
  | 'coord-system'
  | 'custom';

export type PatternType =
  | 'blank'
  | 'ruled'
  | 'squared'
  | 'dotted'
  | 'isometric'
  | 'music'
  | 'cornell';

export interface CustomPaperConfig {
  pattern: PatternType;
  spacing: number; // e.g. 24, 32, 40
  lineColor: string;
  bgColor: string;
  subdivision?: number;
}

export interface Point {
  x: number;
  y: number;
  pressure?: number;
}

export interface BoundingBox {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export type StrokeTool = 'pen' | 'highlighter' | 'laser' | 'eraser';
export type PenStyle = 'standard' | 'fountain' | 'brush';

export interface BaseStroke {
  id: string;
  opacity?: number;
}

export interface FreehandStroke extends BaseStroke {
  type: 'stroke';
  tool: StrokeTool;
  color: string;
  size: number;
  lineCap?: CanvasLineCap;
  points: Point[];
  penType?: PenStyle;
  createdAt?: number;
}

export type ShapeType =
  | 'rect'
  | 'ellipse'
  | 'line'
  | 'arrow'
  | 'triangle'
  | 'right-angle'
  | 'angle-arc'
  | 'coord-axes';

export interface ShapeStroke extends BaseStroke {
  type: 'shape';
  shape: ShapeType;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  color: string;
  size: number;
  fill?: boolean;
  lineCap?: CanvasLineCap;
  angleValue?: number;
}

export interface TextStroke extends BaseStroke {
  type: 'text';
  x: number;
  y: number;
  text: string;
  fontSize: number;
  color: string;
}

export interface ImageStroke extends BaseStroke {
  type: 'image';
  dataUrl: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface StickerStroke extends BaseStroke {
  type: 'sticker';
  emoji: string;
  x: number;
  y: number;
  fontSize: number;
}

export type CanvasItem = FreehandStroke | ShapeStroke | TextStroke | ImageStroke | StickerStroke;

export interface AudioRecording {
  id: string;
  name: string;
  duration: number; // seconds
  dataUrl: string;
  createdAt: number;
}

export interface PageData {
  id: string;
  type: PageStyle;
  bg: string;
  width: number;
  height: number;
  pdfDataUrl: string | null; // eski içe aktarmalar (sayfa resmi olarak saklanmış)
  pdfRef?: { docId: string; pageNo: number }; // yeni: PDF dosyası ayrı saklanır, sayfa ihtiyaç anında çizilir
  strokes: CanvasItem[];
  bookmarked?: boolean;
  title?: string;
  audioRecordings?: AudioRecording[];
  customPaper?: CustomPaperConfig;
}

export interface Notebook {
  id: string;
  name: string;
  icon: string;
  cover: string;
  pageCount: number;
  currentIdx: number;
  createdAt: number;
  updatedAt: number;
  description?: string;
}

export type ActiveTool =
  | 'hand'
  | 'pen'
  | 'highlighter'
  | 'laser'
  | 'eraser'
  | 'stroke-eraser'
  | 'lasso'
  | 'rect'
  | 'ellipse'
  | 'triangle'
  | 'line'
  | 'arrow'
  | 'right-angle'
  | 'angle-arc'
  | 'coord-axes'
  | 'text'
  | 'compass';

export interface ToolSettingsItem {
  size: number;
  opacity: number;
  color: string;
  lineCap?: CanvasLineCap;
  smartShape?: boolean;
  fill?: boolean;
  eraseHighlighterOnly?: boolean;
  penType?: PenStyle;
  pressureSensitivity?: boolean;
  drawAndHold?: boolean;
}

export type ToolSettingsMap = Record<ActiveTool, ToolSettingsItem>;

export interface ViewTransform {
  scale: number;
  offsetX: number;
  offsetY: number;
}

export interface InteractiveRuler {
  visible: boolean;
  x: number;
  y: number;
  angle: number; // in degrees
  length: number;
  mode: 'ruler' | 'protractor';
}

export interface InteractiveCompass {
  visible: boolean;
  x: number; // needle pivot X
  y: number; // needle pivot Y
  radius: number; // radius in px
  angle: number; // rotation in degrees
}
