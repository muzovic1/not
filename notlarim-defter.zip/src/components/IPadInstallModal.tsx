import { useState } from 'react';
import {
  X,
  Share,
  PlusSquare,
  Sparkles,
  Tablet,
  CheckCircle2,
  ExternalLink,
  PenTool,
  ShieldCheck,
  Download,
} from 'lucide-react';

interface IPadInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function IPadInstallModal({ isOpen, onClose }: IPadInstallModalProps) {
  const [activeTab, setActiveTab] = useState<'safari' | 'pencil' | 'offline'>('safari');

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200 select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-500 p-6 text-white shrink-0">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <Tablet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">iPad'e Yükleme Rehberi</h2>
              <p className="text-xs text-blue-100 font-medium">
                Apple iPad & Safari PWA Kurulumu ve Apple Pencil İpuçları
              </p>
            </div>
          </div>

          {/* Navigation tabs */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveTab('safari')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'safari'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'bg-white/15 text-white hover:bg-white/25'
              }`}
            >
              1. Safari'den Yükle
            </button>
            <button
              onClick={() => setActiveTab('pencil')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'pencil'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'bg-white/15 text-white hover:bg-white/25'
              }`}
            >
              2. Apple Pencil & Avuç İçi
            </button>
            <button
              onClick={() => setActiveTab('offline')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'offline'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'bg-white/15 text-white hover:bg-white/25'
              }`}
            >
              3. Çevrimdışı Çalışma
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-700 text-sm">
          {activeTab === 'safari' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Bu uygulama bir <strong className="text-slate-800">Progressive Web App (PWA)</strong> olarak kodlanmıştır. App Store'a gerek kalmadan doğrudan Safari üzerinden iPad ana ekranınıza bir yerel uygulama gibi kurulabilir:
              </p>

              {/* Step 1 */}
              <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    Safari ile Açın
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    iPad'inizde Safari tarayıcısını açıp bu uygulamanın bağlantısını yükleyin. (Apple kısıtlamaları nedeniyle kurulum Safari üzerinden yapılmalıdır).
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-blue-50/70 border border-blue-200/80">
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-blue-950 text-xs flex items-center gap-1.5">
                    <Share className="w-3.5 h-3.5 text-blue-600" />
                    <span>Paylaş Simgesine Dokunun</span>
                  </h4>
                  <p className="text-xs text-blue-900/80 leading-relaxed">
                    Safari'nin üst çubuğundaki (veya iPadOS ekranının sağ üstündeki) <strong className="text-blue-700">"Paylaş" (Share)</strong> simgesine dokunun.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-start gap-3.5 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    <PlusSquare className="w-3.5 h-3.5 text-slate-700" />
                    <span>"Ana Ekrana Ekle" Seçeneğine Dokunun</span>
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Açılan menüde aşağı kaydırarak <strong className="text-slate-800">"Ana Ekrana Ekle" (Add to Home Screen)</strong> butonuna dokunun ve sağ üstteki <strong>"Ekle"</strong>ye basın.
                  </p>
                </div>
              </div>

              {/* Step 4: Result */}
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-900 space-y-1">
                  <p className="font-bold">Artık Tam Ekran iPad Uygulaması!</p>
                  <p className="text-emerald-800/90 leading-relaxed">
                    Ana ekranınızdaki <strong>Notlarım</strong> simgesine dokunduğunuzda Safari arayüzü gizlenir; GoodNotes veya Notlar gibi tam ekran, pencereli ve sıfır gecikmeli çalışır.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'pencil' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-950 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-indigo-900">
                  <PenTool className="w-4 h-4 text-indigo-600" />
                  <span>Apple Pencil & Stylus Optimizasyonu</span>
                </div>
                <p className="leading-relaxed text-indigo-900/80">
                  Uygulamamız Apple Pencil 1, 2, USB-C ve Pro modellerini donanım seviyesinde destekler:
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-xs text-slate-900">Otomatik Avuç İçi Koruması (Palm Rejection)</h5>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Apple Pencil ile yazarken elinizi iPad ekranına rahatça yaslayabilirsiniz. Avucunuz algılandığında çizim yapmaz; yalnızca Apple Pencil ucu çizer.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-xs text-slate-900">Basınç & Eğim Duyarlılığı (Pressure Sensitivity)</h5>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Apple Pencil'ı ekrana daha sert bastırdığınızda çizgi kalınlaşır, hafif dokunduğunuzda incelir. Dolmakalem ve fırça uçlarında hat sanatı ve imza estetiği sağlar.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-xs text-slate-900">120 Hz ProMotion Akıcılığı</h5>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Doğrudan donanım ivmeli Canvas API ve çift tamponlu senkron pipeline ile kalem ile çizgi arasında sıfır gecikme elde edilir.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'offline' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-blue-600" />
                  <span>İnternetsiz (Çevrimdışı / Offline) Kullanım</span>
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Tüm defterleriniz, sayfalarınız, çizimleriniz ve ses kayıtlarınız iPad'inizin yerel <strong className="text-slate-800">IndexedDB</strong> veritabanında saklanır. Uçakta, trende veya internet olmayan sınıflarda kesintisiz çalışır.
                </p>
              </div>

              <div className="p-4 bg-blue-50/80 rounded-2xl border border-blue-200 text-xs text-blue-900 space-y-2">
                <h4 className="font-bold flex items-center gap-1.5">
                  <span>Yedekleme Güvenliği</span>
                </h4>
                <p className="leading-relaxed text-blue-900/80">
                  İstediğiniz zaman ana ekrandaki veya defter içindeki <strong>"Yedek Al (.notes.json)"</strong> butonu ile tüm notlarınızı tek bir dosya olarak indirebilir, iCloud Drive, Google Drive veya USB belleğinize aktarabilirsiniz.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/80 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/25 active:scale-97 transition-all cursor-pointer"
          >
            Anladım, Kapat
          </button>
        </div>
      </div>
    </div>
  );
}
