import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Check, Plus, Trash2, Sliders, Palette, RotateCcw } from 'lucide-react';

interface ColorPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentColor: string;
  onSelectColor: (color: string) => void;
  recentColors: string[];
}

// Curated aesthetic palette collections (100% in-app, Apple Notes & GoodNotes inspired)
const PALETTE_COLLECTIONS = {
  ink: {
    title: 'Mürekkep & Not',
    colors: [
      '#1C1C1E', '#007AFF', '#FF3B30', '#34C759', '#FF9500', '#5856D6',
      '#8E8E93', '#000000', '#AF52DE', '#5AC8FA', '#FFCC00', '#32D74B',
    ],
  },
  pastel: {
    title: 'Pastel & Özet',
    colors: [
      '#74B9FF', '#81ECEC', '#55EFC4', '#FFEAA7', '#FAB1A0', '#FD79A8',
      '#A29BFE', '#B8E986', '#F8E71C', '#E17055', '#4A90E2', '#50E3C2',
    ],
  },
  neon: {
    title: 'Neon & Fosforlu',
    colors: [
      '#FFD60A', '#30D158', '#64D2FF', '#FF375F', '#BF5AF2', '#FF9F0A',
      '#00E676', '#FF5252', '#40C4FF', '#38EF7D', '#FFFF00', '#FF007F',
    ],
  },
  earth: {
    title: 'Toprak & Doğal',
    colors: [
      '#8B4513', '#D2691E', '#CD853F', '#556B2F', '#2E8B57', '#4682B4',
      '#708090', '#A0522D', '#800000', '#2F4F4F', '#D4A373', '#CCD5AE',
    ],
  },
};

// HSV to RGB conversion
function hsvToRgb(h: number, s: number, v: number): { r: number; g: number; b: number } {
  const normS = Math.max(0, Math.min(100, s)) / 100;
  const normV = Math.max(0, Math.min(100, v)) / 100;
  const c = normV * normS;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = normV - c;
  let r = 0, g = 0, b = 0;

  if (0 <= h && h < 60) {
    r = c; g = x; b = 0;
  } else if (60 <= h && h < 120) {
    r = x; g = c; b = 0;
  } else if (120 <= h && h < 180) {
    r = 0; g = c; b = x;
  } else if (180 <= h && h < 240) {
    r = 0; g = x; b = c;
  } else if (240 <= h && h < 300) {
    r = x; g = 0; b = c;
  } else if (300 <= h && h <= 360) {
    r = c; g = 0; b = x;
  }

  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((b + m) * 255),
  };
}

// RGB to HEX conversion
function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`.toUpperCase();
}

// HEX to HSV conversion
function hexToHsv(hex: string): { h: number; s: number; v: number } {
  let c = hex.replace('#', '').trim();
  if (c.length === 3) {
    c = c.split('').map((x) => x + x).join('');
  }
  const num = parseInt(c, 16);
  if (isNaN(num)) return { h: 210, s: 80, v: 90 };

  const r = ((num >> 16) & 255) / 255;
  const g = ((num >> 8) & 255) / 255;
  const b = (num & 255) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  const s = max === 0 ? 0 : d / max;
  const v = max;

  if (max !== min) {
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h = Math.round(h * 60);
  }

  return {
    h: (h + 360) % 360,
    s: Math.round(s * 100),
    v: Math.round(v * 100),
  };
}

export function ColorPickerModal({
  isOpen,
  onClose,
  currentColor,
  onSelectColor,
  recentColors,
}: ColorPickerModalProps) {
  // Working color (uncommitted until applied or instant preview)
  const [selectedHex, setSelectedHex] = useState(currentColor);
  const [hsv, setHsv] = useState(() => hexToHsv(currentColor));
  const [activeTab, setActiveTab] = useState<'custom' | 'palettes'>('custom');

  // Custom user-saved palette slots in localStorage
  const [savedColors, setSavedColors] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('notesApp_user_saved_colors');
      return stored ? JSON.parse(stored) : ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];
    } catch {
      return ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];
    }
  });

  const satValBoxRef = useRef<HTMLDivElement>(null);
  const isDraggingSatVal = useRef(false);
  const hueBarRef = useRef<HTMLDivElement>(null);
  const isDraggingHue = useRef(false);

  useEffect(() => {
    setSelectedHex(currentColor);
    setHsv(hexToHsv(currentColor));
  }, [currentColor, isOpen]);

  if (!isOpen) return null;

  // Update color from HSV
  const updateHsv = (newHsv: { h: number; s: number; v: number }) => {
    setHsv(newHsv);
    const rgb = hsvToRgb(newHsv.h, newHsv.s, newHsv.v);
    const hex = rgbToHex(rgb.r, rgb.g, rgb.b);
    setSelectedHex(hex);
  };

  // 2D Saturation-Value box drag calculation
  const handleSatValPointer = (clientX: number, clientY: number) => {
    if (!satValBoxRef.current) return;
    const rect = satValBoxRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
    const y = Math.max(0, Math.min(rect.height, clientY - rect.top));

    const s = Math.round((x / rect.width) * 100);
    const v = Math.round((1 - y / rect.height) * 100);

    updateHsv({ ...hsv, s, v });
  };

  const handleSatValDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingSatVal.current = true;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    handleSatValPointer(e.clientX, e.clientY);
  };

  const handleSatValMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingSatVal.current) return;
    handleSatValPointer(e.clientX, e.clientY);
  };

  const handleSatValUp = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingSatVal.current = false;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Hue Bar drag calculation
  const handleHuePointer = (clientX: number) => {
    if (!hueBarRef.current) return;
    const rect = hueBarRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
    const h = Math.round((x / rect.width) * 360);
    updateHsv({ ...hsv, h });
  };

  const handleHueDown = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingHue.current = true;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    handleHuePointer(e.clientX);
  };

  const handleHueMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingHue.current) return;
    handleHuePointer(e.clientX);
  };

  const handleHueUp = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingHue.current = false;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Handle direct Hex input
  const handleHexInput = (val: string) => {
    setSelectedHex(val);
    if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
      setHsv(hexToHsv(val));
    }
  };

  // Pick a preset color
  const handlePickPreset = (hex: string) => {
    setSelectedHex(hex);
    setHsv(hexToHsv(hex));
  };

  // Apply selected color & close
  const handleApply = () => {
    onSelectColor(selectedHex);
    onClose();
  };

  // Save current color to favorites
  const handleSaveToFavorites = () => {
    const formatted = selectedHex.toUpperCase();
    if (!savedColors.includes(formatted)) {
      const updated = [formatted, ...savedColors].slice(0, 18);
      setSavedColors(updated);
      try {
        localStorage.setItem('notesApp_user_saved_colors', JSON.stringify(updated));
      } catch {
        // ignore
      }
    }
  };

  const handleRemoveFavorite = (colorToRemove: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedColors.filter((c) => c !== colorToRemove);
    setSavedColors(updated);
    try {
      localStorage.setItem('notesApp_user_saved_colors', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const rgb = hsvToRgb(hsv.h, hsv.s, hsv.v);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150 select-none">
      {/* Click outside to close (without committing unapplied changes) */}
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-sm sm:max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col max-h-[85vh] overflow-hidden z-10 animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="shrink-0 px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div
              className="w-5 h-5 rounded-full border border-black/15 shadow-xs transition-colors"
              style={{ backgroundColor: selectedHex }}
            />
            <h3 className="text-base font-bold text-slate-800">Renk Seçici</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="shrink-0 px-5 pt-3 pb-2 flex gap-2 border-b border-slate-100 bg-white">
          <button
            onClick={() => setActiveTab('custom')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'custom'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Özel Ton & Renk Çarkı</span>
          </button>
          <button
            onClick={() => setActiveTab('palettes')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'palettes'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Hazır Paletler</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 no-scrollbar">
          {activeTab === 'custom' ? (
            <>
              {/* 1. App-Native 2D Saturation-Brightness Pad (Pure in-app canvas gradient) */}
              <div>
                <div
                  ref={satValBoxRef}
                  onPointerDown={handleSatValDown}
                  onPointerMove={handleSatValMove}
                  onPointerUp={handleSatValUp}
                  style={{
                    backgroundColor: `hsl(${hsv.h}, 100%, 50%)`,
                  }}
                  className="relative w-full h-44 rounded-2xl shadow-inner cursor-crosshair overflow-hidden touch-none border border-black/10"
                >
                  {/* Horizontal White-to-Transparent Gradient */}
                  <div className="absolute inset-0 bg-gradient-to-r from-white to-transparent pointer-events-none" />
                  {/* Vertical Transparent-to-Black Gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent pointer-events-none" />

                  {/* Touch Target Cursor Thumb */}
                  <div
                    className="absolute w-6 h-6 rounded-full border-2 border-white shadow-md -translate-x-1/2 -translate-y-1/2 pointer-events-none ring-1 ring-black/40"
                    style={{
                      left: `${hsv.s}%`,
                      top: `${100 - hsv.v}%`,
                      backgroundColor: selectedHex,
                    }}
                  />
                </div>
              </div>

              {/* 2. Rainbow Hue Bar */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <span>Renk Tonu (Spektrum)</span>
                  <span className="font-mono text-blue-600">{hsv.h}°</span>
                </div>
                <div
                  ref={hueBarRef}
                  onPointerDown={handleHueDown}
                  onPointerMove={handleHueMove}
                  onPointerUp={handleHueUp}
                  className="relative w-full h-6 rounded-xl cursor-pointer shadow-inner touch-none border border-black/10"
                  style={{
                    background:
                      'linear-gradient(to right, #ff0000 0%, #ffff00 17%, #00ff00 33%, #00ffff 50%, #0000ff 67%, #ff00ff 83%, #ff0000 100%)',
                  }}
                >
                  {/* Hue Thumb Cursor */}
                  <div
                    className="absolute top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-white border-2 border-slate-700 shadow-md -translate-x-1/2 pointer-events-none"
                    style={{
                      left: `${(hsv.h / 360) * 100}%`,
                    }}
                  />
                </div>
              </div>

              {/* 3. RGB & HEX Badges (Readout and Fine Adjustment) */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
                  <span className="px-1.5 py-0.5 bg-slate-200/70 rounded-md font-mono text-[11px]">R:{rgb.r}</span>
                  <span className="px-1.5 py-0.5 bg-slate-200/70 rounded-md font-mono text-[11px]">G:{rgb.g}</span>
                  <span className="px-1.5 py-0.5 bg-slate-200/70 rounded-md font-mono text-[11px]">B:{rgb.b}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-slate-400">HEX:</span>
                  <input
                    type="text"
                    value={selectedHex}
                    onChange={(e) => handleHexInput(e.target.value)}
                    maxLength={7}
                    className="w-22 px-2 py-1 text-xs font-mono font-bold uppercase bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* 4. Favorilerim & Özel Paletim */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Özel Renklerim & Favoriler
                  </span>
                  <button
                    onClick={handleSaveToFavorites}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer bg-blue-50 px-2.5 py-1 rounded-xl border border-blue-200/60 transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Bu Rengi Ekle</span>
                  </button>
                </div>

                <div className="flex gap-2 flex-wrap min-h-[42px] p-2 bg-slate-50 rounded-2xl border border-slate-200/60">
                  {savedColors.map((sc, idx) => (
                    <div key={`fav_${idx}`} className="relative group">
                      <button
                        onClick={() => handlePickPreset(sc)}
                        style={{ backgroundColor: sc }}
                        className="w-8 h-8 rounded-xl flex items-center justify-center shadow-xs border border-black/10 hover:scale-110 active:scale-95 transition-transform cursor-pointer"
                        title={sc}
                      >
                        {selectedHex.toUpperCase() === sc.toUpperCase() && (
                          <Check className="w-3.5 h-3.5 text-white drop-shadow-md stroke-[3]" />
                        )}
                      </button>
                      <button
                        onClick={(e) => handleRemoveFavorite(sc, e)}
                        className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-xs"
                        title="Rengi Sil"
                      >
                        <Trash2 className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Categorized Palette Collections */}
              {Object.entries(PALETTE_COLLECTIONS).map(([key, col]) => (
                <div key={key}>
                  <span className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                    {col.title}
                  </span>
                  <div className="grid grid-cols-6 gap-2.5">
                    {col.colors.map((c) => (
                      <button
                        key={c}
                        onClick={() => handlePickPreset(c)}
                        style={{ backgroundColor: c }}
                        className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-xs hover:scale-110 active:scale-95 transition-transform cursor-pointer border border-black/10"
                      >
                        {selectedHex.toLowerCase() === c.toLowerCase() && (
                          <Check className="w-4 h-4 text-white drop-shadow-md stroke-[3]" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Son Kullanılanlar */}
          {recentColors.length > 0 && (
            <div className="pt-2 border-t border-slate-100">
              <span className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Son Kullanılanlar
              </span>
              <div className="flex gap-2 flex-wrap">
                {recentColors.map((c, idx) => (
                  <button
                    key={`rec_${c}_${idx}`}
                    onClick={() => handlePickPreset(c)}
                    style={{ backgroundColor: c }}
                    className="w-8 h-8 rounded-xl flex items-center justify-center shadow-xs hover:scale-110 active:scale-95 transition-transform cursor-pointer border border-black/10"
                  >
                    {selectedHex.toLowerCase() === c.toLowerCase() && (
                      <Check className="w-3.5 h-3.5 text-white drop-shadow-md stroke-[3]" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Sticky Footer (Always Visible at Bottom, Zero Cutoff) */}
        <div className="shrink-0 px-5 py-3 border-t border-slate-100 bg-slate-50/90 flex items-center justify-between gap-3">
          {/* Compare Previous vs New */}
          <div className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-xl border border-slate-300 shadow-inner"
              style={{ backgroundColor: currentColor }}
              title="Önceki Renk"
            />
            <span className="text-slate-400 text-xs font-bold">→</span>
            <div
              className="w-9 h-9 rounded-xl border border-blue-500 shadow-sm ring-2 ring-blue-500/20"
              style={{ backgroundColor: selectedHex }}
              title="Yeni Seçilen Renk"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs font-bold rounded-xl hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              Vazgeç
            </button>
            <button
              onClick={handleApply}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5 stroke-[3]" />
              <span>Uygula</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
