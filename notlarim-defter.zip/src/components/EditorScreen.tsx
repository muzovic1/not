import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  Notebook,
  PageData,
  ActiveTool,
  ToolSettingsMap,
  ViewTransform,
  CanvasItem,
  Point,
  FreehandStroke,
  ShapeStroke,
  TextStroke,
  BoundingBox,
  PageStyle,
  InteractiveRuler,
  InteractiveCompass,
  CustomPaperConfig,
  AudioRecording,
} from '../types.ts';
import {
  drawBackgroundCanvas,
  drawMultiplePagesBackground,
  drawItem,
  drawLaserTrail,
  drawCompassOverlay,
} from '../utils/canvasRenderer.ts';
import {
  getItemBoundingBox,
  pointInPolygon,
  recognizeGeometricShape,
  distanceToSegment,
  eraseAtPoint,
} from '../utils/geometry.ts';
import {
  importPDFFile,
  exportNotebookToPDF,
  exportSinglePageImage,
  copyPageImageToClipboard,
} from '../utils/pdf.ts';
import { PagesSidebar } from './PagesSidebar.tsx';
import { ColorPickerModal } from './ColorPickerModal.tsx';
import { StickerModal } from './StickerModal.tsx';
import { QuickSettingsPopover } from './QuickSettingsPopover.tsx';
import { IPadInstallModal } from './IPadInstallModal.tsx';
import { AudioRecorderBar } from './AudioRecorderBar.tsx';
import { FunctionPlotterModal } from './FunctionPlotterModal.tsx';
import { CustomPaperModal } from './CustomPaperModal.tsx';
import { ZoomWritingBox } from './ZoomWritingBox.tsx';
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Undo2,
  Redo2,
  Layers,
  Share2,
  Hand,
  PenTool,
  Highlighter,
  Sparkles,
  Eraser,
  Scissors,
  Square,
  Circle,
  Triangle,
  Minus,
  MoveRight,
  Type,
  Image as ImageIcon,
  Smile,
  FileUp,
  Settings2,
  CloudCheck,
  Ruler,
  Compass,
  RotateCw,
  Copy,
  FileDown,
  Check,
  Grid,
  Star,
  Mic,
  ZoomIn,
  Tablet,
  Calculator,
  BookOpen,
  X,
  Plus,
  ScrollText,
} from 'lucide-react';

interface EditorScreenProps {
  notebook: Notebook;
  pages: PageData[];
  currentPageIndex: number;
  onUpdateNotebookTitle: (newTitle: string) => void;
  onUpdatePages: (newPages: PageData[]) => void;
  onSelectPageIndex: (index: number) => void;
  onBackToHome: () => void;
}

const DEFAULT_TOOLS: ToolSettingsMap = {
  hand: { size: 4, opacity: 1, color: '#1c1c1e' },
  pen: { size: 4, opacity: 1, color: '#1c1c1e', lineCap: 'round', smartShape: false, penType: 'standard', pressureSensitivity: true, drawAndHold: true },
  highlighter: { size: 18, opacity: 0.45, color: '#ffcc00', lineCap: 'butt' },
  laser: { size: 6, opacity: 1, color: '#ff3b30', lineCap: 'round' },
  eraser: { size: 14, opacity: 1, color: '#000000', lineCap: 'round' },
  'stroke-eraser': { size: 10, opacity: 1, color: '#000000', lineCap: 'round', eraseHighlighterOnly: false },
  lasso: { size: 3, opacity: 1, color: '#007aff', lineCap: 'round' },
  rect: { size: 4, opacity: 1, color: '#007aff', lineCap: 'round', fill: false },
  ellipse: { size: 4, opacity: 1, color: '#007aff', lineCap: 'round', fill: false },
  triangle: { size: 4, opacity: 1, color: '#007aff', lineCap: 'round', fill: false },
  line: { size: 4, opacity: 1, color: '#007aff', lineCap: 'round' },
  arrow: { size: 4, opacity: 1, color: '#007aff', lineCap: 'round' },
  'right-angle': { size: 4, opacity: 1, color: '#007aff', lineCap: 'round' },
  'angle-arc': { size: 3, opacity: 1, color: '#ff9500', lineCap: 'round' },
  'coord-axes': { size: 3, opacity: 1, color: '#5856d6', lineCap: 'round' },
  text: { size: 22, opacity: 1, color: '#1c1c1e', lineCap: 'round' },
  compass: { size: 3, opacity: 1, color: '#007aff', lineCap: 'round' },
};

export function EditorScreen({
  notebook,
  pages,
  currentPageIndex,
  onUpdateNotebookTitle,
  onUpdatePages,
  onSelectPageIndex,
  onBackToHome,
}: EditorScreenProps) {
  const [tools, setTools] = useState<ToolSettingsMap>(() => {
    try {
      const saved = localStorage.getItem('notesApp_toolSettings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.pen && parsed.pen.smartShape === undefined) {
          parsed.pen.smartShape = false;
        }
        return { ...DEFAULT_TOOLS, ...parsed };
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_TOOLS;
  });

  const [activeTool, setActiveTool] = useState<ActiveTool>('pen');
  const [palmRejection, setPalmRejection] = useState<boolean>(true);
  const [recentColors, setRecentColors] = useState<string[]>([
    '#1c1c1e', '#007aff', '#ff3b30', '#ffcc00', '#34c759', '#af52de',
  ]);

  // History stacks for Undo / Redo
  const [undoStack, setUndoStack] = useState<CanvasItem[][]>([]);
  const [redoStack, setRedoStack] = useState<CanvasItem[][]>([]);

  // View Pan & Zoom (State + Real-time Ref for 120fps latency-free touch pinch)
  const [view, setView] = useState<ViewTransform>({ scale: 1, offsetX: 0, offsetY: 0 });
  const viewRef = useRef<ViewTransform>(view);

  // Interactive Ruler & Protractor state
  const [ruler, setRuler] = useState<InteractiveRuler>({
    visible: false,
    x: 500,
    y: 700,
    angle: 0,
    length: 520,
    mode: 'ruler',
  });

  // Interactive Virtual Compass (Pergel)
  const [compass, setCompass] = useState<InteractiveCompass>({
    visible: false,
    x: 520,
    y: 560,
    radius: 160,
    angle: 35,
  });

  // Shape Inspector & Measurement Mode (Otomatik Kenar ve Açı Ölçümü)
  const [isInspectorOpen, setIsInspectorOpen] = useState(false);

  // Modals & Panels
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isColorPickerOpen, setIsColorPickerOpen] = useState(false);
  const [isStickerModalOpen, setIsStickerModalOpen] = useState(false);
  const [isQuickSettingsOpen, setIsQuickSettingsOpen] = useState(false);
  const [isShapeMenuOpen, setIsShapeMenuOpen] = useState(false);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [isFunctionPlotterOpen, setIsFunctionPlotterOpen] = useState(false);
  const [isCustomPaperOpen, setIsCustomPaperOpen] = useState(false);
  const [isZoomBoxOpen, setIsZoomBoxOpen] = useState(false);
  const [zoomFocusPos, setZoomFocusPos] = useState<Point>({ x: 80, y: 140 });
  const [isAudioBarOpen, setIsAudioBarOpen] = useState(false);
  const [isDualPage, setIsDualPage] = useState(false);
  const [isIPadGuideOpen, setIsIPadGuideOpen] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState<string | null>(null);
  const [toastNotice, setToastNotice] = useState<string | null>(null);

  // Page Scroll Mode: 'single' (traditional page-by-page) or 'vertical' (continuous vertical flow)
  const [scrollMode, setScrollMode] = useState<'single' | 'vertical'>(() => {
    try {
      return (localStorage.getItem('notesApp_scrollMode') as 'single' | 'vertical') || 'single';
    } catch {
      return 'single';
    }
  });

  const PAGE_GAP = 36;
  const pageOffsets = useMemo(() => {
    let currentY = 0;
    return pages.map((p) => {
      const top = currentY;
      currentY += p.height + PAGE_GAP;
      return top;
    });
  }, [pages]);

  const findPageIndexAtY = useCallback(
    (worldY: number): number => {
      for (let i = 0; i < pages.length; i++) {
        const top = pageOffsets[i];
        const bottom = top + pages[i].height;
        if (worldY >= top && worldY <= bottom + PAGE_GAP) {
          return i;
        }
      }
      if (worldY < 0) return 0;
      return Math.max(0, pages.length - 1);
    },
    [pages, pageOffsets]
  );

  // Lasso & Selection State
  const [selectedIndices, setSelectedIndices] = useState<number[]>([]);
  const [selectionBox, setSelectionBox] = useState<BoundingBox | null>(null);
  const [clipboard, setClipboard] = useState<CanvasItem[]>([]);

  // Text Editing Overlay
  const [editingTextIndex, setEditingTextIndex] = useState<number | null>(null);
  const [editingTextPos, setEditingTextPos] = useState<Point | null>(null);
  const [editingTextValue, setEditingTextValue] = useState('');

  // Refs
  const wrapRef = useRef<HTMLDivElement>(null);
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  // Çizgi çekerken önceden çizilmiş öğeler tek resim olarak saklanır (her karede yüzlerce öğeyi baştan çizmemek için)
  const layerCacheRef = useRef<{ canvas: HTMLCanvasElement | null; key: string; items: any }>({
    canvas: null,
    key: '',
    items: null,
  });
  // Arka plan (PDF/kâğıt) sadece görünüm veya sayfa değişince yeniden çizilir; çizgi çekerken çizilmez
  const bgCacheRef = useRef<{ key: string; pages: any; page: any; offsets: any; dirty: boolean }>({
    key: '',
    pages: null,
    page: null,
    offsets: null,
    dirty: true,
  });
  const strokeCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pdfInputRef = useRef<HTMLInputElement>(null);

  const currentPage = pages[currentPageIndex] || pages[0];

  // REAL-TIME LOCAL STROKES REF: Eliminates all asynchronous state flicker/disappearance
  const strokesRef = useRef<CanvasItem[]>(
    currentPage
      ? currentPage.strokes.filter((s) => s.type !== 'stroke' || (s.tool !== 'eraser' && (s.tool as any) !== 'stroke-eraser'))
      : []
  );

  useEffect(() => {
    if (currentPage) {
      // Purge any legacy destination-out eraser strokes
      strokesRef.current = currentPage.strokes.filter(
        (s) => s.type !== 'stroke' || (s.tool !== 'eraser' && (s.tool as any) !== 'stroke-eraser')
      );
      requestRender();
    }
  }, [currentPageIndex, pages]);

  const showToast = useCallback((msg: string) => {
    setToastNotice(msg);
    setTimeout(() => {
      setToastNotice((prev) => (prev === msg ? null : prev));
    }, 2400);
  }, []);

  // Long press timer for tool-specific settings popup
  const longPressTimerRef = useRef<number | null>(null);
  const startLongPress = (toolName: ActiveTool) => {
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = window.setTimeout(() => {
      setActiveTool(toolName);
      setIsQuickSettingsOpen(true);
      longPressTimerRef.current = null;
    }, 420);
  };
  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  // Ephemeral interactive states during pointer interaction
  const liveRef = useRef<{
    currentStroke: FreehandStroke | null;
    shapePreview: ShapeStroke | null;
    lassoPoints: Point[] | null;
    laserStrokes: (FreehandStroke & { createdAt: number })[];
    hoverPos: Point | null;
    dragSelection: {
      startWorld: Point;
      origItems: CanvasItem[];
      indices: number[];
    } | null;
    middlePan: { startX: number; startY: number; ox: number; oy: number } | null;
    singleFingerPan: { startX: number; startY: number; ox: number; oy: number } | null;
    rulerDrag: { startX: number; startY: number; origRx: number; origRy: number } | null;
    rulerRotate: { startAngle: number; initialRulerAngle: number; cx: number; cy: number } | null;
    compassDrag: {
      type: 'needle' | 'pencil';
      startAngle: number;
      startRadius: number;
      cx: number;
      cy: number;
      startX: number;
      startY: number;
    } | null;
    pointers: Map<number, { x: number; y: number; type: string }>;
    isPinching: boolean;
    isErasing: boolean;
    pinchEndedAt: number;
    hasUsedPen: boolean;
    pinch: {
      dist: number;
      scale: number;
      centerWorld: Point;
      centerScreen: Point;
    } | null;
    rafId: number | null;
  }>({
    currentStroke: null,
    shapePreview: null,
    lassoPoints: null,
    laserStrokes: [],
    hoverPos: null,
    dragSelection: null,
    middlePan: null,
    singleFingerPan: null,
    rulerDrag: null,
    rulerRotate: null,
    compassDrag: null,
    pointers: new Map(),
    isPinching: false,
    isErasing: false,
    pinchEndedAt: 0,
    hasUsedPen: false,
    pinch: null,
    rafId: null,
  });

  // Save tool settings to localStorage
  const updateToolSettings = (newSettings: Partial<ToolSettingsMap[ActiveTool]>) => {
    setTools((prev) => {
      const next = {
        ...prev,
        [activeTool]: { ...prev[activeTool], ...newSettings },
      };
      try {
        localStorage.setItem('notesApp_toolSettings', JSON.stringify(next));
      } catch (e) {
        // ignore
      }
      return next;
    });
  };

  const handleSelectColor = (color: string) => {
    let targetTool = activeTool;
    if (targetTool === 'eraser' || targetTool === 'stroke-eraser' || targetTool === 'lasso' || targetTool === 'hand') {
      targetTool = 'pen';
    }
    setTools((prev) => ({
      ...prev,
      [targetTool]: { ...prev[targetTool], color },
    }));
    setRecentColors((prev) => [color, ...prev.filter((c) => c !== color)].slice(0, 8));
    setIsColorPickerOpen(false);
    showToast('Renk güncellendi');
  };

  // Push current page state to undo stack before mutation
  const pushUndo = useCallback(() => {
    if (!currentPage) return;
    setUndoStack((prev) => [...prev.slice(-30), strokesRef.current.map((s) => ({ ...s }))]);
    setRedoStack([]);
  }, [currentPage]);

  // Quick Add Page (Top bar or canvas action)
  const handleQuickAddPage = useCallback(() => {
    pushUndo();
    const newPage: PageData = {
      id: `p_${Date.now()}_add`,
      type: currentPage.type,
      bg: currentPage.bg,
      width: currentPage.width,
      height: currentPage.height,
      pdfDataUrl: null,
      strokes: [],
    };
    const insertIdx = scrollMode === 'vertical' ? pages.length : currentPageIndex + 1;
    const updatedPages = [...pages];
    updatedPages.splice(insertIdx, 0, newPage);
    onUpdatePages(updatedPages);
    onSelectPageIndex(insertIdx);

    if (scrollMode === 'vertical') {
      setTimeout(() => {
        if (!wrapRef.current) return;
        const wrap = wrapRef.current.getBoundingClientRect();
        const targetTop =
          pageOffsets[insertIdx] ?? pageOffsets[pageOffsets.length - 1] + currentPage.height + PAGE_GAP;
        const targetOffsetY = wrap.height / 2 - (targetTop + newPage.height / 2) * viewRef.current.scale;
        const nextView = { ...viewRef.current, offsetY: targetOffsetY };
        viewRef.current = nextView;
        setView(nextView);
        requestRender();
      }, 60);
    }
    showToast(`⚡ Yeni sayfa eklendi (Sayfa ${insertIdx + 1})`);
  }, [
    currentPage,
    scrollMode,
    pages,
    currentPageIndex,
    onUpdatePages,
    onSelectPageIndex,
    pushUndo,
    pageOffsets,
    PAGE_GAP,
    showToast,
  ]);

  const handleUndo = useCallback(() => {
    if (undoStack.length === 0 || !currentPage) return;
    const previous = undoStack[undoStack.length - 1];
    setUndoStack((prev) => prev.slice(0, -1));
    setRedoStack((prev) => [...prev, strokesRef.current.map((s) => ({ ...s }))]);

    strokesRef.current = previous;
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, strokes: previous };
    onUpdatePages(updatedPages);
    setSelectedIndices([]);
    setSelectionBox(null);
    requestRender();
  }, [undoStack, currentPage, pages, currentPageIndex, onUpdatePages]);

  const handleRedo = useCallback(() => {
    if (redoStack.length === 0 || !currentPage) return;
    const next = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, -1));
    setUndoStack((prev) => [...prev, strokesRef.current.map((s) => ({ ...s }))]);

    strokesRef.current = next;
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, strokes: next };
    onUpdatePages(updatedPages);
    setSelectedIndices([]);
    setSelectionBox(null);
    requestRender();
  }, [redoStack, currentPage, pages, currentPageIndex, onUpdatePages]);

  // Fit page in viewport
  const fitPage = useCallback(() => {
    if (!wrapRef.current || !currentPage) return;
    const wrap = wrapRef.current.getBoundingClientRect();
    const margin = 28;
    const scaleX = (wrap.width - margin * 2) / currentPage.width;
    const scaleY = (wrap.height - margin * 2) / currentPage.height;
    const scale = Math.min(scaleX, scaleY, 1.25);
    const offsetX = (wrap.width - currentPage.width * scale) / 2;
    const offsetY = (wrap.height - currentPage.height * scale) / 2;
    const nextView = { scale, offsetX, offsetY };
    viewRef.current = nextView;
    setView(nextView);
  }, [currentPage]);

  useEffect(() => {
    fitPage();
  }, [currentPageIndex]);

  // Coordinate transforms (always uses latest viewRef with zero lag)
  const toWorld = useCallback((clientX: number, clientY: number): Point => {
    if (!strokeCanvasRef.current) return { x: 0, y: 0 };
    const rect = strokeCanvasRef.current.getBoundingClientRect();
    const v = viewRef.current;
    return {
      x: (clientX - rect.left - v.offsetX) / v.scale,
      y: (clientY - rect.top - v.offsetY) / v.scale,
    };
  }, []);

  // Ruler snapping algorithm
  const snapToRulerIfNear = useCallback(
    (rawWorld: Point): Point => {
      if (!ruler.visible) return rawWorld;

      const rad = (ruler.angle * Math.PI) / 180;
      const ux = Math.cos(rad);
      const uy = Math.sin(rad);
      const nx = -Math.sin(rad);
      const ny = Math.cos(rad);

      if (ruler.mode === 'ruler') {
        // Top edge of the ruler
        const halfLen = ruler.length / 2;
        const edgeOffset = -32; // height / 2 = 32
        const edgeCx = ruler.x + nx * edgeOffset;
        const edgeCy = ruler.y + ny * edgeOffset;

        const p1 = { x: edgeCx - ux * halfLen, y: edgeCy - uy * halfLen };
        const p2 = { x: edgeCx + ux * halfLen, y: edgeCy + uy * halfLen };

        const d = distanceToSegment(rawWorld, p1, p2);
        if (d < 38) {
          // Project rawWorld onto segment p1-p2
          const segLen2 = (p2.x - p1.x) ** 2 + (p2.y - p1.y) ** 2;
          let t = ((rawWorld.x - p1.x) * (p2.x - p1.x) + (rawWorld.y - p1.y) * (p2.y - p1.y)) / segLen2;
          t = Math.max(0, Math.min(1, t));
          return {
            x: p1.x + t * (p2.x - p1.x),
            y: p1.y + t * (p2.y - p1.y),
          };
        }
      } else {
        // Protractor baseline & circular edge
        const radius = ruler.length * 0.45;
        // Check baseline
        const b1 = { x: ruler.x - ux * radius, y: ruler.y - uy * radius };
        const b2 = { x: ruler.x + ux * radius, y: ruler.y + uy * radius };
        const dBase = distanceToSegment(rawWorld, b1, b2);
        if (dBase < 32) {
          const segLen2 = (b2.x - b1.x) ** 2 + (b2.y - b1.y) ** 2;
          let t = ((rawWorld.x - b1.x) * (b2.x - b1.x) + (rawWorld.y - b1.y) * (b2.y - b1.y)) / segLen2;
          t = Math.max(0, Math.min(1, t));
          return {
            x: b1.x + t * (b2.x - b1.x),
            y: b1.y + t * (b2.y - b1.y),
          };
        }

        // Check semicircle arc
        const distFromCenter = Math.hypot(rawWorld.x - ruler.x, rawWorld.y - ruler.y);
        if (Math.abs(distFromCenter - radius) < 32) {
          const angle = Math.atan2(rawWorld.y - ruler.y, rawWorld.x - ruler.x);
          return {
            x: ruler.x + radius * Math.cos(angle),
            y: ruler.y + radius * Math.sin(angle),
          };
        }
      }

      return rawWorld;
    },
    [ruler]
  );

  // Resize canvas ONLY when container dimensions actually change
  useEffect(() => {
    const updateCanvasDimensions = () => {
      if (!wrapRef.current || !bgCanvasRef.current || !strokeCanvasRef.current) return;
      const rect = wrapRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;

      const targetW = Math.floor(rect.width * dpr);
      const targetH = Math.floor(rect.height * dpr);

      if (strokeCanvasRef.current.width !== targetW || strokeCanvasRef.current.height !== targetH) {
        bgCanvasRef.current.width = targetW;
        bgCanvasRef.current.height = targetH;
        bgCanvasRef.current.style.width = `${rect.width}px`;
        bgCanvasRef.current.style.height = `${rect.height}px`;

        strokeCanvasRef.current.width = targetW;
        strokeCanvasRef.current.height = targetH;
        strokeCanvasRef.current.style.width = `${rect.width}px`;
        strokeCanvasRef.current.style.height = `${rect.height}px`;

        requestRender();
      }
    };

    updateCanvasDimensions();
    window.addEventListener('resize', updateCanvasDimensions);
    return () => window.removeEventListener('resize', updateCanvasDimensions);
  }, []);

  // Main Render loop
  const requestRender = useCallback(() => {
    if (liveRef.current.rafId) return;
    liveRef.current.rafId = requestAnimationFrame(() => {
      liveRef.current.rafId = null;
      if (!bgCanvasRef.current || !strokeCanvasRef.current || !currentPage) return;

      const dpr = window.devicePixelRatio || 1;
      const bgCtx = bgCanvasRef.current.getContext('2d');
      const strokeCtx = strokeCanvasRef.current.getContext('2d');
      if (!bgCtx || !strokeCtx) return;

      const v = viewRef.current;
      const currentItems = strokesRef.current;

      const bgKey = `${scrollMode}|${v.scale}|${v.offsetX}|${v.offsetY}|${bgCanvasRef.current.width}x${bgCanvasRef.current.height}|${currentPageIndex}|${isDualPage}`;
      const bc = bgCacheRef.current;
      const bgStale =
        bc.dirty || bc.key !== bgKey || bc.pages !== pages || bc.page !== currentPage || bc.offsets !== pageOffsets;
      const onBgImageLoad = () => {
        bgCacheRef.current.dirty = true;
        requestRender();
      };
      if (bgStale) {
        bgCacheRef.current = { key: bgKey, pages, page: currentPage, offsets: pageOffsets, dirty: false };
      }

      if (scrollMode === 'vertical') {
        // 1. Draw all pages stacked vertically
        if (bgStale) drawMultiplePagesBackground(bgCtx, pages, pageOffsets, v, dpr, onBgImageLoad);

        // 2. Draw Strokes
        strokeCtx.setTransform(1, 0, 0, 1, 0, 0);
        strokeCtx.clearRect(0, 0, strokeCanvasRef.current.width, strokeCanvasRef.current.height);

        const s = v.scale * dpr;
        const viewportTop = -v.offsetY / v.scale;
        const viewportBottom = (-v.offsetY + strokeCanvasRef.current.height / dpr) / v.scale;

        // Render each page's strokes at its vertical offset
        for (let i = 0; i < pages.length; i++) {
          const topY = pageOffsets[i];
          const page = pages[i];
          if (topY + page.height < viewportTop - 120 || topY > viewportBottom + 120) {
            continue;
          }

          strokeCtx.save();
          strokeCtx.setTransform(s, 0, 0, s, v.offsetX * dpr, (v.offsetY + topY * v.scale) * dpr);
          const pageItems = i === currentPageIndex ? strokesRef.current : page.strokes;

          // 1. Fosforlu Kalem Katmanı
          for (const item of pageItems) {
            if (item.type === 'stroke' && item.tool === 'highlighter') {
              drawItem(strokeCtx, item, () => requestRender());
            }
          }
          // 2. Ana Çizim Katmanı
          for (const item of pageItems) {
            if (item.type !== 'stroke' || item.tool !== 'highlighter') {
              drawItem(strokeCtx, item, () => requestRender());
            }
          }
          strokeCtx.restore();
        }

        // Active drawing stroke & preview in world coordinates
        strokeCtx.setTransform(s, 0, 0, s, v.offsetX * dpr, v.offsetY * dpr);
        if (liveRef.current.currentStroke && !liveRef.current.isPinching) {
          drawItem(strokeCtx, liveRef.current.currentStroke);
        }
        if (liveRef.current.shapePreview && !liveRef.current.isPinching) {
          drawItem(strokeCtx, liveRef.current.shapePreview);
        }
      } else {
        // Single Page Mode
        // 1. Draw Background
        if (bgStale) {
          drawBackgroundCanvas(bgCtx, currentPage, v, dpr, onBgImageLoad);
        if (isDualPage && pages[currentPageIndex + 1]) {
          bgCtx.save();
          const pageGap = 24;
          bgCtx.translate((currentPage.width + pageGap) * v.scale * dpr, 0);
          drawBackgroundCanvas(
            bgCtx,
            pages[currentPageIndex + 1],
            { scale: v.scale, offsetX: 0, offsetY: v.offsetY },
            dpr,
            onBgImageLoad
          );
          bgCtx.restore();
        }
        }

        // 2. Draw Strokes
        strokeCtx.setTransform(1, 0, 0, 1, 0, 0);
        strokeCtx.clearRect(0, 0, strokeCanvasRef.current.width, strokeCanvasRef.current.height);

        const s = v.scale * dpr;
        strokeCtx.setTransform(s, 0, 0, s, v.offsetX * dpr, v.offsetY * dpr);

        const currentItems = strokesRef.current;

        // Çizgi/şekil çizilirken eski öğeler tek resim olarak çizilir (hızlı yol)
        const liveNow = liveRef.current;
        const liveDrawing =
          !isDualPage &&
          !liveNow.isPinching &&
          ((!!liveNow.currentStroke && liveNow.currentStroke.tool !== 'highlighter') || !!liveNow.shapePreview);
        const lc = layerCacheRef.current;

        if (liveDrawing) {
          const cw = strokeCanvasRef.current.width;
          const ch = strokeCanvasRef.current.height;
          const cacheKey = `${v.scale}|${v.offsetX}|${v.offsetY}|${cw}x${ch}|${currentItems.length}|${currentPageIndex}`;
          if (!lc.canvas) lc.canvas = document.createElement('canvas');
          if (lc.key !== cacheKey || lc.items !== currentItems) {
            if (lc.canvas.width !== cw || lc.canvas.height !== ch) {
              lc.canvas.width = cw;
              lc.canvas.height = ch;
            }
            const lctx = lc.canvas.getContext('2d');
            if (lctx) {
              const onCacheImg = () => {
                layerCacheRef.current.key = '';
                requestRender();
              };
              lctx.setTransform(1, 0, 0, 1, 0, 0);
              lctx.clearRect(0, 0, cw, ch);
              lctx.setTransform(s, 0, 0, s, v.offsetX * dpr, v.offsetY * dpr);
              for (const item of currentItems) {
                if (item.type === 'stroke' && item.tool === 'highlighter') drawItem(lctx, item, onCacheImg);
              }
              for (const item of currentItems) {
                if (item.type !== 'stroke' || item.tool !== 'highlighter') drawItem(lctx, item, onCacheImg);
              }
              lc.key = cacheKey;
              lc.items = currentItems;
            }
          }
          strokeCtx.setTransform(1, 0, 0, 1, 0, 0);
          strokeCtx.drawImage(lc.canvas, 0, 0);
          strokeCtx.setTransform(s, 0, 0, s, v.offsetX * dpr, v.offsetY * dpr);
        } else {
          lc.key = '';
          lc.items = null;
        // 1. Fosforlu Kalem Katmanı
        for (const item of currentItems) {
          if (item.type === 'stroke' && item.tool === 'highlighter') {
            drawItem(strokeCtx, item, () => requestRender());
          }
        }
        if (
          liveRef.current.currentStroke &&
          liveRef.current.currentStroke.tool === 'highlighter' &&
          !liveRef.current.isPinching
        ) {
          drawItem(strokeCtx, liveRef.current.currentStroke);
        }

        // 2. Ana Çizim Katmanı
        for (const item of currentItems) {
          if (item.type !== 'stroke' || item.tool !== 'highlighter') {
            drawItem(strokeCtx, item, () => requestRender());
          }
        }

        }

        if (isDualPage && pages[currentPageIndex + 1]) {
          strokeCtx.save();
          strokeCtx.translate(currentPage.width + 24, 0);
          for (const item of pages[currentPageIndex + 1].strokes) {
            drawItem(strokeCtx, item, () => requestRender());
          }
          strokeCtx.restore();
        }

        if (
          liveRef.current.currentStroke &&
          liveRef.current.currentStroke.tool !== 'highlighter' &&
          !liveRef.current.isPinching
        ) {
          drawItem(strokeCtx, liveRef.current.currentStroke);
        }

        if (liveRef.current.shapePreview && !liveRef.current.isPinching) {
          drawItem(strokeCtx, liveRef.current.shapePreview);
        }
      }

      // Lasso polygon preview
      const lassoPts = liveRef.current.lassoPoints;
      if (lassoPts && lassoPts.length > 1) {
        strokeCtx.save();
        strokeCtx.strokeStyle = '#007aff';
        strokeCtx.lineWidth = 1.5 / v.scale;
        strokeCtx.setLineDash([5 / v.scale, 4 / v.scale]);
        strokeCtx.beginPath();
        strokeCtx.moveTo(lassoPts[0].x, lassoPts[0].y);
        for (let j = 1; j < lassoPts.length; j++) {
          strokeCtx.lineTo(lassoPts[j].x, lassoPts[j].y);
        }
        strokeCtx.closePath();
        strokeCtx.stroke();
        strokeCtx.fillStyle = 'rgba(0, 122, 255, 0.08)';
        strokeCtx.fill();
        strokeCtx.restore();
      }

      // Eraser hover cursor circle
      const hPos = liveRef.current.hoverPos;
      if (hPos && (activeTool === 'eraser' || activeTool === 'stroke-eraser')) {
        const w = toWorld(hPos.x, hPos.y);
        const radius = activeTool === 'eraser' ? tools.eraser.size * 1.5 : tools['stroke-eraser'].size * 1.5;
        strokeCtx.save();
        strokeCtx.beginPath();
        strokeCtx.arc(w.x, w.y, radius, 0, Math.PI * 2);
        strokeCtx.strokeStyle = 'rgba(0, 0, 0, 0.4)';
        strokeCtx.lineWidth = 1 / v.scale;
        strokeCtx.setLineDash([3 / v.scale, 3 / v.scale]);
        strokeCtx.stroke();
        strokeCtx.restore();
      }

      // Zoom Box Focus Area Guide
      if (isZoomBoxOpen) {
        strokeCtx.save();
        strokeCtx.strokeStyle = 'rgba(37, 99, 235, 0.8)';
        strokeCtx.lineWidth = 2 / v.scale;
        strokeCtx.fillStyle = 'rgba(59, 130, 246, 0.08)';
        strokeCtx.fillRect(zoomFocusPos.x, zoomFocusPos.y, 320, 150);
        strokeCtx.strokeRect(zoomFocusPos.x, zoomFocusPos.y, 320, 150);
        strokeCtx.fillStyle = '#2563eb';
        const cw = 6 / v.scale;
        strokeCtx.fillRect(zoomFocusPos.x, zoomFocusPos.y, cw, cw);
        strokeCtx.fillRect(zoomFocusPos.x + 320 - cw, zoomFocusPos.y, cw, cw);
        strokeCtx.fillRect(zoomFocusPos.x, zoomFocusPos.y + 150 - cw, cw, cw);
        strokeCtx.fillRect(zoomFocusPos.x + 320 - cw, zoomFocusPos.y + 150 - cw, cw, cw);
        strokeCtx.restore();
      }

      // Shape Inspector: Draw Dimension Labels on shapes
      if (isInspectorOpen) {
        strokeCtx.save();
        strokeCtx.font = `bold ${Math.max(11, 13 / v.scale)}px sans-serif`;
        for (const item of currentItems) {
          if (item.type === 'shape') {
            if (item.shape === 'line' || item.shape === 'arrow') {
              const len = Math.hypot(item.x2 - item.x1, item.y2 - item.y1);
              const cm = (len / 40).toFixed(1);
              const midX = (item.x1 + item.x2) / 2;
              const midY = (item.y1 + item.y2) / 2 - 10 / v.scale;
              strokeCtx.fillStyle = '#0f172a';
              strokeCtx.fillText(`${cm} cm`, midX, midY);
            } else if (item.shape === 'rect') {
              const w = Math.abs(item.x2 - item.x1);
              const h = Math.abs(item.y2 - item.y1);
              const minX = Math.min(item.x1, item.x2);
              const minY = Math.min(item.y1, item.y2);
              strokeCtx.fillStyle = '#0f172a';
              strokeCtx.fillText(`${(w / 40).toFixed(1)} cm`, minX + w / 2 - 15 / v.scale, minY - 8 / v.scale);
              strokeCtx.fillText(`${(h / 40).toFixed(1)} cm`, minX + w + 8 / v.scale, minY + h / 2);
            } else if (item.shape === 'triangle') {
              const minX = Math.min(item.x1, item.x2);
              const maxX = Math.max(item.x1, item.x2);
              const maxY = Math.max(item.y1, item.y2);
              strokeCtx.fillStyle = '#0f172a';
              strokeCtx.fillText(`taban: ${((maxX - minX) / 40).toFixed(1)} cm`, (minX + maxX) / 2 - 20 / v.scale, maxY + 16 / v.scale);
            }
          }
        }
        strokeCtx.restore();
      }

      // Interactive Virtual Compass Overlay (Pergel)
      if (compass.visible) {
        drawCompassOverlay(strokeCtx, compass, v, dpr);
      }
    });
  }, [
    currentPage,
    activeTool,
    tools,
    toWorld,
    compass,
    isZoomBoxOpen,
    zoomFocusPos,
    isInspectorOpen,
    isDualPage,
    pages,
    currentPageIndex,
    scrollMode,
    pageOffsets,
  ]);

  useEffect(() => {
    requestRender();
  }, [view, activeTool, requestRender]);

  // Update selection bounding box from selected indices
  const updateSelectionBox = useCallback(() => {
    if (selectedIndices.length === 0 || !currentPage) {
      setSelectionBox(null);
      return;
    }
    let x1 = Infinity;
    let y1 = Infinity;
    let x2 = -Infinity;
    let y2 = -Infinity;

    for (const idx of selectedIndices) {
      const item = strokesRef.current[idx];
      if (!item) continue;
      const bb = getItemBoundingBox(item);
      if (bb) {
        if (bb.x1 < x1) x1 = bb.x1;
        if (bb.y1 < y1) y1 = bb.y1;
        if (bb.x2 > x2) x2 = bb.x2;
        if (bb.y2 > y2) y2 = bb.y2;
      }
    }

    if (x1 < x2 && y1 < y2) {
      setSelectionBox({ x1, y1, x2, y2 });
    } else {
      setSelectionBox(null);
    }
  }, [selectedIndices, currentPage]);

  useEffect(() => {
    updateSelectionBox();
  }, [selectedIndices, updateSelectionBox]);

  // Pointer Handlers with Multi-Touch Protection & Ruler Snapping
  // Kaydırma/yakınlaştırmada canvas viewRef'ten çizilir; React state'i (yüzde etiketi, cetvel vb.)
  // her harekette değil, seyrek güncellenir. Böylece tüm arayüz her pointer olayında yeniden çizilmez.
  const viewSyncTimerRef = useRef<number | null>(null);
  const liveOverlayRef = useRef(false);
  liveOverlayRef.current = ruler.visible || !!selectionBox || !!editingTextPos;
  const syncViewState = () => {
    if (viewSyncTimerRef.current !== null) return;
    const delay = liveOverlayRef.current ? 16 : 140;
    viewSyncTimerRef.current = window.setTimeout(() => {
      viewSyncTimerRef.current = null;
      setView(viewRef.current);
    }, delay);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (Date.now() - liveRef.current.pinchEndedAt < 350) {
      return;
    }

    if (e.pointerType === 'mouse' && e.button === 1) {
      const v = viewRef.current;
      liveRef.current.middlePan = {
        startX: e.clientX,
        startY: e.clientY,
        ox: v.offsetX,
        oy: v.offsetY,
      };
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }

    if (e.pointerType === 'mouse' && e.button !== 0) return;

    if (e.pointerType === 'pen') {
      liveRef.current.hasUsedPen = true;
    }

    const isFingerWithPenActive = e.pointerType === 'touch' && liveRef.current.hasUsedPen && palmRejection;

    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    liveRef.current.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, type: e.pointerType });

    // Two finger pinch / zoom detected
    if (liveRef.current.pointers.size >= 2) {
      liveRef.current.isPinching = true;
      liveRef.current.currentStroke = null;
      liveRef.current.shapePreview = null;
      liveRef.current.singleFingerPan = null;

      const pts = Array.from(liveRef.current.pointers.values());
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const screenCenterX = (pts[0].x + pts[1].x) / 2 - rect.left;
      const screenCenterY = (pts[0].y + pts[1].y) / 2 - rect.top;
      const v = viewRef.current;

      liveRef.current.pinch = {
        dist: Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y),
        scale: v.scale,
        centerWorld: {
          x: (screenCenterX - v.offsetX) / v.scale,
          y: (screenCenterY - v.offsetY) / v.scale,
        },
        centerScreen: { x: screenCenterX, y: screenCenterY },
      };

      requestRender();
      return;
    }

    // Hand tool or Palm Rejection finger pan
    if (activeTool === 'hand' || isFingerWithPenActive) {
      const v = viewRef.current;
      liveRef.current.singleFingerPan = {
        startX: e.clientX,
        startY: e.clientY,
        ox: v.offsetX,
        oy: v.offsetY,
      };
      return;
    }

    let world = toWorld(e.clientX, e.clientY);
    if (activeTool === 'pen' || activeTool === 'highlighter' || activeTool === 'line') {
      world = snapToRulerIfNear(world);
    }

    // Interactive Compass Touch (Igne veya Kalem Ucu Tutma)
    if (compass.visible) {
      const distNeedle = Math.hypot(world.x - compass.x, world.y - compass.y);
      const rad = (compass.angle * Math.PI) / 180;
      const px = compass.x + compass.radius * Math.cos(rad);
      const py = compass.y + compass.radius * Math.sin(rad);
      const distPencil = Math.hypot(world.x - px, world.y - py);

      if (distNeedle < 36 / view.scale) {
        liveRef.current.compassDrag = {
          type: 'needle',
          startAngle: compass.angle,
          startRadius: compass.radius,
          cx: compass.x,
          cy: compass.y,
          startX: world.x,
          startY: world.y,
        };
        return;
      }
      if (distPencil < 36 / view.scale) {
        liveRef.current.compassDrag = {
          type: 'pencil',
          startAngle: compass.angle,
          startRadius: compass.radius,
          cx: compass.x,
          cy: compass.y,
          startX: world.x,
          startY: world.y,
        };
        return;
      }
    }

    const ts = tools[activeTool];

    // Lasso Tool
    if (activeTool === 'lasso') {
      if (selectionBox && selectedIndices.length > 0) {
        const pad = 12;
        if (
          world.x >= selectionBox.x1 - pad &&
          world.x <= selectionBox.x2 + pad &&
          world.y >= selectionBox.y1 - pad &&
          world.y <= selectionBox.y2 + pad
        ) {
          liveRef.current.dragSelection = {
            startWorld: world,
            origItems: selectedIndices.map((i) => ({ ...strokesRef.current[i] })),
            indices: [...selectedIndices],
          };
          return;
        }
      }
      setSelectedIndices([]);
      setSelectionBox(null);
      liveRef.current.lassoPoints = [world];
      requestRender();
      return;
    }

    // Precision Vector Eraser (Gerçek Fiziksel Silgi: çizgileri fiziksel keser/siler)
    if (activeTool === 'eraser') {
      pushUndo();
      liveRef.current.isErasing = true;
      const radius = tools.eraser.size * 1.5;
      const eraseHighlighterOnly = !!tools.eraser.eraseHighlighterOnly;
      const { updatedItems, hasChanged } = eraseAtPoint(strokesRef.current, world, radius, eraseHighlighterOnly);
      if (hasChanged) {
        strokesRef.current = updatedItems;
        requestRender();
      }
      return;
    }

    // Stroke Eraser (Nokta / Çizgi Silgisi: dokunulan şekli/çizgiyi tamamen kaldırır)
    if (activeTool === 'stroke-eraser') {
      pushUndo();
      liveRef.current.isErasing = true;
      eraseStrokeAt(world);
      return;
    }

    // Text Tool
    if (activeTool === 'text') {
      let hitIndex = -1;
      for (let i = strokesRef.current.length - 1; i >= 0; i--) {
        const item = strokesRef.current[i];
        if (item.type === 'text') {
          const bb = getItemBoundingBox(item);
          if (bb && world.x >= bb.x1 && world.x <= bb.x2 && world.y >= bb.y1 && world.y <= bb.y2) {
            hitIndex = i;
            break;
          }
        }
      }
      if (hitIndex >= 0) {
        const item = strokesRef.current[hitIndex] as any;
        setEditingTextIndex(hitIndex);
        setEditingTextPos({ x: item.x, y: item.y });
        setEditingTextValue(item.text);
      } else {
        setEditingTextIndex(-1);
        setEditingTextPos(world);
        setEditingTextValue('');
      }
      return;
    }

    // Shapes Tool (rect, ellipse, triangle, line, arrow, right-angle, angle-arc, coord-axes)
    if (
      activeTool === 'rect' ||
      activeTool === 'ellipse' ||
      activeTool === 'triangle' ||
      activeTool === 'line' ||
      activeTool === 'arrow' ||
      activeTool === 'right-angle' ||
      activeTool === 'angle-arc' ||
      activeTool === 'coord-axes'
    ) {
      liveRef.current.shapePreview = {
        id: 'shp_' + Date.now(),
        type: 'shape',
        shape: activeTool,
        x1: world.x,
        y1: world.y,
        x2: world.x,
        y2: world.y,
        color: ts.color,
        size: ts.size,
        opacity: ts.opacity,
        fill: ts.fill,
        lineCap: ts.lineCap,
      };
      requestRender();
      return;
    }

    // Freehand Pen / Highlighter / Laser / Eraser
    liveRef.current.currentStroke = {
      id: 'st_' + Date.now(),
      type: 'stroke',
      tool: activeTool as any,
      color: ts.color,
      size: ts.size,
      opacity: ts.opacity,
      lineCap: ts.lineCap,
      penType: ts.penType || 'standard',
      points: [{ ...world, pressure: e.pressure > 0 ? e.pressure : 0.5 }],
    };
    requestRender();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (liveRef.current.middlePan) {
      const mp = liveRef.current.middlePan;
      const nextView = {
        ...viewRef.current,
        offsetX: mp.ox + (e.clientX - mp.startX),
        offsetY: mp.oy + (e.clientY - mp.startY),
      };
      viewRef.current = nextView;
      syncViewState();
      requestRender();
      return;
    }

    if (liveRef.current.singleFingerPan) {
      const sfp = liveRef.current.singleFingerPan;
      const nextView = {
        ...viewRef.current,
        offsetX: sfp.ox + (e.clientX - sfp.startX),
        offsetY: sfp.oy + (e.clientY - sfp.startY),
      };
      viewRef.current = nextView;
      syncViewState();
      requestRender();
      return;
    }

    if (e.pointerType === 'mouse' || e.pointerType === 'pen') {
      liveRef.current.hoverPos = { x: e.clientX, y: e.clientY };
      if (activeTool === 'eraser' || activeTool === 'stroke-eraser') {
        requestRender();
      }
    }

    if (!liveRef.current.pointers.has(e.pointerId)) return;
    const ptr = liveRef.current.pointers.get(e.pointerId)!;
    ptr.x = e.clientX;
    ptr.y = e.clientY;

    // Two finger pinch zoom & pan (Synchronous viewRef update + instant requestRender)
    if (liveRef.current.isPinching && liveRef.current.pointers.size >= 2) {
      const pts = Array.from(liveRef.current.pointers.values());
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const currentDist = Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y);
      const currentCenterX = (pts[0].x + pts[1].x) / 2 - rect.left;
      const currentCenterY = (pts[0].y + pts[1].y) / 2 - rect.top;

      const pinch = liveRef.current.pinch;
      if (pinch && pinch.dist > 10) {
        const scaleFactor = currentDist / Math.max(15, pinch.dist);
        const newScale = Math.max(0.15, Math.min(8, pinch.scale * scaleFactor));
        const newOffsetX = currentCenterX - pinch.centerWorld.x * newScale;
        const newOffsetY = currentCenterY - pinch.centerWorld.y * newScale;

        viewRef.current = {
          scale: newScale,
          offsetX: newOffsetX,
          offsetY: newOffsetY,
        };
        syncViewState();
        requestRender();
      }
      return;
    }

    if (liveRef.current.isPinching) return;
    if (Date.now() - liveRef.current.pinchEndedAt < 350) return;

    let world = toWorld(e.clientX, e.clientY);
    if (activeTool === 'pen' || activeTool === 'highlighter' || activeTool === 'line') {
      world = snapToRulerIfNear(world);
    }

    // Compass Dragging (Igne veya Kalem Ucu Donusu & Boyutlandirma)
    if (liveRef.current.compassDrag) {
      const cd = liveRef.current.compassDrag;
      if (cd.type === 'needle') {
        const dx = world.x - cd.startX;
        const dy = world.y - cd.startY;
        setCompass((prev) => ({
          ...prev,
          x: cd.cx + dx,
          y: cd.cy + dy,
        }));
      } else if (cd.type === 'pencil') {
        const dx = world.x - cd.cx;
        const dy = world.y - cd.cy;
        const newRadius = Math.max(25, Math.min(600, Math.hypot(dx, dy)));
        let newAngle = (Math.atan2(dy, dx) * 180) / Math.PI;
        if (newAngle < 0) newAngle += 360;
        setCompass((prev) => ({
          ...prev,
          radius: newRadius,
          angle: newAngle,
        }));
      }
      requestRender();
      return;
    }

    // Precision Vector Eraser Dragging (fiziksel vektör silme/kesme)
    if (activeTool === 'eraser' && liveRef.current.isErasing) {
      const radius = tools.eraser.size * 1.5;
      const eraseHighlighterOnly = !!tools.eraser.eraseHighlighterOnly;
      const { updatedItems, hasChanged } = eraseAtPoint(strokesRef.current, world, radius, eraseHighlighterOnly);
      if (hasChanged) {
        strokesRef.current = updatedItems;
        requestRender();
      }
      return;
    }

    // Stroke Eraser Dragging (dokunulan nesneleri tamamen silme)
    if (activeTool === 'stroke-eraser' && liveRef.current.isErasing) {
      eraseStrokeAt(world);
      return;
    }

    // Dragging selection items with lasso
    if (liveRef.current.dragSelection) {
      const ds = liveRef.current.dragSelection;
      const dx = world.x - ds.startWorld.x;
      const dy = world.y - ds.startWorld.y;

      const updatedStrokes = [...strokesRef.current];
      ds.indices.forEach((idx, k) => {
        const orig = ds.origItems[k];
        if (orig.type === 'stroke') {
          updatedStrokes[idx] = {
            ...orig,
            points: orig.points.map((p) => ({ x: p.x + dx, y: p.y + dy })),
          };
        } else if (orig.type === 'shape') {
          updatedStrokes[idx] = {
            ...orig,
            x1: orig.x1 + dx,
            y1: orig.y1 + dy,
            x2: orig.x2 + dx,
            y2: orig.y2 + dy,
          };
        } else if (orig.type === 'text' || orig.type === 'image' || orig.type === 'sticker') {
          updatedStrokes[idx] = {
            ...orig,
            x: orig.x + dx,
            y: orig.y + dy,
          };
        }
      });

      // Sürüklerken sadece canvas güncellenir; kayıt/state parmak kalkınca tek seferde yapılır
      strokesRef.current = updatedStrokes;
      updateSelectionBox();
      requestRender();
      return;
    }

    // Lasso polygon point collection
    if (liveRef.current.lassoPoints) {
      const pts = liveRef.current.lassoPoints;
      const last = pts[pts.length - 1];
      if (Math.hypot(world.x - last.x, world.y - last.y) > 2 / view.scale) {
        pts.push(world);
        requestRender();
      }
      return;
    }

    // Shape preview update
    if (liveRef.current.shapePreview) {
      liveRef.current.shapePreview.x2 = world.x;
      liveRef.current.shapePreview.y2 = world.y;
      requestRender();
      return;
    }

    // Freehand stroke point collection
    if (liveRef.current.currentStroke) {
      const pts = liveRef.current.currentStroke.points;
      // Apple Pencil kareler arasında birden çok nokta üretir; hepsini alınca çizgi daha pürüzsüz olur
      const native: any = e.nativeEvent;
      const coalesced: PointerEvent[] =
        typeof native.getCoalescedEvents === 'function' ? native.getCoalescedEvents() : [];
      const evs: PointerEvent[] = coalesced.length > 0 ? coalesced : [native as PointerEvent];
      const minDist = 1.2 / viewRef.current.scale;
      let added = false;
      for (const ev of evs) {
        let w = toWorld(ev.clientX, ev.clientY);
        if (activeTool === 'pen' || activeTool === 'highlighter' || activeTool === 'line') {
          w = snapToRulerIfNear(w);
        }
        const last = pts[pts.length - 1];
        if (Math.hypot(w.x - last.x, w.y - last.y) < minDist) continue;
        pts.push({ ...w, pressure: ev.pressure > 0 ? ev.pressure : 0.5 });
        added = true;
      }
      if (added) requestRender();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (liveRef.current.compassDrag) {
      liveRef.current.compassDrag = null;
      requestRender();
    }

    if (liveRef.current.middlePan) {
      liveRef.current.middlePan = null;
      try {
        (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      } catch (err) {
        // ignore
      }
      return;
    }

    if (liveRef.current.singleFingerPan) {
      liveRef.current.singleFingerPan = null;
      liveRef.current.pointers.delete(e.pointerId);
      return;
    }

    liveRef.current.pointers.delete(e.pointerId);

    // Pinch gesture termination (as soon as fewer than 2 fingers remain on screen)
    if (liveRef.current.isPinching) {
      if (liveRef.current.pointers.size < 2) {
        liveRef.current.isPinching = false;
        liveRef.current.pinch = null;
        liveRef.current.pinchEndedAt = Date.now();
      }
      liveRef.current.currentStroke = null;
      liveRef.current.shapePreview = null;
      requestRender();
      return;
    }

    if (Date.now() - liveRef.current.pinchEndedAt < 350) {
      liveRef.current.currentStroke = null;
      liveRef.current.shapePreview = null;
      requestRender();
      return;
    }

    // Commit Eraser changes on stroke end
    if (liveRef.current.isErasing) {
      liveRef.current.isErasing = false;
      const updatedPages = [...pages];
      updatedPages[currentPageIndex] = { ...currentPage, strokes: strokesRef.current };
      onUpdatePages(updatedPages);
      requestRender();
      return;
    }

    if (liveRef.current.dragSelection) {
      liveRef.current.dragSelection = null;
      const movedPages = [...pages];
      movedPages[currentPageIndex] = { ...currentPage, strokes: strokesRef.current };
      onUpdatePages(movedPages);
      updateSelectionBox();
      return;
    }

    if (liveRef.current.lassoPoints) {
      const poly = liveRef.current.lassoPoints;
      liveRef.current.lassoPoints = null;

      if (poly.length >= 3) {
        const hits: number[] = [];
        strokesRef.current.forEach((item, idx) => {
          if (item.type === 'stroke') {
            for (const p of item.points) {
              if (pointInPolygon(p, poly)) {
                hits.push(idx);
                break;
              }
            }
          } else {
            const bb = getItemBoundingBox(item);
            if (bb) {
              const center = { x: (bb.x1 + bb.x2) / 2, y: (bb.y1 + bb.y2) / 2 };
              if (pointInPolygon(center, poly)) {
                hits.push(idx);
              }
            }
          }
        });
        setSelectedIndices(hits);
      } else {
        setSelectedIndices([]);
      }
      requestRender();
      return;
    }

    // Finish Shape drawing
    if (liveRef.current.shapePreview) {
      const sh = liveRef.current.shapePreview;
      liveRef.current.shapePreview = null;
      if (Math.hypot(sh.x2 - sh.x1, sh.y2 - sh.y1) > 6) {
        pushUndo();
        if (scrollMode === 'vertical') {
          const targetIdx = findPageIndexAtY(sh.y1);
          const top = pageOffsets[targetIdx] ?? 0;
          const localShape: ShapeStroke = {
            ...sh,
            y1: sh.y1 - top,
            y2: sh.y2 - top,
          };
          const updatedPages = [...pages];
          if (targetIdx === currentPageIndex) {
            const nextStrokes = [...strokesRef.current, localShape];
            strokesRef.current = nextStrokes;
            updatedPages[currentPageIndex] = {
              ...currentPage,
              strokes: nextStrokes,
            };
          } else {
            updatedPages[targetIdx] = {
              ...updatedPages[targetIdx],
              strokes: [...updatedPages[targetIdx].strokes, localShape],
            };
          }
          onUpdatePages(updatedPages);
        } else {
          const nextStrokes = [...strokesRef.current, sh];
          strokesRef.current = nextStrokes;
          const updatedPages = [...pages];
          updatedPages[currentPageIndex] = {
            ...currentPage,
            strokes: nextStrokes,
          };
          onUpdatePages(updatedPages);
        }
      }
      requestRender();
      return;
    }

    // Finish Freehand Stroke (ZERO FLICKER: committed to strokesRef first!)
    if (liveRef.current.currentStroke) {
      const stroke = liveRef.current.currentStroke;
      liveRef.current.currentStroke = null;

      if (stroke.points.length >= 1) {
        if (stroke.tool === 'laser') {
          liveRef.current.laserStrokes.push({
            ...stroke,
            createdAt: performance.now(),
          });
        } else {
          let recognized: ShapeStroke[] | null = null;
          if (stroke.tool === 'pen' && tools.pen.smartShape && !ruler.visible) {
            recognized = recognizeGeometricShape(stroke);
          }

          pushUndo();
          const itemsToAdd: CanvasItem[] =
            recognized && recognized.length > 0 ? recognized : [stroke];

          if (scrollMode === 'vertical') {
            const startY = stroke.points[0]?.y ?? 0;
            const targetIdx = findPageIndexAtY(startY);
            const top = pageOffsets[targetIdx] ?? 0;

            const pageLocalItems: CanvasItem[] = itemsToAdd.map((item) => {
              if (item.type === 'stroke') {
                return {
                  ...item,
                  points: item.points.map((p) => ({ ...p, y: p.y - top })),
                };
              } else if (item.type === 'shape') {
                return {
                  ...item,
                  y1: item.y1 - top,
                  y2: item.y2 - top,
                };
              }
              return item;
            });

            const updatedPages = [...pages];
            if (targetIdx === currentPageIndex) {
              const nextStrokes = [...strokesRef.current, ...pageLocalItems];
              strokesRef.current = nextStrokes;
              updatedPages[currentPageIndex] = {
                ...currentPage,
                strokes: nextStrokes,
              };
            } else {
              updatedPages[targetIdx] = {
                ...updatedPages[targetIdx],
                strokes: [...updatedPages[targetIdx].strokes, ...pageLocalItems],
              };
            }
            onUpdatePages(updatedPages);
          } else {
            const nextStrokes = [...strokesRef.current, ...itemsToAdd];
            strokesRef.current = nextStrokes;

            const updatedPages = [...pages];
            updatedPages[currentPageIndex] = {
              ...currentPage,
              strokes: nextStrokes,
            };
            onUpdatePages(updatedPages);
          }
        }
      }
      requestRender();
    }
  };

  // Erase stroke at point
  const eraseStrokeAt = (world: Point) => {
    const radius = tools['stroke-eraser'].size * 1.8;
    const eraseHighlighterOnly = !!tools['stroke-eraser'].eraseHighlighterOnly;

    if (scrollMode === 'vertical') {
      const targetIdx = findPageIndexAtY(world.y);
      const top = pageOffsets[targetIdx] ?? 0;
      const localWorld = { x: world.x, y: world.y - top };
      const targetStrokes = targetIdx === currentPageIndex ? strokesRef.current : pages[targetIdx].strokes;

      const hitIndex = targetStrokes.findIndex((item) => {
        if (eraseHighlighterOnly && (item.type !== 'stroke' || item.tool !== 'highlighter')) {
          return false;
        }
        if (item.type === 'stroke') {
          return item.points.some((p) => Math.hypot(p.x - localWorld.x, p.y - localWorld.y) <= radius);
        } else {
          const bb = getItemBoundingBox(item);
          if (!bb) return false;
          const cx = Math.max(bb.x1, Math.min(localWorld.x, bb.x2));
          const cy = Math.max(bb.y1, Math.min(localWorld.y, bb.y2));
          return Math.hypot(cx - localWorld.x, cy - localWorld.y) <= radius;
        }
      });

      if (hitIndex >= 0) {
        const updatedTarget = [...targetStrokes];
        updatedTarget.splice(hitIndex, 1);
        if (targetIdx === currentPageIndex) {
          strokesRef.current = updatedTarget;
        }
        const updatedPages = [...pages];
        updatedPages[targetIdx] = { ...updatedPages[targetIdx], strokes: updatedTarget };
        onUpdatePages(updatedPages);
        requestRender();
      }
      return;
    }

    const hitIndex = strokesRef.current.findIndex((item) => {
      if (eraseHighlighterOnly && (item.type !== 'stroke' || item.tool !== 'highlighter')) {
        return false;
      }
      if (item.type === 'stroke') {
        return item.points.some((p) => Math.hypot(p.x - world.x, p.y - world.y) <= radius);
      } else {
        const bb = getItemBoundingBox(item);
        if (!bb) return false;
        const cx = Math.max(bb.x1, Math.min(world.x, bb.x2));
        const cy = Math.max(bb.y1, Math.min(world.y, bb.y2));
        return Math.hypot(cx - world.x, cy - world.y) <= radius;
      }
    });

    if (hitIndex >= 0) {
      const updatedStrokes = [...strokesRef.current];
      updatedStrokes.splice(hitIndex, 1);
      strokesRef.current = updatedStrokes;
      if (!liveRef.current.isErasing) {
        const updatedPages = [...pages];
        updatedPages[currentPageIndex] = { ...currentPage, strokes: updatedStrokes };
        onUpdatePages(updatedPages);
      }
      requestRender();
    }
  };

  // Wheel Zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (!strokeCanvasRef.current) return;
    const rect = strokeCanvasRef.current.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const curV = viewRef.current;
    const wx = (sx - curV.offsetX) / curV.scale;
    const wy = (sy - curV.offsetY) / curV.scale;

    const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
    const newScale = Math.max(0.15, Math.min(8, curV.scale * factor));
    const nextView = {
      scale: newScale,
      offsetX: sx - wx * newScale,
      offsetY: sy - wy * newScale,
    };
    viewRef.current = nextView;
    syncViewState();
    requestRender();
  };

  // Insert Image helper
  const handleInsertImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();
      img.onload = () => {
        const maxWidth = currentPage.width * 0.65;
        const maxHeight = currentPage.height * 0.65;
        const sc = Math.min(1, maxWidth / img.width, maxHeight / img.height);
        const w = img.width * sc;
        const h = img.height * sc;

        const centerWorld = toWorld(window.innerWidth / 2, window.innerHeight / 2);

        pushUndo();
        const nextStrokes = [
          ...strokesRef.current,
          {
            id: 'img_' + Date.now(),
            type: 'image' as const,
            dataUrl,
            x: centerWorld.x - w / 2,
            y: centerWorld.y - h / 2,
            width: w,
            height: h,
          },
        ];
        strokesRef.current = nextStrokes;
        const updatedPages = [...pages];
        updatedPages[currentPageIndex] = {
          ...currentPage,
          strokes: nextStrokes,
        };
        onUpdatePages(updatedPages);
        requestRender();
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // Insert Sticker helper
  const handleInsertSticker = (emoji: string) => {
    const centerWorld = toWorld(window.innerWidth / 2, window.innerHeight / 2);
    const fontSize = 64;

    pushUndo();
    const nextStrokes = [
      ...strokesRef.current,
      {
        id: 'stk_' + Date.now(),
        type: 'sticker' as const,
        emoji,
        x: centerWorld.x - fontSize / 2,
        y: centerWorld.y - fontSize / 2,
        fontSize,
      },
    ];
    strokesRef.current = nextStrokes;
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = {
      ...currentPage,
      strokes: nextStrokes,
    };
    onUpdatePages(updatedPages);
    requestRender();
  };

  // PDF Import helper
  const handleImportPDF = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    try {
      setLoadingMsg('PDF sayfaları dönüştürülüyor...');
      const importedPages = await importPDFFile(file, (curr, total) => {
        setLoadingMsg(`PDF Sayfa ${curr} / ${total} işleniyor...`);
      });

      if (importedPages.length > 0) {
        pushUndo();
        const isCurrentEmpty =
          !currentPage.pdfDataUrl && strokesRef.current.length === 0;

        const updatedPages = [...pages];
        if (isCurrentEmpty) {
          updatedPages.splice(currentPageIndex, 1, ...importedPages);
        } else {
          updatedPages.splice(currentPageIndex + 1, 0, ...importedPages);
          onSelectPageIndex(currentPageIndex + 1);
        }
        onUpdatePages(updatedPages);
      }
    } catch (err: any) {
      alert(`PDF yüklenemedi: ${err?.message || err}`);
    } finally {
      setLoadingMsg(null);
    }
  };

  // PDF Export helper
  const handleExportPDF = async () => {
    setIsExportMenuOpen(false);
    try {
      setLoadingMsg('PDF belgesi hazırlanıyor...');
      await exportNotebookToPDF(notebook.name, pages, (curr, total) => {
        setLoadingMsg(`Sayfa ${curr} / ${total} PDF'e aktarılıyor...`);
      });
      showToast('Tüm defter PDF olarak indirildi.');
    } catch (err: any) {
      alert(`PDF oluşturulamadı: ${err?.message || err}`);
    } finally {
      setLoadingMsg(null);
    }
  };

  // Single page image export
  const handleExportSinglePage = async (format: 'png' | 'jpeg') => {
    setIsExportMenuOpen(false);
    try {
      setLoadingMsg('Sayfa resmi hazırlanıyor...');
      const name = `${notebook.name}_Sayfa_${currentPageIndex + 1}`;
      await exportSinglePageImage(currentPage, name, format);
      showToast(`Sayfa ${format.toUpperCase()} olarak indirildi.`);
    } catch (err: any) {
      alert(`Resim kaydedilemedi: ${err?.message || err}`);
    } finally {
      setLoadingMsg(null);
    }
  };

  // Copy page image to clipboard
  const handleCopyPageToClipboard = async () => {
    setIsExportMenuOpen(false);
    try {
      const ok = await copyPageImageToClipboard(currentPage);
      if (ok) {
        showToast('✓ Sayfa panoya kopyalandı! (Ctrl+V ile yapıştırabilirsiniz)');
      } else {
        showToast('Panoya kopyalama desteklenmiyor, resim olarak indirebilirsiniz.');
      }
    } catch (err) {
      showToast('Kopyalama başarısız oldu.');
    }
  };

  // Clear current page
  const handleClearPage = () => {
    if (!confirm('Bu sayfadaki tüm çizim ve notları silmek istediğinizden emin misiniz?')) return;
    pushUndo();
    strokesRef.current = [];
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, strokes: [] };
    onUpdatePages(updatedPages);
    setSelectedIndices([]);
    setSelectionBox(null);
    setIsQuickSettingsOpen(false);
    requestRender();
  };

  // Audio Recordings Management
  const handleAddAudioRecording = useCallback((recording: AudioRecording) => {
    const updatedPages = [...pages];
    const cur = updatedPages[currentPageIndex];
    const recs = cur.audioRecordings || [];
    updatedPages[currentPageIndex] = {
      ...cur,
      audioRecordings: [...recs, recording],
    };
    onUpdatePages(updatedPages);
    showToast('Ders ses kaydı eklendi');
  }, [pages, currentPageIndex, onUpdatePages, showToast]);

  const handleDeleteAudioRecording = useCallback((id: string) => {
    const updatedPages = [...pages];
    const cur = updatedPages[currentPageIndex];
    const recs = (cur.audioRecordings || []).filter((r) => r.id !== id);
    updatedPages[currentPageIndex] = {
      ...cur,
      audioRecordings: recs,
    };
    onUpdatePages(updatedPages);
    showToast('Ses kaydı silindi');
  }, [pages, currentPageIndex, onUpdatePages, showToast]);

  // Duplicate active page
  const handleDuplicatePage = () => {
    pushUndo();
    const copy: PageData = {
      ...currentPage,
      id: `p_${Date.now()}_dup`,
      strokes: strokesRef.current.map((s) => ({ ...s })),
    };
    const updatedPages = [...pages];
    updatedPages.splice(currentPageIndex + 1, 0, copy);
    onUpdatePages(updatedPages);
    onSelectPageIndex(currentPageIndex + 1);
  };

  // Delete active page
  const handleDeletePage = () => {
    if (pages.length <= 1) {
      alert('Defterde en az bir sayfa bulunmalıdır.');
      return;
    }
    if (!confirm(`${currentPageIndex + 1}. sayfayı silmek istediğinizden emin misiniz?`)) return;
    const updatedPages = [...pages];
    updatedPages.splice(currentPageIndex, 1);
    const newIdx = Math.min(currentPageIndex, updatedPages.length - 1);
    onUpdatePages(updatedPages);
    onSelectPageIndex(newIdx);
  };

  // Change page template / background
  const handleChangePageStyle = (style: PageStyle) => {
    pushUndo();
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, type: style, pdfDataUrl: null };
    onUpdatePages(updatedPages);
  };

  const handleChangePageBg = (bg: string) => {
    pushUndo();
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, bg };
    onUpdatePages(updatedPages);
  };

  // Save Text Editor changes
  const handleSaveTextEditor = () => {
    if (editingTextPos === null) return;
    const val = editingTextValue.trim();

    pushUndo();
    const updatedStrokes = [...strokesRef.current];

    if (editingTextIndex !== null && editingTextIndex >= 0) {
      if (!val) {
        updatedStrokes.splice(editingTextIndex, 1);
      } else {
        const item = updatedStrokes[editingTextIndex] as any;
        updatedStrokes[editingTextIndex] = { ...item, text: val };
      }
    } else if (val) {
      updatedStrokes.push({
        id: 'txt_' + Date.now(),
        type: 'text',
        x: editingTextPos.x,
        y: editingTextPos.y,
        text: val,
        fontSize: tools.text.size || 22,
        color: tools.text.color || '#1c1c1e',
      });
    }

    strokesRef.current = updatedStrokes;
    const updatedPages = [...pages];
    updatedPages[currentPageIndex] = { ...currentPage, strokes: updatedStrokes };
    onUpdatePages(updatedPages);

    setEditingTextIndex(null);
    setEditingTextPos(null);
    setEditingTextValue('');
    requestRender();
  };

  // Keyboard Shortcuts: Undo (Ctrl+Z), Redo (Ctrl+Y), Copy (Ctrl+C), Paste (Ctrl+V), Delete
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      // Undo / Redo
      if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y')) {
        e.preventDefault();
        handleRedo();
        return;
      }

      // Copy
      if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'C')) {
        if (selectedIndices.length > 0) {
          setClipboard(selectedIndices.map((i) => ({ ...strokesRef.current[i] })));
        }
        return;
      }

      // Paste
      if ((e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'V')) {
        if (clipboard.length > 0) {
          pushUndo();
          const pasted = clipboard.map((orig) => {
            if (orig.type === 'stroke') {
              return {
                ...orig,
                id: 'p_' + Date.now() + Math.random(),
                points: orig.points.map((p) => ({ x: p.x + 24, y: p.y + 24 })),
              };
            } else if (orig.type === 'shape') {
              return {
                ...orig,
                id: 'p_' + Date.now() + Math.random(),
                x1: orig.x1 + 24,
                y1: orig.y1 + 24,
                x2: orig.x2 + 24,
                y2: orig.y2 + 24,
              };
            } else {
              return {
                ...orig,
                id: 'p_' + Date.now() + Math.random(),
                x: orig.x + 24,
                y: orig.y + 24,
              };
            }
          });

          const nextStrokes = [...strokesRef.current, ...pasted];
          strokesRef.current = nextStrokes;
          const updatedPages = [...pages];
          updatedPages[currentPageIndex] = {
            ...currentPage,
            strokes: nextStrokes,
          };
          onUpdatePages(updatedPages);
          setSelectedIndices([]);
          setSelectionBox(null);
          requestRender();
        }
        return;
      }

      // Delete selected
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedIndices.length > 0) {
        pushUndo();
        const updatedStrokes = strokesRef.current.filter((_, idx) => !selectedIndices.includes(idx));
        strokesRef.current = updatedStrokes;
        const updatedPages = [...pages];
        updatedPages[currentPageIndex] = { ...currentPage, strokes: updatedStrokes };
        onUpdatePages(updatedPages);
        setSelectedIndices([]);
        setSelectionBox(null);
        requestRender();
        return;
      }

      // Tool shortcut keys
      if (e.key === 'h' || e.key === 'H') {
        setActiveTool('hand');
        return;
      }
      if (e.key === 'r' || e.key === 'R') {
        setRuler((prev) => ({ ...prev, visible: !prev.visible }));
        return;
      }
      const toolMap: Record<string, ActiveTool> = {
        '1': 'pen',
        '2': 'highlighter',
        '3': 'laser',
        '4': 'eraser',
        '5': 'stroke-eraser',
        '6': 'lasso',
        '7': 'text',
        '8': 'rect',
        '9': 'ellipse',
        '0': 'arrow',
      };
      if (toolMap[e.key]) {
        setActiveTool(toolMap[e.key]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIndices, clipboard, currentPage, pages, currentPageIndex, handleUndo, handleRedo, pushUndo, onUpdatePages, requestRender]);

  // Current active color representation for the color swatch
  const activeColor =
    activeTool === 'eraser' || activeTool === 'stroke-eraser' || activeTool === 'lasso' || activeTool === 'hand'
      ? tools.pen.color
      : tools[activeTool].color;

  return (
    <div
      className="fixed inset-0 flex flex-col bg-[#e5e5ea] overflow-hidden select-none"
      onClick={() => setIsExportMenuOpen(false)}
    >
      {/* Top Navigation Bar */}
      <header className="h-14 bg-white/95 backdrop-blur-md border-b border-black/8 px-2 sm:px-4 flex items-center justify-between gap-1.5 sm:gap-3 z-30 shrink-0 overflow-x-auto no-scrollbar w-full touch-pan-x select-none">
        {/* Left: Back & Title */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-1 p-2 sm:px-2.5 sm:py-1.5 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer shrink-0"
            title="Defterlerime Dön"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">Defterler</span>
          </button>

          <div className="h-4 w-px bg-slate-200 shrink-0" />

          {/* Editable Title */}
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-lg sm:text-xl select-none">{notebook.icon}</span>
            <input
              type="text"
              value={notebook.name}
              onChange={(e) => onUpdateNotebookTitle(e.target.value)}
              className="font-bold text-xs sm:text-sm text-slate-800 bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:bg-white/80 px-1 py-0.5 rounded outline-none transition-colors truncate max-w-[100px] sm:max-w-xs"
              placeholder="Defter Başlığı"
            />
          </div>
        </div>

        {/* Center: Page Switcher & Quiet Cloud Save Icon */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="flex items-center gap-0.5 sm:gap-1 bg-slate-100/90 p-0.5 sm:p-1 rounded-xl shadow-2xs">
            <button
              onClick={() => onSelectPageIndex(Math.max(0, currentPageIndex - 1))}
              disabled={currentPageIndex <= 0}
              className="p-1.5 sm:p-1 rounded-lg text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white transition-all cursor-pointer"
              title="Önceki Sayfa"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="px-1.5 sm:px-2.5 text-xs font-semibold text-slate-700 min-w-[55px] sm:min-w-[75px] text-center font-mono">
              {currentPageIndex + 1} / {pages.length}
            </span>

            <button
              onClick={() => onSelectPageIndex(Math.min(pages.length - 1, currentPageIndex + 1))}
              disabled={currentPageIndex >= pages.length - 1}
              className="p-1.5 sm:p-1 rounded-lg text-slate-600 hover:text-slate-900 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white transition-all cursor-pointer"
              title="Sonraki Sayfa"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <div className="h-3.5 w-px bg-slate-200 mx-0.5" />

            {/* Quick Add Page (+) Button */}
            <button
              onClick={handleQuickAddPage}
              className="p-1.5 rounded-lg text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 transition-all cursor-pointer flex items-center gap-0.5"
              title="⚡ Hızlı Sayfa Ekle"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>

            <div className="h-3.5 w-px bg-slate-200 mx-0.5" />

            {/* Bookmark Star Toggle */}
            <button
              onClick={() => {
                const updatedPages = [...pages];
                updatedPages[currentPageIndex] = {
                  ...currentPage,
                  bookmarked: !currentPage.bookmarked,
                };
                onUpdatePages(updatedPages);
                showToast(!currentPage.bookmarked ? 'Sayfa yer imlerine eklendi ★' : 'Yer imi kaldırıldı');
              }}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                currentPage.bookmarked
                  ? 'text-amber-500 bg-amber-50 hover:bg-amber-100'
                  : 'text-slate-400 hover:text-slate-700 hover:bg-white'
              }`}
              title={currentPage.bookmarked ? 'Yıldızlı Sayfa (Favori)' : 'Sayfayı Yıldızla'}
            >
              <Star className={`w-3.5 h-3.5 ${currentPage.bookmarked ? 'fill-amber-400 text-amber-500' : ''}`} />
            </button>
          </div>

          {/* Scroll Mode Toggle: Tek Sayfa vs Dikey Akış (GoodNotes / Notability tarzı) */}
          <button
            onClick={() => {
              const nextMode = scrollMode === 'single' ? 'vertical' : 'single';
              setScrollMode(nextMode);
              try {
                localStorage.setItem('notesApp_scrollMode', nextMode);
              } catch {}
              showToast(
                nextMode === 'vertical'
                  ? '📜 Dikey Akış Modu Açıldı (Sayfalar Alt Alta)'
                  : '📄 Tek Sayfa Modu Açıldı'
              );
              requestRender();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
              scrollMode === 'vertical'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
            title="Sayfa Görünümü: Tek Sayfa veya Alt Alta Dikey Akış (GoodNotes tarzı)"
          >
            <ScrollText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {scrollMode === 'vertical' ? 'Dikey Akış' : 'Tek Sayfa'}
            </span>
          </button>

          <div
            className="hidden md:flex items-center gap-1 text-[11px] font-medium text-slate-400 shrink-0"
            title="Otomatik Kayıt Devrede"
          >
            <CloudCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Kayıtlı</span>
          </div>
        </div>

        {/* Right Actions: Audio, Dual Page, iPad Guide, Undo, Redo, Zoom, Export, Pages */}
        <div className="flex items-center gap-0.5 sm:gap-1.5 shrink-0">
          {/* Audio Lecture Recorder */}
          <button
            onClick={() => setIsAudioBarOpen(!isAudioBarOpen)}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              isAudioBarOpen || (currentPage.audioRecordings && currentPage.audioRecordings.length > 0)
                ? 'text-rose-600 bg-rose-50 hover:bg-rose-100'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
            title="Ders Ses Kaydedicisi (Audio Bar)"
          >
            <Mic className="w-4 h-4" />
          </button>

          {/* Dual Page Toggle (Book View) */}
          <button
            onClick={() => {
              setIsDualPage(!isDualPage);
              showToast(!isDualPage ? 'Çift Sayfa Modu Açıldı' : 'Tek Sayfa Modu');
              requestRender();
            }}
            className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
              isDualPage
                ? 'bg-blue-50 text-blue-600 border border-blue-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
            title="Yatay Çift Sayfa Kitap Modu"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Çift Sayfa</span>
          </button>

          {/* iPad & Pencil Setup Guide */}
          <button
            onClick={() => setIsIPadGuideOpen(true)}
            className="hidden lg:flex items-center gap-1 px-2 py-1.5 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors cursor-pointer"
            title="iPad 6 ve Apple Pencil Rehberi"
          >
            <Tablet className="w-3.5 h-3.5 text-blue-600" />
            <span>iPad</span>
          </button>

          <button
            onClick={handleUndo}
            disabled={undoStack.length === 0}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="Geri Al (Ctrl+Z)"
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button
            onClick={handleRedo}
            disabled={redoStack.length === 0}
            className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            title="İleri Al (Ctrl+Y)"
          >
            <Redo2 className="w-4 h-4" />
          </button>

          <button
            onClick={fitPage}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            title="Sayfayı Ekrana Sığdır"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="font-mono">{Math.round(view.scale * 100)}%</span>
          </button>

          {/* Export / Share Dropdown */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsExportMenuOpen(!isExportMenuOpen);
              }}
              className="p-2 rounded-xl text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
              title="Paylaş ve Dışa Aktar"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {isExportMenuOpen && (
              <div
                className="absolute right-0 top-12 z-50 w-56 bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200/90 py-1.5 animate-in fade-in slide-in-from-top-2 duration-100"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  Dışa Aktar & Paylaş
                </div>
                <button
                  onClick={handleExportPDF}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left"
                >
                  <FileDown className="w-4 h-4 text-blue-500" />
                  <span>Tüm Defteri PDF İndir</span>
                </button>
                <button
                  onClick={() => handleExportSinglePage('png')}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left"
                >
                  <ImageIcon className="w-4 h-4 text-emerald-500" />
                  <span>Aktif Sayfayı Resim (PNG) İndir</span>
                </button>
                <button
                  onClick={handleCopyPageToClipboard}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left"
                >
                  <Copy className="w-4 h-4 text-purple-500" />
                  <span>Aktif Sayfayı Panoya Kopyala</span>
                </button>
              </div>
            )}
          </div>

          <button
            onClick={() => setIsSidebarOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-all cursor-pointer ml-1"
            title="Sayfa Listesi & Şablonlar"
          >
            <Layers className="w-4 h-4" />
            <span className="hidden md:inline">Sayfalar</span>
          </button>
        </div>
      </header>

      {/* Canvas Wrap Viewport */}
      <div
        ref={wrapRef}
        className="flex-1 relative overflow-hidden bg-[#cfcfd4] touch-none"
        style={{ cursor: activeTool === 'hand' ? 'grab' : 'crosshair' }}
      >
        <canvas ref={bgCanvasRef} className="canvas-layer pointer-events-none" />
        <canvas
          ref={strokeCanvasRef}
          className="canvas-layer touch-none"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onPointerLeave={() => {
            liveRef.current.hoverPos = null;
            requestRender();
          }}
          onWheel={handleWheel}
          onContextMenu={(e) => e.preventDefault()}
          onDoubleClick={fitPage}
        />

        {/* Interactive Ruler / Protractor Overlay */}
        {ruler.visible && (
          <div
            className="absolute pointer-events-auto select-none"
            style={{
              left: `${ruler.x * view.scale + view.offsetX}px`,
              top: `${ruler.y * view.scale + view.offsetY}px`,
              transform: `translate(-50%, -50%) rotate(${ruler.angle}deg)`,
              transformOrigin: 'center center',
            }}
          >
            {/* Ruler Body */}
            <div
              className={`relative bg-white/80 backdrop-blur-md rounded-2xl border-2 border-blue-500/40 shadow-2xl flex items-center justify-between cursor-move ${
                ruler.mode === 'ruler' ? 'h-18' : 'h-36 rounded-t-full rounded-b-none border-b-4'
              }`}
              style={{ width: `${ruler.length * view.scale}px` }}
              onPointerDown={(e) => {
                e.stopPropagation();
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                liveRef.current.rulerDrag = {
                  startX: e.clientX,
                  startY: e.clientY,
                  origRx: ruler.x,
                  origRy: ruler.y,
                };
              }}
              onPointerMove={(e) => {
                if (liveRef.current.rulerDrag) {
                  const rd = liveRef.current.rulerDrag;
                  const dx = (e.clientX - rd.startX) / view.scale;
                  const dy = (e.clientY - rd.startY) / view.scale;
                  setRuler((prev) => ({
                    ...prev,
                    x: rd.origRx + dx,
                    y: rd.origRy + dy,
                  }));
                }
              }}
              onPointerUp={(e) => {
                liveRef.current.rulerDrag = null;
                try {
                  (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
                } catch (err) {}
              }}
            >
              {/* Metric Centimeter Ticks Along Top Edge */}
              <div className="absolute top-0 left-0 right-0 flex justify-between px-3 pointer-events-none">
                {Array.from({ length: 13 }).map((_, i) => (
                  <div key={i} className="flex flex-col items-center">
                    <div className="w-0.5 h-3 bg-slate-900" />
                    <span className="text-[10px] font-bold text-slate-800 mt-0.5">{i}</span>
                  </div>
                ))}
              </div>

              {/* Center Angle Badge & Controls */}
              <div
                className="mx-auto flex items-center gap-1.5 p-1 bg-white/90 backdrop-blur-sm rounded-xl shadow-md border border-slate-200/80 pointer-events-auto"
                onPointerDown={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() =>
                    setRuler((prev) => ({
                      ...prev,
                      mode: prev.mode === 'ruler' ? 'protractor' : 'ruler',
                    }))
                  }
                  className="px-2 py-0.5 text-[11px] font-bold rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 cursor-pointer"
                  title="Cetvel / Açıölçer Modu Değiştir"
                >
                  {ruler.mode === 'ruler' ? '📐 Cetvel' : '🧭 Açıölçer'}
                </button>

                <button
                  onClick={() =>
                    setRuler((prev) => ({
                      ...prev,
                      angle: (prev.angle + 45) % 360,
                    }))
                  }
                  className="p-1 rounded-lg text-slate-600 hover:bg-slate-100 cursor-pointer"
                  title="45° Döndür"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                <span className="px-1.5 font-mono text-xs font-bold text-blue-700 min-w-[32px] text-center">
                  {Math.round(ruler.angle)}°
                </span>

                <button
                  onClick={() => setRuler((prev) => ({ ...prev, angle: 0 }))}
                  className="px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 hover:bg-slate-100 rounded cursor-pointer"
                  title="0° Sıfırla"
                >
                  0°
                </button>
              </div>

              {/* Rotation Handle Right */}
              <div
                className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md cursor-grab active:cursor-grabbing pointer-events-auto hover:scale-115 transition-transform"
                title="Döndürmek için sürükleyin"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                  const centerScreenX = ruler.x * view.scale + view.offsetX;
                  const centerScreenY = ruler.y * view.scale + view.offsetY;
                  const initialAngle = (Math.atan2(e.clientY - centerScreenY, e.clientX - centerScreenX) * 180) / Math.PI;

                  liveRef.current.rulerRotate = {
                    startAngle: initialAngle,
                    initialRulerAngle: ruler.angle,
                    cx: centerScreenX,
                    cy: centerScreenY,
                  };
                }}
                onPointerMove={(e) => {
                  if (liveRef.current.rulerRotate) {
                    const rr = liveRef.current.rulerRotate;
                    const curAngle = (Math.atan2(e.clientY - rr.cy, e.clientX - rr.cx) * 180) / Math.PI;
                    const delta = curAngle - rr.startAngle;
                    let target = Math.round(rr.initialRulerAngle + delta);
                    // Snap near 0, 30, 45, 60, 90, 180
                    const snaps = [0, 30, 45, 60, 90, 120, 135, 150, 180, 270, 360];
                    for (const snap of snaps) {
                      if (Math.abs(target - snap) < 3.5) {
                        target = snap;
                        break;
                      }
                    }
                    setRuler((prev) => ({ ...prev, angle: (target + 360) % 360 }));
                  }
                }}
                onPointerUp={(e) => {
                  liveRef.current.rulerRotate = null;
                  try {
                    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
                  } catch (err) {}
                }}
              >
                <RotateCw className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        )}

        {/* Inline Text Editor Overlay */}
        {editingTextPos && (
          <div
            className="absolute z-40 bg-white rounded-2xl shadow-2xl border-2 border-blue-500 p-3 flex flex-col gap-2 min-w-[260px]"
            style={{
              left: `${editingTextPos.x * view.scale + view.offsetX}px`,
              top: `${editingTextPos.y * view.scale + view.offsetY}px`,
            }}
          >
            <textarea
              autoFocus
              value={editingTextValue}
              onChange={(e) => setEditingTextValue(e.target.value)}
              placeholder="Notunuzu yazın..."
              rows={3}
              className="w-full text-sm font-semibold bg-transparent border-0 outline-none resize-y text-slate-800"
              style={{
                fontSize: `${Math.max(14, (tools.text.size || 22) * 0.9)}px`,
                color: tools.text.color || '#1c1c1e',
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSaveTextEditor();
                } else if (e.key === 'Escape') {
                  setEditingTextIndex(null);
                  setEditingTextPos(null);
                }
              }}
            />
            <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setEditingTextIndex(null);
                  setEditingTextPos(null);
                }}
                className="px-2.5 py-1 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                İptal
              </button>
              <button
                type="button"
                onClick={handleSaveTextEditor}
                className="px-3 py-1 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs cursor-pointer"
              >
                Tamam
              </button>
            </div>
          </div>
        )}

        {/* Lasso Selection Box Overlay */}
        {selectionBox && (
          <div
            className="absolute pointer-events-none border-2 border-dashed border-blue-500 bg-blue-500/10 rounded-sm z-30"
            style={{
              left: `${selectionBox.x1 * view.scale + view.offsetX}px`,
              top: `${selectionBox.y1 * view.scale + view.offsetY}px`,
              width: `${(selectionBox.x2 - selectionBox.x1) * view.scale}px`,
              height: `${(selectionBox.y2 - selectionBox.y1) * view.scale}px`,
            }}
          />
        )}

        {/* Floating Bottom Dock */}
        <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-40 max-w-[calc(100vw-20px)] flex items-center gap-1.5 p-1.5 sm:p-2 bg-slate-900/95 backdrop-blur-2xl rounded-2xl shadow-2xl border border-white/15 overflow-x-auto no-scrollbar touch-pan-x select-none">
          {/* Hand Tool (Gezinme / Kaydırma) */}
          <button
            onClick={() => {
              setActiveTool('hand');
              setIsShapeMenuOpen(false);
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTool === 'hand'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="✋ Gezinme Modu (Tek parmakla kaydır, iki parmakla yakınlaştır - çizim yapmaz)"
          >
            <Hand className="w-5 h-5" />
          </button>

          <div className="h-6 w-px bg-white/15 mx-0.5 shrink-0" />

          {/* Main Drawing Tools Group (Tekrar tıklayınca veya basılı tutunca araca özel ayarlar açılır) */}
          <div className="flex items-center gap-1 p-1 bg-white/10 rounded-xl shrink-0">
            {/* Pen Tool */}
            <button
              onClick={() => {
                if (activeTool === 'pen') {
                  setIsQuickSettingsOpen((prev) => !prev);
                } else {
                  setActiveTool('pen');
                  setIsQuickSettingsOpen(false);
                }
                setIsShapeMenuOpen(false);
              }}
              onPointerDown={() => startLongPress('pen')}
              onPointerUp={cancelLongPress}
              onPointerLeave={cancelLongPress}
              className={`relative p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'pen'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Kalem (Ayarlar için tekrar tıklayın veya basılı tutun)"
            >
              <PenTool className="w-5 h-5" />
              {activeTool === 'pen' && (
                <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white ring-1 ring-blue-600" />
              )}
            </button>

            {/* Highlighter Tool */}
            <button
              onClick={() => {
                if (activeTool === 'highlighter') {
                  setIsQuickSettingsOpen((prev) => !prev);
                } else {
                  setActiveTool('highlighter');
                  setIsQuickSettingsOpen(false);
                }
                setIsShapeMenuOpen(false);
              }}
              onPointerDown={() => startLongPress('highlighter')}
              onPointerUp={cancelLongPress}
              onPointerLeave={cancelLongPress}
              className={`relative p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'highlighter'
                  ? 'bg-amber-500 text-slate-900 shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Fosforlu Kalem (Ayarlar için tekrar tıklayın veya basılı tutun)"
            >
              <Highlighter className="w-5 h-5" />
              {activeTool === 'highlighter' && (
                <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-slate-900" />
              )}
            </button>

            {/* Laser Tool */}
            <button
              onClick={() => {
                setActiveTool('laser');
                setIsShapeMenuOpen(false);
                setIsQuickSettingsOpen(false);
              }}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'laser'
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Lazer İşaretçi (2 sn içinde kaybolur)"
            >
              <Sparkles className="w-5 h-5 text-red-300" />
            </button>

            {/* Eraser Tool */}
            <button
              onClick={() => {
                if (activeTool === 'eraser' || activeTool === 'stroke-eraser') {
                  setIsQuickSettingsOpen((prev) => !prev);
                } else {
                  setActiveTool('eraser');
                  setIsQuickSettingsOpen(false);
                }
                setIsShapeMenuOpen(false);
              }}
              onPointerDown={() => startLongPress('eraser')}
              onPointerUp={cancelLongPress}
              onPointerLeave={cancelLongPress}
              className={`relative p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'eraser' || activeTool === 'stroke-eraser'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Silgi (Hassas / Çizgi silgisi ayarları için tekrar tıklayın veya basılı tutun)"
            >
              <Eraser className="w-5 h-5" />
              {(activeTool === 'eraser' || activeTool === 'stroke-eraser') && (
                <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white ring-1 ring-blue-600" />
              )}
            </button>

            {/* Stroke Eraser (Çizgi Silgisi) */}
            <button
              onClick={() => {
                setActiveTool('stroke-eraser');
                setIsShapeMenuOpen(false);
                setIsQuickSettingsOpen(false);
              }}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'stroke-eraser'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Çizgi Silgisi (Dokunulan çizgiyi tamamen siler)"
            >
              <Scissors className="w-5 h-5" />
            </button>

            {/* Lasso Tool */}
            <button
              onClick={() => {
                setActiveTool('lasso');
                setIsShapeMenuOpen(false);
                setIsQuickSettingsOpen(false);
              }}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                activeTool === 'lasso'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Kement / Seçim Aracı (Çizimleri seçip taşıyın veya kopyalayın)"
            >
              <Square className="w-5 h-5 border-dashed" />
            </button>
          </div>

          {/* Interactive Ruler Toggle */}
          <button
            onClick={() => {
              setRuler((prev) => ({ ...prev, visible: !prev.visible }));
              setIsShapeMenuOpen(false);
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              ruler.visible
                ? 'bg-amber-500 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="📐 Cetvel / Açıölçer (Kenarından çizerek düz çizgi çekin)"
          >
            <Ruler className="w-5 h-5" />
          </button>

          {/* Interactive Compass Toggle (Pergel) */}
          <button
            onClick={() => {
              setCompass((prev) => ({ ...prev, visible: !prev.visible }));
              setIsShapeMenuOpen(false);
              requestRender();
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              compass.visible
                ? 'bg-amber-500 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="🧭 İnteraktif Pergel (Daire ve yay çizimi)"
          >
            <Compass className="w-5 h-5" />
          </button>

          {/* Shape Dimensions Inspector (Ölçü & Açı Etiketleri) */}
          <button
            onClick={() => {
              setIsInspectorOpen(!isInspectorOpen);
              showToast(!isInspectorOpen ? 'Şekil ölçü etiketleri açık' : 'Ölçü etiketleri kapalı');
              requestRender();
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              isInspectorOpen
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="📏 Şekil Kenar & Açı Ölçüm Müfettişi (cm / °)"
          >
            <Calculator className="w-5 h-5" />
          </button>

          {/* Function Plotter Modal Toggle */}
          <button
            onClick={() => setIsFunctionPlotterOpen(true)}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0 font-serif italic font-bold text-sm"
            title="📈 Matematik Fonksiyon Grafiği [f(x)] Çizici"
          >
            f(x)
          </button>

          {/* Zoom Writing Box Toggle */}
          <button
            onClick={() => {
              setIsZoomBoxOpen(!isZoomBoxOpen);
              showToast(!isZoomBoxOpen ? 'Büyüteç yazma kutusu açıldı' : 'Büyüteç kutusu kapandı');
              requestRender();
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              isZoomBoxOpen
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="🔍 Büyüteç Yazma Kutusu (GoodNotes tarzı hassas el yazısı)"
          >
            <ZoomIn className="w-5 h-5" />
          </button>

          {/* Custom Paper Templates Toggle */}
          <button
            onClick={() => setIsCustomPaperOpen(true)}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            title="📑 Özel Kağıt & Şablon Tasarla (Cornell, İzometrik, Müzik, Kareli)"
          >
            <Grid className="w-5 h-5" />
          </button>

          {/* Smart Shape Quick Toggle (El yazısı / Otomatik Geometri Aç-Kapa) */}
          <button
            onClick={() => {
              const nextVal = !tools.pen.smartShape;
              updateToolSettings({ smartShape: nextVal });
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 text-xs font-bold ${
              tools.pen.smartShape
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-xs'
                : 'text-slate-400 hover:text-white hover:bg-white/10'
            }`}
            title={
              tools.pen.smartShape
                ? 'Akıllı Geometri AÇIK (Çizilen üçgen/çember düzeltilir - Kapatmak için tıklayın, el yazınız korunur)'
                : 'Akıllı Geometri KAPALI (El yazısı ve harfler olduğu gibi korunur - Açmak için tıklayın)'
            }
          >
            <Sparkles className="w-4 h-4" />
            <span className="hidden sm:inline">
              {tools.pen.smartShape ? 'Şekil: Açık' : 'Şekil: Kapalı'}
            </span>
          </button>

          {/* Geometric Shapes Button */}
          <button
            onClick={() => {
              if (
                !['rect', 'ellipse', 'triangle', 'line', 'arrow', 'right-angle', 'angle-arc', 'coord-axes'].includes(
                  activeTool
                )
              ) {
                setActiveTool('rect');
                setIsShapeMenuOpen(true);
                showToast('Geometri modu: Dikdörtgen seçildi');
              } else {
                setIsShapeMenuOpen((prev) => !prev);
              }
              setIsQuickSettingsOpen(false);
            }}
            className={`p-2 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 ${
              ['rect', 'ellipse', 'triangle', 'line', 'arrow', 'right-angle', 'angle-arc', 'coord-axes'].includes(
                activeTool
              )
                ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-400/50'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="Geometrik Şekiller & Çizim Araçları (Dikdörtgen, Daire, Üçgen, Çizgi, Ok, Dik Açı, X-Y)"
          >
            {activeTool === 'ellipse' ? (
              <Circle className="w-5 h-5" />
            ) : activeTool === 'triangle' ? (
              <Triangle className="w-5 h-5" />
            ) : activeTool === 'line' ? (
              <Minus className="w-5 h-5" />
            ) : activeTool === 'arrow' ? (
              <MoveRight className="w-5 h-5" />
            ) : activeTool === 'right-angle' ? (
              <Square className="w-5 h-5" />
            ) : activeTool === 'coord-axes' ? (
              <Grid className="w-5 h-5" />
            ) : (
              <Square className="w-5 h-5" />
            )}
          </button>

          {/* Text Tool */}
          <button
            onClick={() => {
              setActiveTool('text');
              setIsShapeMenuOpen(false);
            }}
            className={`p-2 rounded-xl transition-all cursor-pointer shrink-0 ${
              activeTool === 'text'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-white/10'
            }`}
            title="Metin Yaz"
          >
            <Type className="w-5 h-5" />
          </button>

          {/* Active Color Swatch */}
          <button
            onClick={() => setIsColorPickerOpen(true)}
            className="w-8 h-8 rounded-full border-2 border-white/50 shadow-inner hover:scale-110 active:scale-95 transition-transform cursor-pointer shrink-0 mx-1"
            style={{ backgroundColor: activeColor }}
            title="Renk Değiştir"
          />

          <div className="h-6 w-px bg-white/15 mx-0.5 shrink-0" />

          {/* Secondary Actions Group (Stickers, Image, PDF) */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => setIsStickerModalOpen(true)}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Çıkartma / Emoji Ekle"
            >
              <Smile className="w-5 h-5" />
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Görsel Ekle"
            >
              <ImageIcon className="w-5 h-5" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleInsertImage}
              accept="image/*"
              className="hidden"
            />

            <button
              onClick={() => pdfInputRef.current?.click()}
              className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="PDF İçe Aktar"
            >
              <FileUp className="w-5 h-5" />
            </button>
            <input
              type="file"
              ref={pdfInputRef}
              onChange={handleImportPDF}
              accept="application/pdf"
              className="hidden"
            />
          </div>
        </div>

        {/* Quick Settings Popover */}
        {isQuickSettingsOpen && (
          <QuickSettingsPopover
            tool={activeTool}
            settings={tools}
            palmRejection={palmRejection}
            onTogglePalmRejection={setPalmRejection}
            onChangeSettings={updateToolSettings}
            onClearPage={handleClearPage}
            onClose={() => setIsQuickSettingsOpen(false)}
          />
        )}

        {/* Floating Shape Selector Popover (Outside dock so it is never clipped) */}
        {isShapeMenuOpen && (
          <div className="fixed inset-0 z-50 pointer-events-none flex items-end justify-center pb-20 sm:pb-22">
            {/* Backdrop to tap outside to close */}
            <div
              className="fixed inset-0 pointer-events-auto bg-black/20 backdrop-blur-[1px]"
              onClick={() => setIsShapeMenuOpen(false)}
            />

            <div className="relative pointer-events-auto bg-slate-900/98 backdrop-blur-2xl border border-white/20 p-2 sm:p-2.5 rounded-2xl shadow-2xl flex items-center gap-1.5 sm:gap-2 animate-in fade-in slide-in-from-bottom-3 duration-150 max-w-[calc(100vw-24px)] overflow-x-auto no-scrollbar">
              <span className="text-[11px] font-bold text-slate-400 px-2 shrink-0">Şekiller:</span>

              <button
                onClick={() => {
                  setActiveTool('rect');
                  setIsShapeMenuOpen(false);
                  showToast('Dikdörtgen / Kare aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'rect' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Dikdörtgen & Kare"
              >
                <Square className="w-4 h-4" />
                <span>Dikdörtgen</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('ellipse');
                  setIsShapeMenuOpen(false);
                  showToast('Daire / Elips aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'ellipse' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Daire & Elips"
              >
                <Circle className="w-4 h-4" />
                <span>Daire</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('triangle');
                  setIsShapeMenuOpen(false);
                  showToast('Üçgen aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'triangle' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Üçgen"
              >
                <Triangle className="w-4 h-4" />
                <span>Üçgen</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('line');
                  setIsShapeMenuOpen(false);
                  showToast('Düz çizgi aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'line' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Düz Çizgi"
              >
                <Minus className="w-4 h-4" />
                <span>Çizgi</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('arrow');
                  setIsShapeMenuOpen(false);
                  showToast('Ok çizim aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'arrow' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Ok Çizimi"
              >
                <MoveRight className="w-4 h-4" />
                <span>Ok</span>
              </button>

              <div className="h-5 w-px bg-white/20 shrink-0" />

              <button
                onClick={() => {
                  setActiveTool('right-angle');
                  setIsShapeMenuOpen(false);
                  showToast('Dik açı sembolü (90°) seçildi');
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'right-angle' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Dik Açı Sembolü (⦜ 90°)"
              >
                <span className="font-mono text-xs font-bold text-amber-300">⦜</span>
                <span>Dik Açı</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('angle-arc');
                  setIsShapeMenuOpen(false);
                  showToast('Açı yayı (∠ θ) seçildi');
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'angle-arc' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="Açı Yayı ve Derece Sembolü (∠ θ)"
              >
                <span className="font-mono text-xs font-bold text-amber-300">∠</span>
                <span>Açı Yayı</span>
              </button>

              <button
                onClick={() => {
                  setActiveTool('coord-axes');
                  setIsShapeMenuOpen(false);
                  showToast('X-Y Koordinat Düzlemi aracı seçildi');
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                  activeTool === 'coord-axes' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-300 hover:bg-white/10'
                }`}
                title="X-Y Koordinat Düzlemi Ekle"
              >
                <Grid className="w-3.5 h-3.5 text-blue-400" />
                <span>+ X-Y</span>
              </button>

              <button
                onClick={() => setIsShapeMenuOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer ml-1 shrink-0"
                title="Kapat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Pages Sidebar */}
      <PagesSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        pages={pages}
        currentPageIndex={currentPageIndex}
        onSelectPage={(idx) => {
          onSelectPageIndex(idx);
          setIsSidebarOpen(false);
        }}
        onAddPage={() => {
          pushUndo();
          const newPage: PageData = {
            id: `p_${Date.now()}_add`,
            type: currentPage.type,
            bg: currentPage.bg,
            width: currentPage.width,
            height: currentPage.height,
            pdfDataUrl: null,
            strokes: [],
          };
          const updatedPages = [...pages];
          updatedPages.splice(currentPageIndex + 1, 0, newPage);
          onUpdatePages(updatedPages);
          onSelectPageIndex(currentPageIndex + 1);
        }}
        onDuplicatePage={handleDuplicatePage}
        onDeletePage={handleDeletePage}
        onChangePageStyle={handleChangePageStyle}
        onChangePageBg={handleChangePageBg}
        onToggleBookmark={(idx) => {
          const updatedPages = [...pages];
          updatedPages[idx] = {
            ...updatedPages[idx],
            bookmarked: !updatedPages[idx].bookmarked,
          };
          onUpdatePages(updatedPages);
        }}
        onOpenCustomPaper={() => {
          setIsSidebarOpen(false);
          setIsCustomPaperOpen(true);
        }}
      />

      {/* Audio Recorder Bar */}
      {isAudioBarOpen && (
        <div className="fixed top-15 right-4 z-40 animate-in fade-in slide-in-from-top-2">
          <AudioRecorderBar
            recordings={currentPage.audioRecordings || []}
            onAddRecording={handleAddAudioRecording}
            onDeleteRecording={handleDeleteAudioRecording}
            onClose={() => setIsAudioBarOpen(false)}
          />
        </div>
      )}

      {/* Zoom Writing Box (GoodNotes Tarzı) */}
      {isZoomBoxOpen && (
        <ZoomWritingBox
          isOpen={isZoomBoxOpen}
          onClose={() => {
            setIsZoomBoxOpen(false);
            requestRender();
          }}
          pageWidth={currentPage.width}
          pageHeight={currentPage.height}
          focusPos={zoomFocusPos}
          onMoveFocusPos={(newPos) => {
            setZoomFocusPos(newPos);
            requestRender();
          }}
          strokes={strokesRef.current}
          currentStroke={liveRef.current.currentStroke}
          toolSettings={tools[activeTool]}
          onAddStroke={(stroke) => {
            pushUndo();
            strokesRef.current = [...strokesRef.current, stroke];
            const updatedPages = [...pages];
            updatedPages[currentPageIndex] = {
              ...currentPage,
              strokes: strokesRef.current,
            };
            onUpdatePages(updatedPages);
            requestRender();
          }}
        />
      )}

      {/* Function Plotter Modal [f(x)] */}
      <FunctionPlotterModal
        isOpen={isFunctionPlotterOpen}
        onClose={() => setIsFunctionPlotterOpen(false)}
        centerPos={{ x: currentPage.width / 2, y: currentPage.height / 2 }}
        onInsertPlot={(plotItems) => {
          pushUndo();
          strokesRef.current = [...strokesRef.current, ...plotItems];
          const updatedPages = [...pages];
          updatedPages[currentPageIndex] = {
            ...currentPage,
            strokes: strokesRef.current,
          };
          onUpdatePages(updatedPages);
          setIsFunctionPlotterOpen(false);
          showToast('f(x) fonksiyon grafiği sayfaya eklendi');
          requestRender();
        }}
      />

      {/* Custom Paper & Template Modal (Cornell, İzometrik vb.) */}
      <CustomPaperModal
        isOpen={isCustomPaperOpen}
        onClose={() => setIsCustomPaperOpen(false)}
        currentConfig={currentPage.customPaper}
        onApplyTemplate={(config, applyToAll) => {
          pushUndo();
          const updatedPages = pages.map((p, idx) => {
            if (applyToAll || idx === currentPageIndex) {
              return {
                ...p,
                type: 'custom' as PageStyle,
                customPaper: config,
                bg: config.bgColor,
              };
            }
            return p;
          });
          onUpdatePages(updatedPages);
          setIsCustomPaperOpen(false);
          showToast(applyToAll ? 'Şablon tüm sayfalara uygulandı' : 'Özel kağıt şablonu uygulandı');
          requestRender();
        }}
      />

      {/* iPad Installation & Apple Pencil Guide Modal */}
      <IPadInstallModal
        isOpen={isIPadGuideOpen}
        onClose={() => setIsIPadGuideOpen(false)}
      />

      {/* Virtual Compass Floating Action Bar */}
      {compass.visible && (
        <div className="absolute bottom-22 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 backdrop-blur-xl border border-white/15 px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-2 select-none text-white max-w-[calc(100vw-32px)] overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 shrink-0">
            <Compass className="w-4 h-4" />
            <span>Pergel</span>
          </div>
          <div className="h-4 w-px bg-white/20 shrink-0" />
          {/* Radius controls */}
          <div className="flex items-center gap-1.5 text-xs shrink-0">
            <span className="text-slate-300">Yarıçap (r):</span>
            <button
              onClick={() => {
                setCompass((prev) => ({ ...prev, radius: Math.max(30, prev.radius - 15) }));
                requestRender();
              }}
              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold text-sm cursor-pointer"
              title="Yarıçapı Küçült"
            >
              -
            </button>
            <span className="font-mono font-bold text-blue-300 min-w-[50px] text-center">
              {(compass.radius / 40).toFixed(1)} cm
            </span>
            <button
              onClick={() => {
                setCompass((prev) => ({ ...prev, radius: Math.min(600, prev.radius + 15) }));
                requestRender();
              }}
              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center font-bold text-sm cursor-pointer"
              title="Yarıçapı Büyüt"
            >
              +
            </button>
          </div>
          <div className="h-4 w-px bg-white/20 shrink-0" />
          {/* Draw Circle Action */}
          <button
            onClick={() => {
              pushUndo();
              const circleItem: ShapeStroke = {
                id: 'shp_circle_' + Date.now(),
                type: 'shape',
                shape: 'ellipse',
                x1: compass.x - compass.radius,
                y1: compass.y - compass.radius,
                x2: compass.x + compass.radius,
                y2: compass.y + compass.radius,
                color: tools.pen.color,
                size: tools.pen.size,
                opacity: tools.pen.opacity,
                fill: false,
                lineCap: 'round',
              };
              strokesRef.current = [...strokesRef.current, circleItem];
              const updatedPages = [...pages];
              updatedPages[currentPageIndex] = {
                ...currentPage,
                strokes: strokesRef.current,
              };
              onUpdatePages(updatedPages);
              showToast('Kusursuz çember çizildi');
              requestRender();
            }}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md cursor-pointer flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
          >
            <Circle className="w-3.5 h-3.5" />
            <span>Çemberi Çiz</span>
          </button>
          {/* Center compass */}
          <button
            onClick={() => {
              const centerWorld = toWorld(window.innerWidth / 2, window.innerHeight / 2);
              setCompass((prev) => ({ ...prev, x: centerWorld.x, y: centerWorld.y }));
              requestRender();
            }}
            className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold cursor-pointer shrink-0"
            title="Pergel İğnesini Ekrana Ortala"
          >
            Ortala
          </button>
          <button
            onClick={() => {
              setCompass((prev) => ({ ...prev, visible: false }));
              requestRender();
            }}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer shrink-0 ml-1"
            title="Pergeli Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Color Picker Modal */}
      <ColorPickerModal
        isOpen={isColorPickerOpen}
        onClose={() => setIsColorPickerOpen(false)}
        currentColor={activeColor}
        onSelectColor={handleSelectColor}
        recentColors={recentColors}
      />

      {/* Sticker Modal */}
      <StickerModal
        isOpen={isStickerModalOpen}
        onClose={() => setIsStickerModalOpen(false)}
        onSelectSticker={handleInsertSticker}
      />

      {/* Toast Notice */}
      {toastNotice && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white px-4 py-2 rounded-2xl shadow-xl text-xs font-semibold flex items-center gap-2 border border-white/10 animate-in fade-in slide-in-from-top-2 duration-150 pointer-events-none">
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span>{toastNotice}</span>
        </div>
      )}

      {/* Loading Overlay */}
      {loadingMsg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs">
          <div className="bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-white/10 animate-in fade-in">
            <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
            <span className="text-sm font-semibold">{loadingMsg}</span>
          </div>
        </div>
      )}
    </div>
  );
}
