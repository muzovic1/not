import { useState } from 'react';
import { X, Search } from 'lucide-react';

interface StickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSticker: (emoji: string) => void;
}

const CATEGORIES: Record<string, string[]> = {
  'Geometri & Matematik': [
    '📐', '📏', '🧮', '🔺', '🔹', '🔷', '🔶', '⬛', '⚪', '⭕', '🔴', '🔵',
    '➕', '➖', '✖️', '➗', '♾️', '💡', '🧠', '⚙️', '🔍', '📊', '📈', '🔬'
  ],
  'Ders & Notlar': [
    '📝', '✏️', '🖊️', '📚', '📖', '📌', '📍', '📎', '📋', '🗓️', '⏰', '⌛',
    '🎯', '🏆', '🥇', '⭐', '🌟', '✨', '🔥', '💯', '✅', '❌', '⚠️', '❗'
  ],
  'İfadeler': [
    '😀', '😃', '😄', '😁', '🤓', '😎', '🧐', '🤔', '💡', '🥳', '🤩', '😇',
    '🙂', '😌', '💪', '👍', '👏', '🙌', '🙏', '❤️', '💙', '💜', '🌈', '☕'
  ],
  'Çevre & Nesneler': [
    '🚀', '🌍', '🪐', '🎨', '🎵', '🎹', '💻', '🖥️', '📱', '🔋', '💎', '🔑',
    '🌱', '🌿', '🌸', '🌻', '🍎', '🍕', '⚽', '🏀', '🎮', '🧩', '🎁', '🎉'
  ]
};

export function StickerModal({ isOpen, onClose, onSelectSticker }: StickerModalProps) {
  const [activeTab, setActiveTab] = useState<string>('Geometri & Matematik');
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const currentEmojis = search.trim()
    ? Object.values(CATEGORIES).flat()
    : CATEGORIES[activeTab] || [];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/45 backdrop-blur-xs animate-in fade-in duration-100">
      <div className="relative w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[75vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <h3 className="text-base font-bold text-slate-800">Çıkartma & Geometri Ekle</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-5 pt-3 pb-2">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Çıkartmalarda ara..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-100 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
          </div>
        </div>

        {/* Category Tabs */}
        {!search.trim() && (
          <div className="flex items-center gap-1 px-5 py-1.5 overflow-x-auto no-scrollbar border-b border-slate-100">
            {Object.keys(CATEGORIES).map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveTab(cat)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Grid of Emojis */}
        <div className="flex-1 overflow-y-auto p-5 grid grid-cols-6 sm:grid-cols-6 gap-2">
          {currentEmojis.map((emoji, idx) => (
            <button
              key={`${emoji}_${idx}`}
              onClick={() => {
                onSelectSticker(emoji);
                onClose();
              }}
              className="aspect-square text-3xl flex items-center justify-center rounded-2xl hover:bg-slate-100 hover:scale-115 active:scale-95 transition-all cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
