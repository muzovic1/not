import { useEffect, useRef, useState } from 'react';
import { PageData, PageStyle } from '../types.ts';
import { renderThumbnail } from '../utils/canvasRenderer.ts';
import { X, Plus, Copy, Trash2, Search, ArrowRight, Bookmark, Star, Grid } from 'lucide-react';

interface PagesSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  pages: PageData[];
  currentPageIndex: number;
  onSelectPage: (index: number) => void;
  onAddPage: () => void;
  onDuplicatePage: () => void;
  onDeletePage: () => void;
  onChangePageStyle: (style: PageStyle) => void;
  onChangePageBg: (color: string) => void;
  onToggleBookmark?: (index: number) => void;
  onOpenCustomPaper?: () => void;
}

export function PagesSidebar({
  isOpen,
  onClose,
  pages,
  currentPageIndex,
  onSelectPage,
  onAddPage,
  onDuplicatePage,
  onDeletePage,
  onChangePageStyle,
  onChangePageBg,
  onToggleBookmark,
  onOpenCustomPaper,
}: PagesSidebarProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'bookmarks'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [jumpPageStr, setJumpPageStr] = useState('');
  const currentPage = pages[currentPageIndex];

  const bookmarkedCount = pages.filter((p) => p.bookmarked).length;

  // Filter pages based on text elements and bookmarks
  const matchingIndices = pages
    .map((page, idx) => {
      if (activeTab === 'bookmarks' && !page.bookmarked) return -1;
      if (!searchQuery.trim()) return idx;
      const q = searchQuery.toLowerCase();
      const hasMatch = page.strokes.some(
        (s) => s.type === 'text' && s.text.toLowerCase().includes(q)
      );
      return hasMatch ? idx : -1;
    })
    .filter((idx) => idx !== -1);

  const handleJump = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parseInt(jumpPageStr, 10);
    if (!isNaN(p) && p >= 1 && p <= pages.length) {
      onSelectPage(p - 1);
      setJumpPageStr('');
    }
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/25 backdrop-blur-2xs transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Slide-over panel */}
      <aside
        className={`fixed top-0 left-0 bottom-0 z-50 w-80 max-w-[85vw] bg-white/95 backdrop-blur-xl border-r border-slate-200/80 shadow-2xl flex flex-col transition-transform duration-250 ease-out select-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Sayfalar</h2>
              <p className="text-xs font-medium text-slate-400">
                Toplam {pages.length} sayfa · Sayfa {currentPageIndex + 1} aktif
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Tabs: All Pages & Bookmarks */}
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setActiveTab('all')}
              className={`py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Tüm Sayfalar ({pages.length})
            </button>
            <button
              onClick={() => setActiveTab('bookmarks')}
              className={`flex items-center justify-center gap-1.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'bookmarks'
                  ? 'bg-white text-amber-600 shadow-xs'
                  : 'text-slate-500 hover:text-amber-600'
              }`}
            >
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span>Yer İmleri ({bookmarkedCount})</span>
            </button>
          </div>

          {/* Search text inside notes */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Metinlerde ara..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-100 border border-slate-200/80 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
            />
          </div>

          {/* Quick Page Jump & Actions */}
          <div className="flex items-center gap-1.5">
            <form onSubmit={handleJump} className="flex-1 flex items-center gap-1">
              <input
                type="number"
                min={1}
                max={pages.length}
                value={jumpPageStr}
                onChange={(e) => setJumpPageStr(e.target.value)}
                placeholder="Sayfa No"
                className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
              <button
                type="submit"
                disabled={!jumpPageStr}
                className="p-1.5 text-xs font-semibold bg-slate-800 text-white disabled:opacity-30 rounded-lg hover:bg-black transition-colors cursor-pointer shrink-0"
                title="Sayfaya Git"
              >
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            <button
              onClick={onDuplicatePage}
              className="p-1.5 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Aktif Sayfayı Çoğalt"
            >
              <Copy className="w-4 h-4" />
            </button>

            <button
              onClick={onDeletePage}
              disabled={pages.length <= 1}
              className="p-1.5 text-red-600 bg-red-50 hover:bg-red-100 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors cursor-pointer"
              title="Aktif Sayfayı Sil"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={onAddPage}
              className="p-1.5 text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Yeni Sayfa Ekle"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Page Template & Background Styling */}
        {currentPage && (
          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex flex-col gap-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <span>Kağıt Şablonu</span>
              <div className="flex items-center gap-1" title="Arka Plan Rengi">
                {['#ffffff', '#fff8e1', '#f1f5f9', '#e8f5e9', '#e3f2fd', '#1c1c1e'].map((c) => (
                  <button
                    key={c}
                    onClick={() => onChangePageBg(c)}
                    className={`w-5 h-5 rounded-full border cursor-pointer ${
                      (currentPage.bg || '#ffffff').toLowerCase() === c
                        ? 'border-blue-600 ring-2 ring-blue-300'
                        : 'border-slate-300'
                    }`}
                    style={{ backgroundColor: c }}
                    aria-label={`Arka plan ${c}`}
                  />
                ))}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: 'squared', label: 'Kareli' },
                { id: 'ruled', label: 'Çizgili' },
                { id: 'dotted', label: 'Noktalı' },
                { id: 'blank', label: 'Düz' },
                { id: 'coord-system', label: 'X-Y Ekseni' },
                { id: 'dark-squared', label: 'Koyu Kare' },
                { id: 'dark-ruled', label: 'Koyu Çizgi' },
                { id: 'dark-blank', label: 'Siyah Kağıt' },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => onChangePageStyle(st.id as PageStyle)}
                  className={`py-1 text-[11px] font-semibold rounded-lg text-center transition-colors cursor-pointer truncate px-1 ${
                    currentPage.type === st.id && !currentPage.pdfDataUrl && !currentPage.pdfRef
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-200/70 bg-white border border-slate-200/80'
                  }`}
                >
                  {st.label}
                </button>
              ))}
            </div>

            {onOpenCustomPaper && (
              <button
                onClick={onOpenCustomPaper}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold border border-blue-200/80 transition-colors cursor-pointer"
              >
                <Grid className="w-3.5 h-3.5" />
                <span>Özel Kağıt Tasarla (İzometrik, Müzik, Cornell...)</span>
              </button>
            )}
          </div>
        )}

        {/* Thumbnails list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {matchingIndices.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              {activeTab === 'bookmarks' ? 'Henüz işaretlenmiş yer imi yok.' : 'Aramanıza uyan sayfa bulunamadı.'}
            </div>
          ) : (
            matchingIndices.map((idx) => (
              <ThumbnailCard
                key={pages[idx].id || idx}
                page={pages[idx]}
                index={idx}
                isActive={idx === currentPageIndex}
                onSelect={() => onSelectPage(idx)}
                onToggleBookmark={onToggleBookmark ? () => onToggleBookmark(idx) : undefined}
              />
            ))
          )}
        </div>
      </aside>
    </>
  );
}

function ThumbnailCard({
  page,
  index,
  isActive,
  onSelect,
  onToggleBookmark,
}: {
  page: PageData;
  index: number;
  isActive: boolean;
  onSelect: () => void;
  onToggleBookmark?: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  // Yüzlerce sayfalı PDF'lerde sadece ekranda görünen küçük resimler çizilir
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    if (typeof IntersectionObserver === 'undefined') {
      setIsVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) setIsVisible(entry.isIntersecting);
      },
      { rootMargin: '200px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (isVisible && canvasRef.current) {
      renderThumbnail(page, canvasRef.current);
    }
  }, [isVisible, page, page.strokes, page.bg, page.type]);

  return (
    <div
      ref={cardRef}
      onClick={onSelect}
      className={`group relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-150 border-2 ${
        isActive
          ? 'border-blue-600 shadow-lg shadow-blue-500/20 ring-2 ring-blue-500/20'
          : 'border-slate-200 hover:border-slate-300 shadow-xs hover:shadow-md'
      }`}
    >
      <div className="aspect-3/4 w-full bg-white flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={180}
          height={250}
          className="w-full h-full object-contain pointer-events-none"
        />
      </div>

      {/* Bookmark star badge */}
      {onToggleBookmark && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleBookmark();
          }}
          className={`absolute top-2.5 right-2.5 p-1.5 rounded-full backdrop-blur-xs transition-all cursor-pointer ${
            page.bookmarked
              ? 'bg-amber-500 text-white shadow-md'
              : 'bg-black/20 text-white/70 hover:bg-black/40 hover:text-white'
          }`}
          title={page.bookmarked ? 'Yer İmini Kaldır' : 'Yer İmi Ekle'}
        >
          <Star className={`w-3.5 h-3.5 ${page.bookmarked ? 'fill-current' : ''}`} />
        </button>
      )}

      <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-full bg-slate-900/75 backdrop-blur-xs text-[11px] font-bold text-white shadow-sm pointer-events-none">
        {index + 1}
      </div>
    </div>
  );
}
