import { useState, useMemo, useRef } from 'react';
import { Notebook } from '../types.ts';
import { IPadInstallModal } from './IPadInstallModal.tsx';
import {
  Plus,
  BookOpen,
  MoreVertical,
  Edit2,
  Copy,
  Download,
  Trash2,
  Upload,
  Search,
  FileDown,
  Tablet,
} from 'lucide-react';

interface HomeScreenProps {
  notebooks: Notebook[];
  onOpenNotebook: (id: string) => void;
  onNewNotebook: () => void;
  onRenameNotebook: (id: string) => void;
  onDuplicateNotebook: (id: string) => void;
  onExportNotebookJSON: (id: string) => void;
  onExportNotebookPDF: (id: string) => void;
  onDeleteNotebook: (id: string) => void;
  onImportNotebookJSON: (file: File) => void;
}

export function HomeScreen({
  notebooks,
  onOpenNotebook,
  onNewNotebook,
  onRenameNotebook,
  onDuplicateNotebook,
  onExportNotebookJSON,
  onExportNotebookPDF,
  onDeleteNotebook,
  onImportNotebookJSON,
}: HomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [menuPos, setMenuPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isIPadModalOpen, setIsIPadModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dismissedBackupNote, setDismissedBackupNote] = useState(false);
  const daysSinceBackup = useMemo(() => {
    try {
      const raw = localStorage.getItem('lastBackupAt');
      if (!raw) return null;
      return Math.floor((Date.now() - Number(raw)) / 86400000);
    } catch {
      return null;
    }
  }, [notebooks]);
  const showBackupNote =
    notebooks.length > 0 && !dismissedBackupNote && (daysSinceBackup === null || daysSinceBackup >= 7);

  const filteredNotebooks = useMemo(() => {
    if (!searchQuery.trim()) return notebooks;
    const q = searchQuery.toLowerCase();
    return notebooks.filter(
      (nb) => nb.name.toLowerCase().includes(q) || (nb.description && nb.description.toLowerCase().includes(q))
    );
  }, [notebooks, searchQuery]);

  const handleOpenMenu = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = Math.min(rect.right - 210, window.innerWidth - 220);
    const y = Math.min(rect.bottom + 6, window.innerHeight - 240);
    setMenuPos({ x: Math.max(10, x), y: Math.max(10, y) });
    setActiveMenuId(activeMenuId === id ? null : id);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportNotebookJSON(file);
    }
    e.target.value = '';
  };

  const activeNotebook = notebooks.find((nb) => nb.id === activeMenuId);

  return (
    <div
      className="fixed inset-0 flex flex-col bg-gradient-to-b from-[#fafafc] to-[#f0f0f5] text-[#1c1c1e] overflow-hidden"
      onClick={() => setActiveMenuId(null)}
    >
      {/* Top Bar */}
      <header className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 px-6 md:px-10 pt-8 pb-5 border-b border-black/5 bg-white/70 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Notlarım
            </h1>
            <p className="text-xs md:text-sm font-medium text-slate-500">
              {notebooks.length === 0
                ? 'Henüz defter bulunmuyor'
                : `${notebooks.length} defter · Geometri & Not Defteri`}
            </p>
          </div>
        </div>

        {/* Search & Actions */}
        <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Defter ara..."
              className="w-full pl-9 pr-3.5 py-2 text-sm bg-white/90 border border-slate-200/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 shadow-xs"
            />
          </div>

          <button
            onClick={() => setIsIPadModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/80 rounded-xl active:scale-97 transition-all shadow-xs shrink-0 cursor-pointer"
            title="iPad'e Yükleme Rehberi"
          >
            <Tablet className="w-4 h-4 text-blue-600" />
            <span className="hidden sm:inline">iPad'e Yükle</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 text-xs md:text-sm font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 active:scale-97 transition-all shadow-xs shrink-0 cursor-pointer"
            title="JSON Yedeği İçe Aktar"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span className="hidden md:inline">Yedek Yükle</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json,application/json"
            className="hidden"
          />

          <button
            onClick={onNewNotebook}
            className="flex items-center gap-2 px-4 py-2 text-xs md:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/30 active:scale-97 transition-all shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Yeni Defter</span>
          </button>
        </div>
      </header>

      {/* Main Grid View */}
      <main className="flex-1 overflow-y-auto px-6 md:px-10 py-8">
        <div className="max-w-7xl mx-auto">
          {showBackupNote && (
            <div className="mb-6 flex items-start justify-between gap-3 px-4 py-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs md:text-sm">
              <p className="font-medium">
                {daysSinceBackup === null
                  ? 'Henüz hiç yedek almadın.'
                  : `Son yedekten bu yana ${daysSinceBackup} gün geçti.`}{' '}
                Veriler yalnızca bu cihazda duruyor: bir defterin <b>⋯</b> menüsünden "Yedekle (JSON İndir)" ile düzenli yedek al.
              </p>
              <button
                onClick={() => setDismissedBackupNote(true)}
                className="shrink-0 font-bold text-amber-700 hover:text-amber-900 cursor-pointer"
              >
                Kapat
              </button>
            </div>
          )}
          {filteredNotebooks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center max-w-md mx-auto">
              <div className="w-20 h-20 rounded-3xl bg-blue-50 text-blue-500 flex items-center justify-center mb-5 text-4xl shadow-inner">
                📓
              </div>
              <h2 className="text-xl font-bold text-slate-800 mb-2">
                {searchQuery ? 'Aramanıza uygun defter bulunamadı' : 'Henüz hiç defteriniz yok'}
              </h2>
              <p className="text-sm text-slate-500 mb-6 leading-relaxed">
                {searchQuery
                  ? 'Farklı bir kelime ile aramayı deneyin veya yeni bir defter oluşturun.'
                  : 'Dersleriniz, geometri çizimleriniz veya günlük notlarınız için hemen ilk defterinizi oluşturun.'}
              </p>
              <button
                onClick={onNewNotebook}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/30 active:scale-97 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                Yeni Defter Oluştur
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-7">
              {filteredNotebooks.map((nb) => (
                <div
                  key={nb.id}
                  onClick={() => onOpenNotebook(nb.id)}
                  className="group flex flex-col cursor-pointer select-none"
                >
                  {/* Book Spine & Cover Card */}
                  <div
                    className="relative aspect-3/4 rounded-2xl p-4 flex flex-col justify-between overflow-hidden shadow-md group-hover:shadow-xl group-hover:-translate-y-1 transition-all duration-200 border border-black/5"
                    style={{ background: nb.cover }}
                  >
                    {/* Spine texture overlay */}
                    <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-r from-black/25 via-black/10 to-transparent pointer-events-none" />
                    {/* Soft gradient sheen */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-white/10 pointer-events-none" />

                    <div className="relative z-10 text-4xl filter drop-shadow-md">
                      {nb.icon || '📓'}
                    </div>

                    <div className="relative z-10">
                      <h3 className="text-white font-bold text-base line-clamp-2 drop-shadow-sm leading-snug">
                        {nb.name}
                      </h3>
                      {nb.description && (
                        <p className="text-white/80 text-[11px] line-clamp-1 mt-1 font-medium">
                          {nb.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Metadata & Context Button */}
                  <div className="flex items-center justify-between mt-2.5 px-1 gap-1">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-800 truncate group-hover:text-blue-600 transition-colors">
                        {nb.name}
                      </p>
                      <p className="text-[11px] font-medium text-slate-400">
                        {nb.pageCount} sayfa · {new Date(nb.updatedAt).toLocaleDateString('tr-TR')}
                      </p>
                    </div>

                    <button
                      onClick={(e) => handleOpenMenu(e, nb.id)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-black/5 transition-colors cursor-pointer shrink-0"
                      title="İşlemler"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Context Menu Popup */}
      {activeMenuId && activeNotebook && (
        <div
          className="fixed z-50 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-200/80 py-1.5 min-w-[210px] animate-in fade-in zoom-in-95 duration-100"
          style={{ left: menuPos.x, top: menuPos.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-3.5 py-1.5 border-b border-slate-100 text-[11px] font-semibold text-slate-400 uppercase tracking-wider truncate">
            {activeNotebook.name}
          </div>

          <button
            onClick={() => {
              setActiveMenuId(null);
              onRenameNotebook(activeNotebook.id);
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left font-medium"
          >
            <Edit2 className="w-4 h-4 text-slate-500" />
            Yeniden Adlandır
          </button>

          <button
            onClick={() => {
              setActiveMenuId(null);
              onDuplicateNotebook(activeNotebook.id);
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left font-medium"
          >
            <Copy className="w-4 h-4 text-slate-500" />
            Defteri Çoğalt
          </button>

          <button
            onClick={() => {
              setActiveMenuId(null);
              onExportNotebookPDF(activeNotebook.id);
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left font-medium"
          >
            <FileDown className="w-4 h-4 text-slate-500" />
            PDF Olarak İndir
          </button>

          <button
            onClick={() => {
              setActiveMenuId(null);
              onExportNotebookJSON(activeNotebook.id);
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer text-left font-medium"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Yedekle (JSON İndir)
          </button>

          <div className="my-1 border-t border-slate-100" />

          <button
            onClick={() => {
              setActiveMenuId(null);
              onDeleteNotebook(activeNotebook.id);
            }}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors cursor-pointer text-left font-medium"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
            Defteri Sil
          </button>
        </div>
      )}

      {/* iPad Installation Modal */}
      <IPadInstallModal
        isOpen={isIPadModalOpen}
        onClose={() => setIsIPadModalOpen(false)}
      />
    </div>
  );
}
