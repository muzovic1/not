import { useState } from 'react';
import { X, Sparkles } from 'lucide-react';
import { PageStyle } from '../types.ts';

interface NewNotebookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (
    name: string,
    icon: string,
    cover: string,
    initialStyle: PageStyle,
    description?: string,
    pageSize?: { width: number; height: number }
  ) => void;
}

const COVERS = [
  'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
  'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
  'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
  'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%)',
  'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
  'linear-gradient(135deg, #2c3e50 0%, #000000 100%)',
  'linear-gradient(135deg, #f857a6 0%, #ff5858 100%)',
  'linear-gradient(135deg, #11998e 0%, #38ef7d 100%)',
  'linear-gradient(135deg, #f12711 0%, #f5af19 100%)',
];

const ICONS = [
  '📐', '📏', '🧮', '📓', '📚', '📝', '✏️', '🔬', '⚗️', '🧪', '🎨', '💻', '🧠', '💡', '🌟', '🚀',
  '🎯', '📊', '📈', '📋', '🎒', '🏆', '💎', '🔥', '🌸', '☕', '🏛️', '🌍', '⚡', '🗝️', '🧬', '⚙️'
];

const SUGGESTIONS = [
  'Geometri Notları',
  'Matematik & Formüller',
  'Fizik & Deneyler',
  'Ders Notları & Özet',
  'Serbest Çizim & Eskiz',
];

const PAGE_SIZES = [
  { id: 'a4', label: 'A4 Dikey', width: 1000, height: 1414 },
  { id: 'long', label: 'Uzun Not', width: 1000, height: 2000 },
  { id: 'a4-land', label: 'A4 Yatay', width: 1414, height: 1000 },
  { id: 'square', label: 'Kare', width: 1200, height: 1200 },
];

export function NewNotebookModal({ isOpen, onClose, onCreate }: NewNotebookModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('📐');
  const [selectedCover, setSelectedCover] = useState(COVERS[0]);
  const [selectedStyle, setSelectedStyle] = useState<PageStyle>('squared');
  const [selectedSize, setSelectedSize] = useState('a4');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const size = PAGE_SIZES.find((s) => s.id === selectedSize) || PAGE_SIZES[0];
    onCreate(title.trim(), selectedIcon, selectedCover, selectedStyle, description.trim() || undefined, {
      width: size.width,
      height: size.height,
    });
    setTitle('');
    setSelectedSize('a4');
    setDescription('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4.5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-blue-50 text-blue-600">
              <Sparkles className="w-4 h-4" />
            </span>
            <h2 className="text-lg font-bold text-slate-800">Yeni Defter Oluştur</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
          {/* Cover Preview */}
          <div className="flex justify-center">
            <div
              className="relative w-36 aspect-3/4 rounded-2xl p-4 flex flex-col justify-between overflow-hidden shadow-xl border border-black/10 transition-all duration-300 transform hover:scale-105"
              style={{ background: selectedCover }}
            >
              <div className="absolute inset-y-0 left-0 w-2.5 bg-gradient-to-r from-black/25 to-transparent pointer-events-none" />
              <div className="text-4xl filter drop-shadow-md select-none">{selectedIcon}</div>
              <div className="text-white">
                <p className="font-bold text-sm leading-tight drop-shadow-sm line-clamp-2">
                  {title || 'Defter Başlığı'}
                </p>
                <p className="text-[10px] text-white/80 font-medium mt-1">1 Sayfa</p>
              </div>
            </div>
          </div>

          {/* Quick Title Suggestions */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Defter Başlığı
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Örn: Geometri Notları, Matematik..."
              maxLength={45}
              autoFocus
              className="w-full px-4 py-2.5 text-sm font-medium bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
            />
            <div className="flex flex-wrap gap-1.5 mt-2">
              {SUGGESTIONS.map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => setTitle(sug)}
                  className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors cursor-pointer"
                >
                  {sug}
                </button>
              ))}
            </div>
          </div>

          {/* Sayfa Şekli */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Sayfa Boyutu
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PAGE_SIZES.map((size) => (
                <button
                  key={size.id}
                  type="button"
                  onClick={() => setSelectedSize(size.id)}
                  className={`py-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center truncate px-1 ${
                    selectedSize === size.id
                      ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {size.label}
                </button>
              ))}
            </div>
          </div>

          {/* Page Grid Style */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              İlk Sayfa Düzeni
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[
                { id: 'squared', label: 'Kareli' },
                { id: 'ruled', label: 'Çizgili' },
                { id: 'dotted', label: 'Noktalı' },
                { id: 'blank', label: 'Düz' },
                { id: 'coord-system', label: 'X-Y Ekseni' },
                { id: 'dark-squared', label: 'Koyu Kare' },
              ].map((style) => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => setSelectedStyle(style.id as PageStyle)}
                  className={`py-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center truncate px-1 ${
                    selectedStyle === style.id
                      ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {style.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cover Color Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Kapak Deseni
            </label>
            <div className="grid grid-cols-6 gap-2">
              {COVERS.map((cov, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedCover(cov)}
                  style={{ background: cov }}
                  className={`h-9 rounded-xl cursor-pointer transition-transform duration-150 ${
                    selectedCover === cov
                      ? 'ring-2 ring-blue-600 ring-offset-2 scale-105'
                      : 'hover:scale-105 opacity-90 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Icon Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Kapak İkonu
            </label>
            <div className="grid grid-cols-8 gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-2xl max-h-36 overflow-y-auto">
              {ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setSelectedIcon(ic)}
                  className={`text-xl aspect-square rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                    selectedIcon === ic
                      ? 'bg-white shadow-sm ring-2 ring-blue-500 scale-110'
                      : 'hover:bg-white/80'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/70">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-800 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          >
            İptal
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!title.trim()}
            className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed rounded-xl shadow-md shadow-blue-500/25 transition-all cursor-pointer"
          >
            Oluştur
          </button>
        </div>
      </div>
    </div>
  );
}
