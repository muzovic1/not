import { useState, useRef, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  CornerDownLeft,
  X,
  Maximize2,
  ZoomIn,
  Move,
} from 'lucide-react';
import { Point, CanvasItem, FreehandStroke, ToolSettingsItem } from '../types.ts';
import { drawItem } from '../utils/canvasRenderer.ts';

interface ZoomWritingBoxProps {
  isOpen: boolean;
  onClose: () => void;
  pageWidth: number;
  pageHeight: number;
  focusPos: Point; // world top-left coordinate of focus area
  onMoveFocusPos: (newPos: Point) => void;
  strokes: CanvasItem[];
  currentStroke: FreehandStroke | null;
  toolSettings: ToolSettingsItem;
  onAddStroke: (stroke: FreehandStroke) => void;
}

export function ZoomWritingBox({
  isOpen,
  onClose,
  pageWidth,
  pageHeight,
  focusPos,
  onMoveFocusPos,
  strokes,
  currentStroke,
  toolSettings,
  onAddStroke,
}: ZoomWritingBoxProps) {
  const [zoomFactor, setZoomFactor] = useState(2.2);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const activeStrokeRef = useRef<FreehandStroke | null>(null);
  const isDrawingRef = useRef(false);

  // Focus box dimension in world space
  const boxWorldWidth = 320;
  const boxWorldHeight = 150;

  // Auto-advance margin
  const autoAdvanceThresholdRatio = 0.82; // rightmost 18% triggers auto-advance

  // Keep focusPos inside page
  const clampPos = useCallback(
    (pos: Point): Point => {
      return {
        x: Math.max(0, Math.min(pageWidth - boxWorldWidth, pos.x)),
        y: Math.max(0, Math.min(pageHeight - boxWorldHeight, pos.y)),
      };
    },
    [pageWidth, pageHeight]
  );

  // Advance right
  const handleAdvanceRight = useCallback(() => {
    onMoveFocusPos(
      clampPos({
        x: focusPos.x + boxWorldWidth * 0.65,
        y: focusPos.y,
      })
    );
  }, [focusPos, clampPos, onMoveFocusPos]);

  // Advance left
  const handleAdvanceLeft = useCallback(() => {
    onMoveFocusPos(
      clampPos({
        x: focusPos.x - boxWorldWidth * 0.65,
        y: focusPos.y,
      })
    );
  }, [focusPos, clampPos, onMoveFocusPos]);

  // Return to next line (GoodNotes newline)
  const handleNewLine = useCallback(() => {
    onMoveFocusPos(
      clampPos({
        x: 40, // return to left margin
        y: focusPos.y + boxWorldHeight * 0.6,
      })
    );
  }, [focusPos, clampPos, onMoveFocusPos]);

  // Render zoom canvas contents
  const renderCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const cw = canvas.clientWidth;
    const ch = canvas.clientHeight;

    if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
      canvas.width = cw * dpr;
      canvas.height = ch * dpr;
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Zoom transform: maps focusPos (world) to top-left of zoom box
    const scale = (cw / boxWorldWidth) * dpr;
    ctx.setTransform(scale, 0, 0, scale, -focusPos.x * scale, -focusPos.y * scale);

    // Draw background paper lines in zoom viewport
    ctx.strokeStyle = 'rgba(0, 122, 255, 0.12)';
    ctx.lineWidth = 1;
    const startY = Math.floor(focusPos.y / 36) * 36;
    for (let y = startY; y < focusPos.y + boxWorldHeight + 40; y += 36) {
      ctx.beginPath();
      ctx.moveTo(focusPos.x - 20, y);
      ctx.lineTo(focusPos.x + boxWorldWidth + 20, y);
      ctx.stroke();
    }

    // Draw existing strokes
    for (const item of strokes) {
      drawItem(ctx, item);
    }

    // Draw current active stroke
    if (activeStrokeRef.current) {
      drawItem(ctx, activeStrokeRef.current);
    } else if (currentStroke) {
      drawItem(ctx, currentStroke);
    }

    // Draw right auto-advance boundary guide
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const advanceX = cw * autoAdvanceThresholdRatio * dpr;
    ctx.fillStyle = 'rgba(59, 130, 246, 0.05)';
    ctx.fillRect(advanceX, 0, canvas.width - advanceX, canvas.height);

    ctx.strokeStyle = 'rgba(59, 130, 246, 0.35)';
    ctx.setLineDash([4 * dpr, 4 * dpr]);
    ctx.lineWidth = 1.5 * dpr;
    ctx.beginPath();
    ctx.moveTo(advanceX, 0);
    ctx.lineTo(advanceX, canvas.height);
    ctx.stroke();
    ctx.setLineDash([]);
  }, [focusPos, strokes, currentStroke]);

  useEffect(() => {
    if (!isOpen) return;
    renderCanvas();
  }, [isOpen, renderCanvas, strokes, currentStroke]);

  if (!isOpen) return null;

  // Pointer drawing handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Convert to world space
    const worldX = focusPos.x + (clickX / rect.width) * boxWorldWidth;
    const worldY = focusPos.y + (clickY / rect.height) * boxWorldHeight;
    const pressure = e.pressure > 0 ? e.pressure : 0.6;

    const newStroke: FreehandStroke = {
      id: `stroke_${Date.now()}_zb`,
      type: 'stroke',
      tool: 'pen',
      color: toolSettings.color,
      size: toolSettings.size,
      penType: toolSettings.penType || 'standard',
      lineCap: 'round',
      points: [{ x: worldX, y: worldY, pressure }],
      createdAt: Date.now(),
    };

    activeStrokeRef.current = newStroke;
    isDrawingRef.current = true;
    renderCanvas();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current || !activeStrokeRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const worldX = focusPos.x + (clickX / rect.width) * boxWorldWidth;
    const worldY = focusPos.y + (clickY / rect.height) * boxWorldHeight;
    const pressure = e.pressure > 0 ? e.pressure : 0.6;

    activeStrokeRef.current.points.push({ x: worldX, y: worldY, pressure });
    renderCanvas();
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current || !activeStrokeRef.current) return;
    isDrawingRef.current = false;

    const canvas = canvasRef.current;
    if (canvas) {
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      // If user finished near the right margin, trigger auto-advance
      if (clickX >= rect.width * autoAdvanceThresholdRatio) {
        setTimeout(() => {
          handleAdvanceRight();
        }, 120);
      }
    }

    onAddStroke(activeStrokeRef.current);
    activeStrokeRef.current = null;
    renderCanvas();
  };

  return (
    <div className="absolute bottom-20 left-4 right-4 md:left-24 md:right-24 z-40 bg-white/95 backdrop-blur-xl border border-slate-300/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col select-none animate-in slide-in-from-bottom-4 duration-200">
      {/* Top control bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-100/90 border-b border-slate-200 text-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center">
            <ZoomIn className="w-3 h-3" />
          </div>
          <span className="text-xs font-bold text-slate-800">
            Büyüteç Yazı Penceresi (Zoom Window)
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            x:{Math.round(focusPos.x)} y:{Math.round(focusPos.y)}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleAdvanceLeft}
            className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors shadow-2xs cursor-pointer"
            title="Geri Kaydır"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleAdvanceRight}
            className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors shadow-2xs cursor-pointer"
            title="İleri Kaydır"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <button
            onClick={handleNewLine}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors shadow-2xs cursor-pointer"
            title="Alt Satıra Geç"
          >
            <CornerDownLeft className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Alt Satır</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            title="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Interactive Magnified Drawing Canvas */}
      <div className="relative w-full h-44 sm:h-52 bg-white cursor-crosshair touch-none">
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full h-full block"
        />
        {/* Helper watermark */}
        <div className="absolute bottom-2 right-4 pointer-events-none text-[10px] text-blue-500/70 font-semibold uppercase tracking-wider">
          Mavi alana yazınca otomatik ilerler →
        </div>
      </div>
    </div>
  );
}
