import { useState, useRef, useEffect } from 'react';
import { X, Check, Grid, Sparkles, Layers } from 'lucide-react';
import { CustomPaperConfig, PatternType, PageStyle } from '../types.ts';

interface CustomPaperModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig?: CustomPaperConfig;
  onApplyTemplate: (config: CustomPaperConfig, applyToAll: boolean) => void;
}

const PAPER_TINTS = [
  { label: 'Beyaz', bg: '#ffffff', dark: false },
  { label: 'Fildişi / Krem', bg: '#faf7ee', dark: false },
  { label: 'Sepya', bg: '#f4ebd9', dark: false },
  { label: 'Pastel Nane', bg: '#f0fdf4', dark: false },
  { label: 'Hafif Mavi', bg: '#f0f7ff', dark: false },
  { label: 'Gece Siyahı', bg: '#18181b', dark: true },
  { label: 'Koyu Lacivert', bg: '#0f172a', dark: true },
];

const PATTERNS: { type: PatternType; label: string; icon: string; desc: string }[] = [
  { type: 'ruled', label: 'Çizgili', icon: '📝', desc: 'Klasik kenar boşluklu defter çizgisi' },
  { type: 'squared', label: 'Kareli', icon: '📐', desc: 'Matematik, tablo ve hassas çizimler' },
  { type: 'dotted', label: 'Noktalı', icon: '· ·', desc: 'Bullet journal ve serbest eskiz' },
  { type: 'isometric', label: 'İzometrik 3D', icon: '🧊', desc: '3 boyutlu geometrik çizimler & mimari' },
  { type: 'music', label: 'Müzik Portesi', icon: '🎼', desc: '5 çizgili nota ve müzik yazımı' },
  { type: 'cornell', label: 'Cornell Notu', icon: '📋', desc: 'İpuçları, ders notları ve özet alanı' },
  { type: 'blank', label: 'Düz Kağıt', icon: '📄', desc: 'Çizgisiz tertemiz boş sayfa' },
];

export function CustomPaperModal({
  isOpen,
  onClose,
  currentConfig,
  onApplyTemplate,
}: CustomPaperModalProps) {
  const [pattern, setPattern] = useState<PatternType>(currentConfig?.pattern || 'ruled');
  const [spacing, setSpacing] = useState<number>(currentConfig?.spacing || 32);
  const [bgColor, setBgColor] = useState<string>(currentConfig?.bgColor || '#ffffff');
  const [lineColor, setLineColor] = useState<string>(
    currentConfig?.lineColor || 'rgba(0, 122, 255, 0.16)'
  );
  const [applyToAll, setApplyToAll] = useState(false);

  const previewRef = useRef<HTMLCanvasElement>(null);

  const isDark = bgColor === '#18181b' || bgColor === '#0f172a';

  // Preview renderer
  useEffect(() => {
    if (!isOpen) return;
    const canvas = previewRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Bg
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 1;

    if (pattern === 'ruled') {
      for (let y = spacing; y < h; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      ctx.strokeStyle = isDark ? 'rgba(255, 69, 58, 0.4)' : 'rgba(255, 59, 48, 0.25)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(45, 0);
      ctx.lineTo(45, h);
      ctx.stroke();
    } else if (pattern === 'squared') {
      for (let x = spacing; x < w; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = spacing; y < h; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    } else if (pattern === 'dotted') {
      ctx.fillStyle = lineColor;
      for (let x = spacing; x < w; x += spacing) {
        for (let y = spacing; y < h; y += spacing) {
          ctx.beginPath();
          ctx.arc(x, y, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (pattern === 'isometric') {
      for (let x = 0; x < w; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      const slope = Math.tan((30 * Math.PI) / 180);
      const yStep = spacing * slope * 2;
      for (let startY = -w * slope; startY < h; startY += yStep) {
        ctx.beginPath();
        ctx.moveTo(0, startY);
        ctx.lineTo(w, startY + w * slope);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, startY + w * slope);
        ctx.lineTo(w, startY);
        ctx.stroke();
      }
    } else if (pattern === 'music') {
      const lineGap = 6;
      for (let stave = 30; stave < h - 20; stave += 55) {
        for (let l = 0; l < 5; l++) {
          ctx.beginPath();
          ctx.moveTo(20, stave + l * lineGap);
          ctx.lineTo(w - 20, stave + l * lineGap);
          ctx.stroke();
        }
      }
    } else if (pattern === 'cornell') {
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, 35);
      ctx.lineTo(w, 35);
      ctx.moveTo(65, 35);
      ctx.lineTo(65, h - 45);
      ctx.moveTo(0, h - 45);
      ctx.lineTo(w, h - 45);
      ctx.stroke();

      ctx.lineWidth = 0.8;
      for (let y = 48; y < h - 50; y += 18) {
        ctx.beginPath();
        ctx.moveTo(65, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
    }
  }, [isOpen, pattern, spacing, bgColor, lineColor, isDark]);

  if (!isOpen) return null;

  const handleApply = () => {
    onApplyTemplate(
      {
        pattern,
        spacing,
        bgColor,
        lineColor,
      },
      applyToAll
    );
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
              <Grid className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Özel Kağıt Tasarımcısı</h3>
              <p className="text-xs text-slate-500">Desen, ızgara aralığı, kağıt dokusu ve renkleri özelleştirin</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-700">
          {/* Pattern Choice */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              1. Şablon Deseni Seçin
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {PATTERNS.map((p) => {
                const isSelected = pattern === p.type;
                return (
                  <button
                    key={p.type}
                    onClick={() => setPattern(p.type)}
                    className={`flex flex-col items-start p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50/80 border-blue-500 shadow-xs ring-1 ring-blue-500'
                        : 'bg-slate-50/60 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-xl mb-1">{p.icon}</span>
                    <span className="text-xs font-bold text-slate-900">{p.label}</span>
                    <span className="text-[10px] text-slate-500 leading-tight mt-0.5 line-clamp-1">
                      {p.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center">
            {/* Live Canvas Preview */}
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-slate-500 mb-1.5 self-start">Önizleme:</span>
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-slate-50">
                <canvas ref={previewRef} width={260} height={200} className="block" />
              </div>
            </div>

            {/* Adjustments */}
            <div className="space-y-4">
              {/* Paper Background Tint */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600">Kağıt Tonu (Arka Plan):</label>
                <div className="flex items-center gap-2 flex-wrap">
                  {PAPER_TINTS.map((t) => (
                    <button
                      key={t.bg}
                      onClick={() => setBgColor(t.bg)}
                      className={`w-7 h-7 rounded-xl border border-slate-300 shadow-2xs transition-transform cursor-pointer ${
                        bgColor === t.bg ? 'scale-120 ring-2 ring-blue-600 ring-offset-2' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: t.bg }}
                      title={t.label}
                    />
                  ))}
                </div>
              </div>

              {/* Spacing Slider */}
              {pattern !== 'blank' && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-bold text-slate-600">
                    <span>Çizgi / Izgara Aralığı:</span>
                    <span className="font-mono text-blue-600">{spacing} px</span>
                  </div>
                  <input
                    type="range"
                    min={18}
                    max={54}
                    value={spacing}
                    onChange={(e) => setSpacing(Number(e.target.value))}
                    className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                  />
                </div>
              )}

              {/* Line Color Selection */}
              {pattern !== 'blank' && (
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-600">Çizgi Rengi:</label>
                  <div className="flex items-center gap-2">
                    {[
                      { label: 'Hafif Mavi', val: 'rgba(0, 122, 255, 0.20)' },
                      { label: 'Soluk Gri', val: 'rgba(0, 0, 0, 0.16)' },
                      { label: 'Sıcak Kahve', val: 'rgba(160, 82, 45, 0.22)' },
                      { label: 'Yeşil Mürekkep', val: 'rgba(16, 185, 129, 0.22)' },
                      { label: 'Koyu Izgara', val: isDark ? 'rgba(255, 255, 255, 0.25)' : 'rgba(15, 23, 42, 0.28)' },
                    ].map((col) => (
                      <button
                        key={col.label}
                        onClick={() => setLineColor(col.val)}
                        className={`w-6 h-6 rounded-full border border-slate-300 transition-transform cursor-pointer ${
                          lineColor === col.val ? 'scale-120 ring-2 ring-blue-600 ring-offset-2' : 'hover:scale-110'
                        }`}
                        style={{ backgroundColor: col.val }}
                        title={col.label}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Apply to all pages checkbox */}
              <label className="flex items-center gap-2 pt-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={applyToAll}
                  onChange={(e) => setApplyToAll(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 accent-blue-600"
                />
                <span>Bu şablonu defterdeki tüm sayfalara uygula</span>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/80">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
          >
            İptal
          </button>
          <button
            onClick={handleApply}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/25 active:scale-97 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Şablonu Uygula</span>
          </button>
        </div>
      </div>
    </div>
  );
}
