import { useState, useRef, useEffect, useMemo } from 'react';
import { X, Sparkles, Check, Play, HelpCircle } from 'lucide-react';
import { CanvasItem, FreehandStroke, ShapeStroke, Point } from '../types.ts';

interface FunctionPlotterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertPlot: (items: CanvasItem[]) => void;
  centerPos: Point;
}

const PRESETS = [
  { label: 'f(x) = x²', formula: 'x * x', desc: 'Parabol' },
  { label: 'f(x) = sin(x)', formula: 'Math.sin(x)', desc: 'Sinüs Dalgası' },
  { label: 'f(x) = cos(x)', formula: 'Math.cos(x)', desc: 'Kosinüs Dalgası' },
  { label: 'f(x) = 2x - 1', formula: '2 * x - 1', desc: 'Doğrusal Fonksiyon' },
  { label: 'f(x) = -0.2x² + 4', formula: '-0.2 * x * x + 4', desc: 'Ters Parabol' },
  { label: 'f(x) = 1 / x', formula: '1 / (x === 0 ? 0.0001 : x)', desc: 'Hiperbol' },
  { label: 'f(x) = |x|', formula: 'Math.abs(x)', desc: 'Mutlak Değer' },
  { label: 'f(x) = x³ - 3x', formula: 'x*x*x - 3*x', desc: 'Kübik Polinom' },
];

export function FunctionPlotterModal({
  isOpen,
  onClose,
  onInsertPlot,
  centerPos,
}: FunctionPlotterModalProps) {
  const [formula, setFormula] = useState('x * x');
  const [xMin, setXMin] = useState(-5);
  const [xMax, setXMax] = useState(5);
  const [strokeColor, setStrokeColor] = useState('#2563eb');
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [includeAxes, setIncludeAxes] = useState(true);
  const [plotSize, setPlotSize] = useState(380); // in pixels
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  // Compile expression into evaluator
  const evaluate = useMemo(() => {
    try {
      // Safe function evaluator allowing Math functions and basic arithmetic
      const sanitized = formula
        .replace(/\bsin\b/g, 'Math.sin')
        .replace(/\bcos\b/g, 'Math.cos')
        .replace(/\btan\b/g, 'Math.tan')
        .replace(/\bsqrt\b/g, 'Math.sqrt')
        .replace(/\babs\b/g, 'Math.abs')
        .replace(/\bexp\b/g, 'Math.exp')
        .replace(/\bpi\b/gi, 'Math.PI')
        .replace(/\^/g, '**');

      const fn = new Function('x', `with(Math) { return (${sanitized}); }`);
      // Test at x = 1
      fn(1);
      setErrorMsg(null);
      return fn;
    } catch (e: any) {
      setErrorMsg('Geçersiz matematiksel ifade');
      return null;
    }
  }, [formula]);

  // Render live preview on preview canvas
  useEffect(() => {
    if (!isOpen) return;
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Background
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, width, height);

    const cx = width / 2;
    const cy = height / 2;
    const rangeX = Math.max(1, xMax - xMin);
    const scaleX = (width - 40) / rangeX;
    const scaleY = scaleX; // 1:1 aspect ratio

    // Grid
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let x = -10; x <= 10; x += 1) {
      const px = cx + x * scaleX;
      if (px >= 0 && px <= width) {
        ctx.beginPath();
        ctx.moveTo(px, 0);
        ctx.lineTo(px, height);
        ctx.stroke();
      }
    }
    for (let y = -10; y <= 10; y += 1) {
      const py = cy - y * scaleY;
      if (py >= 0 && py <= height) {
        ctx.beginPath();
        ctx.moveTo(0, py);
        ctx.lineTo(width, py);
        ctx.stroke();
      }
    }

    // Axes
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, cy);
    ctx.lineTo(width, cy);
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, height);
    ctx.stroke();

    // Labels
    ctx.fillStyle = '#64748b';
    ctx.font = '10px monospace';
    ctx.fillText('x', width - 12, cy - 6);
    ctx.fillText('y', cx + 6, 12);
    ctx.fillText('O', cx - 12, cy + 12);

    // Plot points
    if (evaluate) {
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = strokeWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      ctx.beginPath();
      let started = false;
      const step = (xMax - xMin) / 200;

      for (let x = xMin; x <= xMax; x += step) {
        try {
          const y = evaluate(x);
          if (typeof y !== 'number' || isNaN(y) || !isFinite(y)) {
            started = false;
            continue;
          }
          const px = cx + x * scaleX;
          const py = cy - y * scaleY;

          // Clip if way outside
          if (py < -height || py > height * 2) {
            started = false;
            continue;
          }

          if (!started) {
            ctx.moveTo(px, py);
            started = true;
          } else {
            ctx.lineTo(px, py);
          }
        } catch (e) {
          started = false;
        }
      }
      ctx.stroke();
    }
  }, [isOpen, evaluate, xMin, xMax, strokeColor, strokeWidth]);

  if (!isOpen) return null;

  const handleInsert = () => {
    if (!evaluate) return;

    const items: CanvasItem[] = [];
    const cx = centerPos.x;
    const cy = centerPos.y;
    const half = plotSize / 2;
    const rangeX = Math.max(1, xMax - xMin);
    const scale = (plotSize - 40) / rangeX;

    // 1. Add Coordinate System Box if selected
    if (includeAxes) {
      const axesItem: ShapeStroke = {
        id: `shape_${Date.now()}_axes`,
        type: 'shape',
        shape: 'coord-axes',
        x1: cx - half,
        y1: cy - half,
        x2: cx + half,
        y2: cy + half,
        color: '#64748b',
        size: 2,
        opacity: 0.9,
      };
      items.push(axesItem);
    }

    // 2. Generate curve points in world space
    const points: Point[] = [];
    const step = (xMax - xMin) / 180;

    for (let x = xMin; x <= xMax; x += step) {
      try {
        const y = evaluate(x);
        if (typeof y === 'number' && !isNaN(y) && isFinite(y)) {
          const px = cx + x * scale;
          const py = cy - y * scale;
          // Only add if within reasonable bounds around plot area
          if (px >= cx - half * 1.4 && px <= cx + half * 1.4 && py >= cy - half * 1.4 && py <= cy + half * 1.4) {
            points.push({ x: px, y: py, pressure: 0.7 });
          }
        }
      } catch (e) {
        // continue
      }
    }

    if (points.length > 1) {
      const curveItem: FreehandStroke = {
        id: `stroke_${Date.now()}_graph`,
        type: 'stroke',
        tool: 'pen',
        color: strokeColor,
        size: strokeWidth,
        lineCap: 'round',
        points,
        createdAt: Date.now(),
      };
      items.push(curveItem);
    }

    onInsertPlot(items);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold font-mono text-sm">
              f(x)
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">Matematik Fonksiyon & Grafik Çizici</h3>
              <p className="text-xs text-slate-500">Denklem girin, sayfaya hassas vektör eğrisi olarak ekleyin</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Formula input and Presets */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Fonksiyon Denklemi y = f(x)
            </label>
            <div className="flex gap-2">
              <span className="flex items-center px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-600">
                f(x) =
              </span>
              <input
                type="text"
                value={formula}
                onChange={(e) => setFormula(e.target.value)}
                placeholder="Örn: x*x, sin(x), 2*x - 3"
                className="flex-1 px-3.5 py-2 text-sm font-mono bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
              />
            </div>
            {errorMsg && <p className="text-xs text-red-500 font-medium">{errorMsg}</p>}

            {/* Quick Presets */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[11px] font-semibold text-slate-400">Hazır Şablonlar:</span>
              {PRESETS.map((p) => (
                <button
                  key={p.formula}
                  onClick={() => setFormula(p.formula)}
                  className="px-2.5 py-1 text-[11px] font-mono font-medium rounded-lg bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 border border-slate-200 transition-colors cursor-pointer"
                  title={p.desc}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Grid View & Parameters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center">
            {/* Live Canvas Preview */}
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-slate-500 mb-1.5 self-start">Canlı Önizleme:</span>
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-inner bg-slate-50">
                <canvas
                  ref={previewCanvasRef}
                  width={280}
                  height={220}
                  className="block"
                />
              </div>
            </div>

            {/* Options */}
            <div className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600">x Min:</label>
                  <input
                    type="number"
                    value={xMin}
                    onChange={(e) => setXMin(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600">x Max:</label>
                  <input
                    type="number"
                    value={xMax}
                    onChange={(e) => setXMax(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs font-mono bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Color selection */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-600">Grafik Rengi:</label>
                <div className="flex items-center gap-2">
                  {['#2563eb', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#0f172a'].map((c) => (
                    <button
                      key={c}
                      onClick={() => setStrokeColor(c)}
                      className={`w-6 h-6 rounded-full transition-transform cursor-pointer ${
                        strokeColor === c ? 'scale-125 ring-2 ring-blue-500 ring-offset-2' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Thickness */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-bold text-slate-600">
                  <span>Çizgi Kalınlığı:</span>
                  <span className="font-mono">{strokeWidth} px</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={8}
                  value={strokeWidth}
                  onChange={(e) => setStrokeWidth(Number(e.target.value))}
                  className="w-full accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                />
              </div>

              {/* Include Axes Checkbox */}
              <label className="flex items-center gap-2 pt-1 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeAxes}
                  onChange={(e) => setIncludeAxes(e.target.checked)}
                  className="w-4 h-4 rounded text-blue-600 accent-blue-600"
                />
                <span>Koordinat Eksenleri ve Izgara Kutusunu Ekle</span>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50/80">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-200 transition-colors cursor-pointer"
          >
            İptal
          </button>
          <button
            onClick={handleInsert}
            disabled={!evaluate}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs shadow-md shadow-blue-500/25 active:scale-97 transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Grafiği Sayfaya Ekle</span>
          </button>
        </div>
      </div>
    </div>
  );
}
