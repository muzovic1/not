import { ActiveTool, ToolSettingsMap } from '../types.ts';
import {
  Trash2,
  Sparkles,
  Hand,
  ShieldCheck,
  X,
  PenTool,
  Highlighter,
  Eraser,
  Scissors,
  Check,
} from 'lucide-react';

interface QuickSettingsPopoverProps {
  tool: ActiveTool;
  settings: ToolSettingsMap;
  palmRejection: boolean;
  onTogglePalmRejection: (val: boolean) => void;
  onChangeSettings: (newSettings: Partial<ToolSettingsMap[ActiveTool]>) => void;
  onClearPage: () => void;
  onClose: () => void;
}

export function QuickSettingsPopover({
  tool,
  settings,
  palmRejection,
  onTogglePalmRejection,
  onChangeSettings,
  onClearPage,
  onClose,
}: QuickSettingsPopoverProps) {
  const current = settings[tool] || { size: 4, opacity: 1, color: '#1c1c1e' };
  const isEraser = tool === 'eraser' || tool === 'stroke-eraser';
  const isPen = tool === 'pen';
  const isHighlighter = tool === 'highlighter';
  const isHand = tool === 'hand';

  // Quick size presets based on active tool
  const penPresets = [2, 4, 8];
  const highlighterPresets = [14, 22, 34];
  const eraserPresets = [10, 20, 36];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/35 backdrop-blur-xs select-none animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-slate-900/98 text-white rounded-3xl p-4 sm:p-5 shadow-2xl border border-white/15 max-h-[82vh] overflow-y-auto no-scrollbar space-y-4 animate-in zoom-in-95 slide-in-from-bottom-4 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Tool Icon & Close Button */}
        <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-blue-600/30 text-blue-400 flex items-center justify-center">
              {isPen ? (
                <PenTool className="w-4 h-4" />
              ) : isHighlighter ? (
                <Highlighter className="w-4 h-4" />
              ) : isEraser ? (
                <Eraser className="w-4 h-4" />
              ) : (
                <Hand className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                {isPen
                  ? 'Kalem Ayarları'
                  : isHighlighter
                  ? 'Fosforlu Kalem Ayarları'
                  : isEraser
                  ? 'Silgi Ayarları'
                  : 'Gezinme & Dokunma Ayarları'}
              </h3>
              <p className="text-[10px] text-slate-400">Dokunmatik ve Apple Pencil kontrolleri</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Kapat"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 1. KALEM (PEN) ÖZEL AYARLARI */}
        {isPen && (
          <div className="space-y-4">
            {/* Quick Thickness Presets */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                <span>Çizgi Kalınlığı</span>
                <span className="font-mono text-blue-400 font-bold">{current.size} px</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {penPresets.map((px) => {
                  const isSel = current.size === px;
                  return (
                    <button
                      key={px}
                      type="button"
                      onClick={() => onChangeSettings({ size: px })}
                      className={`h-11 rounded-xl flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                        isSel
                          ? 'bg-blue-600 text-white border-blue-400 shadow-md font-bold'
                          : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <span
                        className="rounded-full bg-current"
                        style={{ width: `${Math.max(3, px)}px`, height: `${Math.max(3, px)}px` }}
                      />
                      <span className="text-xs">{px === 2 ? 'İnce' : px === 4 ? 'Normal' : 'Kalın'}</span>
                    </button>
                  );
                })}
              </div>
              <input
                type="range"
                min={1}
                max={24}
                value={current.size}
                onChange={(e) => onChangeSettings({ size: Number(e.target.value) })}
                className="w-full accent-blue-500 h-2 bg-white/20 rounded-lg cursor-pointer"
              />
            </div>

            {/* Pen Model: Standart, Dolmakalem, Fırça */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300">Kalem Ucu Tipi</span>
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-white/10 rounded-2xl">
                {(
                  [
                    { type: 'standard', label: 'Standart', desc: 'Bilye uç' },
                    { type: 'fountain', label: 'Dolmakalem', desc: '45° Kesik' },
                    { type: 'brush', label: 'Fırça', desc: 'Dinamik' },
                  ] as const
                ).map((pt) => {
                  const isSelected = (current.penType || 'standard') === pt.type;
                  return (
                    <button
                      key={pt.type}
                      type="button"
                      onClick={() => onChangeSettings({ penType: pt.type })}
                      className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center gap-0.5 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-blue-600 text-white shadow-md'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span>{pt.label}</span>
                      <span className="text-[9px] opacity-75 font-normal">{pt.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Stylus Pressure Sensitivity */}
            <label className="flex items-center justify-between p-2.5 bg-white/5 rounded-2xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <div>
                <span className="block text-xs font-semibold text-slate-200">Basınç Duyarlılığı</span>
                <span className="block text-[10px] text-slate-400">Apple Pencil basınca göre çizgiyi kalınlaştırır</span>
              </div>
              <input
                type="checkbox"
                checked={current.pressureSensitivity !== false}
                onChange={(e) => onChangeSettings({ pressureSensitivity: e.target.checked })}
                className="w-4 h-4 accent-blue-500 rounded cursor-pointer"
              />
            </label>

            {/* Draw & Hold (Bekletince Düzleştir) */}
            <label className="flex items-center justify-between p-2.5 bg-white/5 rounded-2xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <div>
                <span className="block text-xs font-semibold text-slate-200">Bekletince Düzleştir (Draw & Hold)</span>
                <span className="block text-[10px] text-slate-400">Çizgi bitiminde 0.5s basılı tutunca düzleşir</span>
              </div>
              <input
                type="checkbox"
                checked={current.drawAndHold !== false}
                onChange={(e) => onChangeSettings({ drawAndHold: e.target.checked })}
                className="w-4 h-4 accent-blue-500 rounded cursor-pointer"
              />
            </label>

            {/* Smart Shape Quick Toggle */}
            <label className="flex items-center justify-between p-2.5 bg-white/5 rounded-2xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="block text-xs font-semibold text-slate-200">Akıllı Şekil Tanıma</span>
                  <span className="block text-[10px] text-slate-400">
                    {current.smartShape ? 'Açık: Üçgen ve daireler düzeltilir' : 'Kapalı: El yazınız (C, a vb.) korunur'}
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={!!current.smartShape}
                onChange={(e) => onChangeSettings({ smartShape: e.target.checked })}
                className="w-4 h-4 accent-blue-500 rounded cursor-pointer"
              />
            </label>
          </div>
        )}

        {/* 2. FOSFORLU KALEM (HIGHLIGHTER) ÖZEL AYARLARI */}
        {isHighlighter && (
          <div className="space-y-4">
            {/* Quick Thickness Presets */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                <span>Fosforlu Kalınlığı</span>
                <span className="font-mono text-amber-400 font-bold">{current.size} px</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {highlighterPresets.map((px) => {
                  const isSel = current.size === px;
                  return (
                    <button
                      key={px}
                      type="button"
                      onClick={() => onChangeSettings({ size: px })}
                      className={`h-11 rounded-xl flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                        isSel
                          ? 'bg-amber-500 text-slate-900 border-amber-300 shadow-md font-bold'
                          : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <span
                        className="rounded-full bg-current"
                        style={{ width: `${Math.min(18, px * 0.5)}px`, height: `${Math.min(18, px * 0.5)}px` }}
                      />
                      <span className="text-xs">{px === 14 ? 'İnce' : px === 22 ? 'Orta' : 'Geniş'}</span>
                    </button>
                  );
                })}
              </div>
              <input
                type="range"
                min={8}
                max={48}
                value={current.size}
                onChange={(e) => onChangeSettings({ size: Number(e.target.value) })}
                className="w-full accent-amber-500 h-2 bg-white/20 rounded-lg cursor-pointer"
              />
            </div>

            {/* Opacity Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                <span>Saydamlık (Opaklık)</span>
                <span className="font-mono text-amber-400 font-bold">{Math.round((current.opacity || 0.45) * 100)}%</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[0.3, 0.45, 0.65].map((op) => (
                  <button
                    key={op}
                    type="button"
                    onClick={() => onChangeSettings({ opacity: op })}
                    className={`py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      Math.abs((current.opacity || 0.45) - op) < 0.05
                        ? 'bg-amber-500 text-slate-900 border-amber-300 font-bold'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    %{Math.round(op * 100)}
                  </button>
                ))}
              </div>
            </div>

            {/* Tip Style */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300">Uç Modeli</span>
              <div className="grid grid-cols-2 gap-2 p-1 bg-white/10 rounded-2xl">
                <button
                  type="button"
                  onClick={() => onChangeSettings({ lineCap: 'round' })}
                  className={`py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    current.lineCap === 'round' || !current.lineCap
                      ? 'bg-amber-500 text-slate-900 shadow-md font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Yuvarlak Uç
                </button>
                <button
                  type="button"
                  onClick={() => onChangeSettings({ lineCap: 'butt' })}
                  className={`py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    current.lineCap === 'butt'
                      ? 'bg-amber-500 text-slate-900 shadow-md font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  Kesik / Kare Uç
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 3. SİLGİ (ERASER) ÖZEL AYARLARI */}
        {isEraser && (
          <div className="space-y-4">
            {/* Mode: Precision Vector Eraser vs Stroke Eraser */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300">Silme Tarzı</span>
              <div className="grid grid-cols-2 gap-2 p-1 bg-white/10 rounded-2xl">
                <button
                  type="button"
                  onClick={() => onChangeSettings({})}
                  className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    tool === 'eraser'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Eraser className="w-3.5 h-3.5" />
                  <span>Hassas Silgi</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangeSettings({})}
                  className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    tool === 'stroke-eraser'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  <Scissors className="w-3.5 h-3.5" />
                  <span>Çizgi Silgisi</span>
                </button>
              </div>
              <p className="text-[10px] text-slate-400 px-1">
                {tool === 'eraser'
                  ? 'Fiziksel silgi: Dokunduğunuz yerdeki çizgiyi parça parça siler.'
                  : 'Çizgi silgisi: Dokunulan çizginin tamamını tek seferde kaldırır.'}
              </p>
            </div>

            {/* Eraser Size Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
                <span>Silgi Çapı</span>
                <span className="font-mono text-blue-400 font-bold">{current.size} px</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {eraserPresets.map((px) => (
                  <button
                    key={px}
                    type="button"
                    onClick={() => onChangeSettings({ size: px })}
                    className={`h-10 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      current.size === px
                        ? 'bg-blue-600 text-white border-blue-400 font-bold'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    {px === 10 ? 'Küçük' : px === 20 ? 'Orta' : 'Geniş'}
                  </button>
                ))}
              </div>
              <input
                type="range"
                min={4}
                max={50}
                value={current.size}
                onChange={(e) => onChangeSettings({ size: Number(e.target.value) })}
                className="w-full accent-blue-500 h-2 bg-white/20 rounded-lg cursor-pointer"
              />
            </div>

            {/* Erase Highlighter Only Toggle */}
            <label className="flex items-center justify-between p-2.5 bg-white/5 rounded-2xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <div>
                <span className="block text-xs font-semibold text-slate-200">Yalnızca Fosforluyu Sil</span>
                <span className="block text-[10px] text-slate-400">Kalem yazılarına dokunmaz, sadece sarı/renkli vurguları siler</span>
              </div>
              <input
                type="checkbox"
                checked={!!current.eraseHighlighterOnly}
                onChange={(e) => onChangeSettings({ eraseHighlighterOnly: e.target.checked })}
                className="w-4 h-4 accent-blue-500 rounded cursor-pointer"
              />
            </label>

            {/* Clear Entire Page Button */}
            <button
              type="button"
              onClick={() => {
                onClose();
                onClearPage();
              }}
              className="w-full py-2.5 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-rose-100 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>Sayfadaki Tüm Çizimleri Temizle</span>
            </button>
          </div>
        )}

        {/* 4. GEZİNME (HAND) VE AVUÇ İÇİ AYARLARI */}
        {isHand && (
          <div className="space-y-4">
            <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-2xl space-y-1">
              <span className="text-xs font-bold text-blue-400">Gezinme Modu Açık</span>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Tek parmakla sayfayı serbestçe kaydırabilir, iki parmakla yakınlaştırıp uzaklaştırabilirsiniz. Kazara çizgi oluşmaz.
              </p>
            </div>

            <label className="flex items-center justify-between p-2.5 bg-white/5 rounded-2xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="block text-xs font-semibold text-slate-200">Avuç İçi Koruması (Palm Rejection)</span>
                  <span className="block text-[10px] text-slate-400">Apple Pencil algılandığında parmak çizim yapmaz</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={palmRejection}
                onChange={(e) => onTogglePalmRejection(e.target.checked)}
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
            </label>
          </div>
        )}

        {/* Done / Close Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Tamam</span>
          </button>
        </div>
      </div>
    </div>
  );
}
