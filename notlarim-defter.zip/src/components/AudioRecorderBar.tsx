import { useState, useRef, useEffect } from 'react';
import { AudioRecording } from '../types.ts';
import {
  Mic,
  Square,
  Play,
  Pause,
  Trash2,
  Download,
  Volume2,
  ChevronDown,
  ChevronUp,
  X,
} from 'lucide-react';

interface AudioRecorderBarProps {
  recordings: AudioRecording[];
  onAddRecording: (recording: AudioRecording) => void;
  onDeleteRecording: (id: string) => void;
  onClose: () => void;
}

export function AudioRecorderBar({
  recordings,
  onAddRecording,
  onDeleteRecording,
  onClose,
}: AudioRecorderBarProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [activePlayId, setActivePlayId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playProgress, setPlayProgress] = useState(0);
  const [isExpanded, setIsExpanded] = useState(true);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Stop recording on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
    };
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Data = reader.result as string;
          const newRec: AudioRecording = {
            id: `rec_${Date.now()}`,
            name: `Ses Notu ${recordings.length + 1}`,
            duration: recordSeconds,
            dataUrl: base64Data,
            createdAt: Date.now(),
          };
          onAddRecording(newRec);
        };
        reader.readAsDataURL(blob);
        setIsRecording(false);
        setRecordSeconds(0);
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      };

      recorder.start(250);
      setIsRecording(true);
      setRecordSeconds(0);
      timerIntervalRef.current = window.setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } catch (err) {
      console.error('Mikrofon erişimi reddedildi veya hata oluştu', err);
      alert('Mikrofon erişimi izni verilemedi. Lütfen tarayıcı ayarlarından mikrofon iznini kontrol edin.');
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  const handlePlayToggle = (rec: AudioRecording) => {
    if (activePlayId === rec.id && isPlaying) {
      audioPlayerRef.current?.pause();
      setIsPlaying(false);
      return;
    }

    if (!audioPlayerRef.current) {
      audioPlayerRef.current = new Audio();
      audioPlayerRef.current.onended = () => {
        setIsPlaying(false);
        setPlayProgress(0);
      };
      audioPlayerRef.current.ontimeupdate = () => {
        if (audioPlayerRef.current && audioPlayerRef.current.duration) {
          setPlayProgress(
            (audioPlayerRef.current.currentTime / audioPlayerRef.current.duration) * 100
          );
        }
      };
    }

    audioPlayerRef.current.src = rec.dataUrl;
    audioPlayerRef.current.play().then(() => {
      setActivePlayId(rec.id);
      setIsPlaying(true);
    }).catch((err) => {
      console.warn('Playback error', err);
    });
  };

  const handleDownload = (rec: AudioRecording) => {
    const a = document.createElement('a');
    a.href = rec.dataUrl;
    a.download = `${rec.name}.webm`;
    a.click();
  };

  return (
    <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 w-11/12 max-w-lg bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-2xl shadow-2xl text-white overflow-hidden transition-all duration-200 select-none">
      {/* Header Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-800/80 border-b border-slate-700/50">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center">
            <Volume2 className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-slate-200">
            Sesli Notlar ({recordings.length})
          </span>
          {isRecording && (
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-bold animate-pulse">
              <span className="w-2 h-2 rounded-full bg-red-500" />
              Kayıt: {formatTime(recordSeconds)}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-7 h-7 rounded-lg hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            title={isExpanded ? 'Daralt' : 'Genişlet'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-3.5 space-y-3">
          {/* Record Actions */}
          <div className="flex items-center justify-between gap-3 bg-slate-800/40 p-2.5 rounded-xl border border-slate-700/40">
            <div className="text-xs text-slate-300">
              {isRecording ? (
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-red-500 animate-ping inline-block" />
                  <span className="font-mono text-red-400 font-bold">{formatTime(recordSeconds)}</span>
                  <span className="text-slate-400">Ders kaydediliyor...</span>
                </div>
              ) : (
                <span>Derste veya toplantıda ses kaydı başlatın</span>
              )}
            </div>

            {isRecording ? (
              <button
                onClick={handleStopRecording}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-600/30 active:scale-95 transition-all cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Kaydı Bitir</span>
              </button>
            ) : (
              <button
                onClick={handleStartRecording}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/30 active:scale-95 transition-all cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Kaydı Başlat</span>
              </button>
            )}
          </div>

          {/* Recordings list */}
          {recordings.length > 0 ? (
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {recordings.map((rec) => {
                const isThisPlaying = activePlayId === rec.id && isPlaying;
                return (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-800/70 border border-slate-700/60 hover:bg-slate-800 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 flex-1 min-w-0">
                      <button
                        onClick={() => handlePlayToggle(rec)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-90 cursor-pointer ${
                          isThisPlaying
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-blue-600 text-white hover:bg-blue-500'
                        }`}
                      >
                        {isThisPlaying ? (
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                        )}
                      </button>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-medium text-slate-200 truncate">{rec.name}</span>
                          <span className="text-[10px] font-mono text-slate-400">
                            {formatTime(rec.duration)}
                          </span>
                        </div>
                        {isThisPlaying && (
                          <div className="w-full bg-slate-700 h-1 rounded-full mt-1.5 overflow-hidden">
                            <div
                              className="bg-blue-400 h-full transition-all duration-200"
                              style={{ width: `${playProgress}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleDownload(rec)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                        title="İndir (.webm)"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteRecording(rec.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                        title="Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-3 text-xs text-slate-500">
              Bu sayfada henüz ses kaydı yok.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
